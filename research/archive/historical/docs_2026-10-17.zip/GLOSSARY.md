# Glossary: terms used in the 2026-09 solver investigations

**plain / etkdg start** — the normal solver. Each ligand is embedded on its own by RDKit ETKDG (free
ligand, no metal), then the solver moves it only as a rigid body plus rotations about rotatable bonds.
Every bond length and bond angle stays exactly as ETKDG made it.

**rigid body / junction** — the solver splits each ligand into rigid pieces at its rotatable bonds
(a pyrazole ring, a tolyl ring, a lone boron, a CH3...). A *junction* is an atom where pieces meet;
the angles there (e.g. N–B–C at a boron) are frozen too.

**oracle** — any diagnostic run that uses the reference (crystal/DFT) structure to answer "what if
this part were perfect?". Oracles only measure the potential of an idea; they can never be part of
the solver. All are available as `jdev case NAME --start ...`.

- **full oracle** (`--start full_oracle`; earlier "crystal internal geometry", `oracle_internal`) —
  every ligand starts with its exact crystal shape (all bond lengths and angles), then the unmodified
  solver places it. It answers: how good can the solver be if the frozen internal geometry were
  right? Panel sample: median ~100 kJ/mol vs ~400 plain.
- **junction oracle** (`--start junction_oracle`; earlier "hybrid", "hybrid_bodies",
  "crystal junctions") — each rigid piece keeps its ETKDG shape but is placed where it sits in the
  crystal, so only the angles *between* pieces are corrected. It answers: how much of the gap is
  junction angles? VUCVUN: 1919 → ~125.
- **reachability fit / closest reachable pose** — fit the solver's own degrees of freedom straight
  onto the crystal coordinates (minimise RMSD; optionally weight donors). It answers: can the
  solver's parameterisation even express the crystal structure? (VUCVUN plain: no, pyrazole N's stuck
  ≥ 2.4 Å from Sc; with hinges: yes, within 0.02 Å.)
- **oracle Q1** (previous session) — replace the statistical M–D distance targets with the crystal's
  bond lengths. Its "4 donors stuck 0.2 Å off" was a reachability limit, not an optimizer limit.

**S_orient / QO (v2, 2026-09-24)** — the joint donor-orientation score that replaces Q3 + Q4 when the DB has
QO fits: per κ donor, the cosines of every angle at the donor among {metal, substituents} (dim 1/3/6 for
1/2/3 substituents), scored by a full-covariance Gaussian mixture keyed by substituent count, chelate-ring
size, donor subclass, metal, geometry and anion context. `solve(orientation_model="auto"|"sorient"|"q3q4")`.
See `math.md` S6.

**chelate-aware embed (v2)** — the default free-ligand embed for ligands with ≥ 2 κ donors: distance bounds
between same-ligand donors that any chelate must satisfy (≥ 2.4 Å apart, both within their M–D length of one
point, ≤ 100° bite for 4–6-membered chelate rings), best of 8 ETKDG candidates when the first violates them,
MMFF with the bounds as restraints; formally anionic lone-pair donors get a temporary H cap. Fixes trans C=C
between donors and MMFF-straightened [C-]=O. `solve(chelate_embed=True)`. (It supersedes the *templated start*
below, which used cis/trans labels.)

**angle bends / Q7 (v2)** — optional bond-angle DOFs on chelate backbones with a flat-bottom quadratic
penalty (free ±2°, width 5°). `solve(angle_bends=True)`; off by default (fixes VUCVUN, worsens typical chelates).

**Q1 trans key from the assignment (v2)** — the trans partner in each Q1 key is read from the candidate
donor-to-site assignment (one Q1 table per candidate, gathered per row), not from the arbitrary initial shell.

**seed noise** — the spread of a case's |ΔE| over solver seeds; changes smaller than about twice this spread
are not distinguishable on one run (`tools/jdev/bench.paired_diff`).

**held-out 28** — the 40-complex random tmQM sample of 2026-09-23 minus the 12 panel complexes; never used for
diagnosis or tuning (`tests_next/regression/fixtures/tmqm_sample40`, `bench.HELDOUT28`).

**templated start** — ETKDG/KDG embedding of the free ligand with extra distance bounds between donor
atoms so the donors already sit roughly where a metal would hold them (cis 70–100°, trans 140–180°
at ~2.25 Å). *Generic template* = the same without cis/trans labels (70–180° for every pair). Pure
distance geometry, no force field. Not in src_next.

**hinge joints** — an experimental extra joint type (sandbox only, not in src_next): a bounded
(±12°) bend of the bond angle at a non-donor junction atom on a donor-to-donor path, softly held to
its ETKDG value. Makes cages like VUCVUN reachable, but alone doesn't find or know the right angle.

**reach phase** — an experimental pure-IK pre-step (sandbox only) that pulls donors onto their
target sites before the normal solve. Got stuck in local minima; not kept.

**score** — the solver's statistical objective (full definition: `math.md` S7): sum of per-quantity mean log-likelihoods Q1..Q6
(Q1 M–D distance, Q2 D–M–D angles, Q3 donor approach/tilt, Q4 donor pyramidalisation, Q5 ligand
torsions, Q6 non-bonded contacts). Higher is better. Crystal VUCVUN scores −0.75.

**dE / dE_sp** — MACE-POLAR-1 single-point energy of the best-scoring conformer minus that of the
reference structure (same atoms, charge, multiplicity), in kJ/mol. Strict: every small bond or angle
strain counts. Negative values happen (solved structure lower than the reference under MACE).

**dE_basin / strain** (`jdev audit --relax`) — relax both structures locally with MACE (as a
measurement only) and compare: `strain` = how much energy a small local relaxation removes (and how
far atoms move), `dE_basin` = remaining difference = "is it the right structure?". This is how
Architector-style benchmarks compare generated vs crystal structures.

**thermal scale** — (3N−6)·kT/2: average potential energy of a room-temperature snapshot above the
minimum, by equipartition (~2.5 kJ/mol per 2 vibrational modes; ~310 kJ/mol for 85 atoms).

**guards / panel / baseline** — `tests_next/test_guards.py` (fast, hang-proof checks), the
24-case accuracy/speed panel (`tests_next/regression/run_panel.py`), and its stored reference results
(`baseline.json`). See `tests_next/REGRESSION_README.md`.

**device / sandbox** — the laptop checkout (source of truth) vs Claude's cloud copy. Numbers only
count if the sandbox copy's fingerprint matches the device.
