# What our ensembles are, and how we judge them (2026-10-16)

Owner request (10-16): formalise conformer vs Boltzmann, isomer vs basin, and judge the score on the question each
metric can answer. Evidence: `tools/jdev/budget/ensemble_stats.py` (v6 pools `data/energy_scale/ensemble_stats/`, refit
pools `data/energy_scale_refit/ensemble_stats/`), `validity.py`, `forces.py`, `isomer.py`, `oracle_targets.py`.

## 1. Definitions

| object | definition | how we label it |
|---|---|---|
| **isomer class** | coordination geometry + donor -> site assignment, up to proper rotations of the polyhedron and swaps of identical ligands. Mirror images are different classes (enantiomers). Linkage isomers (which atom binds) are fixed by the input. | `assignment_idx` (canonical form of `ik/site_enumeration.py`); the reference's own class: `tools/jdev/budget/isomer.py` |
| **basin** (conformer, in the chemist's sense) | one local minimum of the true potential energy surface inside an isomer class | measurement only: loose GFN2 relaxation of the structure; same isomer class and the relaxed energies within 1 kJ/mol and relaxed heavy-atom RMSD < 0.25 A = same basin. Relaxations that change the covalent graph are excluded. |
| **snapshot** | any point inside a basin. Its single-point energy = basin energy + strain | every returned conformer is a snapshot |
| **conformer ensemble** (what `solve()` returns today) | unweighted, score-ranked snapshots, one per 0.5 A RMSD cell | |
| **Boltzmann ensemble** | basins weighted by exp(-dG/kT) (optionally with thermal snapshots inside each basin) | not produced yet: preconditions in section 4 |

Thermal scale: a 298 K snapshot of a minimum carries on average (3N-6) kT/2 of potential energy above it
(equipartition; ~200 kJ/mol for 60 atoms), with spread sqrt((3N-6)/2) kT. A single-point dE of 100-200 kJ/mol against a
minimised reference is therefore the size of a thermal snapshot. It is not by itself "unphysical"; 1000+ is.

## 2. The reference is one isomer's minimum, not "the answer"

tmQM structures are GFN2 minima of the crystallised isomer: the one someone made and found worth solving, not
necessarily the lowest or most common one. The single-point dE of our #1 against it mixes three things:
(a) did we pick the same isomer, (b) the same basin, (c) how far from that basin's minimum the snapshot sits (strain).

Measured (GFN2 relaxations, graph-checked):
- v6 seed-11 pools (116): 16 % contain a basin > 10 kJ/mol below the relaxed reference (largest real one PEWBOL -90;
  the -218 to -592 values seen before were relaxations that broke a bond). Refit pools (80): 7 %.
- The #1's own basin sits a median +2.8 (v6) / +5.6 (refit) kJ/mol above the reference basin; its strain is a median
  103 / 88 kJ/mol. Strain dominates the number, which is why dE stays positive even when we are in a lower basin.

Consequence: the benchmark has two tracks.
- **Track I, isomer-matched** (`pools.py --isomer ref`): the solver gets the reference's donor -> site assignment.
  dE then measures precision inside the reference's isomer: what the score and the solver are responsible for.
  Primary target for scorer / solver changes.
- **Track O, open**: our own isomer choice. Judged by the relaxed basin energy of the pick (<= +10 kJ/mol of the
  relaxed reference = correct; lower = a finding, not an error), whether the reference isomer / basin is in the pool,
  and the single-point dE as before.

## 3. Metrics, each with its own yardstick

| level | metric | yardstick | v6 / refit (dev80) |
|---|---|---|---|
| isomer | rho_isomer: class-best score vs class energy (pools with >= 3 classes) | MACE SP / GFN2 relaxed | SP 0.60 / 0.59; relaxed 0.48 / 0.20 |
| within isomer | rho_within: score vs SP inside each class (median over classes with >= 4 members) | MACE SP | 0.68 / 0.68 |
| basin | rho_basin: score vs relaxed energy over basins; pick in the lowest basin (1 kcal/mol); reference basin present | GFN2 relaxed | 0.22 / 0.15; 47 % / 41 %; 88 % / 89 % |
| strain | strain of the #1 (SP - relaxed) | GFN2 | median 103 / 88 kJ/mol |
| whole pool | rho_all, rho_lo (as before) | MACE SP | 0.68 / 0.69; 0.45 / 0.47 |
| validity | share of returned conformers > 1000 kJ/mol | MACE SP | refit 10.6 % |

Reading: the score ranks snapshots by strain about as well inside an isomer class as across classes (0.68 vs 0.59),
but it barely ranks basins or isomers by their minimum energy (0.15-0.48). Pools are genuinely multi-basin: relaxed
energies within a pool spread a median 50 kJ/mol, and 60-80 % of returned conformers relax to distinct basins (the
0.5 A dedup does not merge many snapshots of one basin).

## 4. When a Boltzmann mode makes sense

Preconditions, each measurable with the tools above:
1. basin weights need rho_basin well above the yardstick noise (today 0.15-0.22: weights would be noise);
2. snapshot weights inside a basin need the score's curvature to match the energy's (`forces.py`, section 5);
3. the energy window for basins is CREST's 6 kcal/mol (25 kJ/mol) on RELAXED energies, never on single points.

Until then `solve()` stays a conformer ensemble. A basin mode (no 0.5 A collapse inside a basin, basin labels on the
output) is designed but not built.

## 5. Results feeding the next decisions (2026-10-16 b, details in CHANGELOG.md)

- **Isomer choice is not the hidden variable.** Forcing the reference isomer leaves the #1 median unchanged (+0.1
  kJ/mol) and makes some complexes worse. Track I stays useful as the clean target for precision work, but it does not
  explain the neutral benchmark results.
- **The floor is set by frozen internals and by search, not by where the tables put their modes.** Problem set: internals
  61 % of the open #1, crystal-positioned statistics 10 % (and only together with crystal internals), residual with
  everything at the crystal 36 %.
- **Ligand-internal configuration is a hidden isomer axis.** 1 pick in 5 carries a stereocentre / E/Z / ring pucker the
  crystal does not have (tmQM SMILES carry no stereo; the solver cannot change internals). Belongs to the embed, not
  to the isomer enumeration.
- **Search failures with a clear mechanism:** the beam ranks torsion modes by peak density (needle modes beat dominant
  broad ones: 34 joints in 16 / 80 complexes never seeded on the dominant mode) and never sees the metal (TAPWUG);
  macrocycle folds (FIGHOT).
- **Curvature:** both scores' stiff directions match the energy's (spearman 0.6-0.7), but the scale per term does not.
  Ranking score: Q1 ~20x too stiff (needle components), Q2 ~4x, S_orient ~1, Q6 ~3x too soft. Solve objective: Q1
  ~4.5x too soft (0.2 A floor), Q2 / S_orient ~2x too stiff, Q5 ~4x too stiff (from the mean aggregation; in the
  ranking score Q5 alone is about right), Q6 (soft-min) ~no curvature. Terms and reconciliation: SCORE_SCALE.md. Per-term scales fitted to the energy explain ~half of the directional
  curvature (R^2 0.5-0.6) where the production weights explain none: the measured target for a rebalanced solve
  objective, and the precondition for a curvature-biased relaxation.
- **Obscene members:** the output score window (default 200 nats) removes most of them; the rest are a metal 1-3
  contact the score does not see.
