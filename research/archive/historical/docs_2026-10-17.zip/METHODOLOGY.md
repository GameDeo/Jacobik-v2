# How we decide what to change (2026-10-15)

Why this exists: several changes that were correct on their own terms (the Q6 onset wall, the WCA core, the Q6
potential of mean force, GFN2-Hessian torsion widths, summed instead of mean terms) made the benchmark worse, and each
time the explanation came afterwards. This page is the protocol that makes the outcome of a change predictable, and
explainable, before it is benchmarked. The evidence behind every rule is in section 4 (the 2026-10-15 error-budget
study, `tools/jdev/budget/`).

## 1. Principles

1. **The score is an ordinal surrogate, not an energy.** It is a sum of log-likelihoods of marginal distributions
   fitted to optimised structures. Such sums rank structures usefully but are not on any energy scale: one nat of one
   term is not worth one nat of another (Thomas & Dill 1996; Ben-Naim 1997; Postic et al. 2020), and correlated
   marginals count shared information more than once (Hamelryck et al. 2010). Measured here: one nat of Q5 is worth
   ~1 kT everywhere, while one nat of Q1 / Q2 / S_orient is worth 3–6 kT near the mode and almost nothing in the
   tails (section 4.3). A change that is "more correct" for one
   term changes its weight relative to every other term; that is why such changes move the benchmark unpredictably.
   Swapping one term without re-balancing the rest is the step the literature warns against (Varnai et al. 2013).
2. **"Matches the data" is not "matches the energy".** A distribution fitted to tmQM tells where structures sit, not
   how much it costs to be elsewhere: widths of a database of minima mix chemical diversity with stiffness, and
   matching a pair distribution fixes only where repulsion starts (Rosenberger et al. 2016). Example: the 0.1 %
   onset wall describes the data better than the 5th-percentile wall and charges ~7x fewer nats for a real clash.
3. **Know which budget line a change attacks before running it.** The #1 error splits into lines that different
   changes can and cannot move (section 2). A change aimed at a line smaller than the noise cannot show up.
4. **Noise first.** Identical code and DB on CUDA move set medians by up to 29 kJ/mol and whole-ensemble rho by
   0.07 between runs (section 4.1). Every comparison is paired per complex, with a set-level CI, against that noise.
5. **Cheapest decisive test first.** Offline re-ranking of fixed pools has zero solver noise and costs minutes; it is
   the first gate for any scorer change (`tools/jdev/budget/gate.py`). Solver benchmarks only for what passes.
6. **One question per experiment, prediction written down first.** Before running: the budget line, the predicted
   direction and size, the mechanism, and what result would falsify it. Afterwards: compare with the prediction; a
   wrong prediction is a finding about the model of the problem, recorded as such.

## 2. The error budget (what each benchmark number is made of)

For each complex, the #1 single-point energy relative to the reference splits as

    dE(#1)  =  pool floor (lowest-energy conformer the solver returned)  +  ranking regret (#1 minus floor)

and the floor, by constrained GFN2 relaxations (`xtb_dof.py`), as

    dE  =  torsions / peripheral placement   (relax with ligand internals AND the coordination polyhedron frozen)
        +  coordination sphere               (relax with ligand internals frozen: M-D distances, D-M-D angles)
        +  frozen ligand internals           (full relaxation: bond lengths, angles, ring torsions of the embed)
        +  basin                             (full relaxation minus the relaxed reference: a wrong structure)

The steps are sequential, so the split depends somewhat on their order; the crystal-internals oracle
(`tools/jdev/start.py full_oracle`) gives an independent estimate of the internals line.

| line | moved by | not moved by |
|---|---|---|
| ranking regret | ranking score, term weights, term shapes (re-rank gate measures it exactly) | anything in generation |
| basin | search (assignments, beam, torsion modes), ranking | precision of the statistics |
| coordination sphere | Q1/Q2 targets and how well the solver can reach them (bite angles!) | Q5/Q6 shapes |
| torsions / periphery | Q5, Q6, S_orient, the optimiser | Q1/Q2 |
| frozen internals | the embed (ETKDG / GFN2 free ligand), bends | every score term |

## 3. Decision protocol for a change

1. **Write the prediction** (one paragraph in the CHANGELOG draft): budget line, mechanism, predicted direction and
   size on that line, falsifier.
2. **Ceiling check.** Is that line, on the target set, larger than the effect you need? Use the latest budget run
   (`analyze.py`, `decomp.py`) or an oracle (crystal internals, crystal targets) for the line's upper bound.
3. **Calibration check (scorer changes).** For a new or reshaped term, compare its implied energy per nat (within-pool
   regression, `analyze.py` section 2) with the term it replaces. A term that charges several times more or fewer
   nats per kJ/mol than the one it replaces changes the balance of the whole score: expect side effects.
4. **Re-rank gate (scorer changes).** `gate.py --sets dev32 n48 --override ...` (all 3 seeds): FAIL = stop; no
   detectable change = the change can only act through generation, say so in the prediction.
5. **Solver benchmark** on the dev set (dev32 / N48), 3 seeds, `bench.paired_test` per set (CI, better/worse,
   minimum detectable effect). If the MDE exceeds the predicted effect, the experiment cannot answer; enlarge the set
   instead of reading the medians.
6. **Held-out confirmation once** (heldout28 / ring10 are small: MDE ~70 / ~190 kJ/mol on the mean; use them for
   regressions and catastrophes, not for 10 kJ/mol decisions).
7. **Report** every budget line, not only #1 |dE|: floor, regret, basin share (right structure within 10 kJ/mol),
   rho_lo, top-1, and the paired test. `bench.targets` prints floor / regret / rho_lo since 2026-10-15.

## 4. Evidence (2026-10-15 study)

v6 DB, angle bends on, CUDA solves, all returned conformers kept (348 pools, 16 319 conformers); MACE-POLAR-1-S
single points; GFN2-xTB single points of every conformer, loose relaxations of the top 48 per seed-11 pool, and
constrained relaxations of every seed-11 #1 (116 complexes). Full output: `data/energy_scale/analysis_final.txt`.

**4.1 Noise.** The 10-03 and 10-13 benchmark runs used identical code and DB. Between them, per-run |dE| moved by a
median of 9 kJ/mol (p90 80), ~1 case in 6 crossed ±10 kJ/mol each way, set medians moved by up to 29 kJ/mol
(ring10 192 → 163) and whole-ensemble rho medians by up to 0.07 (N48 0.68 → 0.61). Minimum detectable mean
change (`paired_test`, 3 seeds): panel 5, N48 17, heldout28 69, ring10 194 kJ/mol. The Q6 ablation's onset/WCA
losses (18–21 of 32 cases worse) are far outside this noise (p < 0.001): real.

**4.2 Error budget (MACE, production ranking, median).** #1 = floor + regret: N48 70 = 62 + 6, dev32 74 = 66 + 5,
heldout28 104 = 82 + 8, ring10 154 = 142 + 5. The mean regret (18–126) is the tail of ranking catastrophes. With
crystal internals (oracle) the floor and the #1 roughly halve: N48 #1 69 → 31, dev32 74 → 35, heldout28 104 → 41.
GFN2 split of the #1 picks (116 complexes; share of the summed SP dE, cluster-bootstrap 95 % CI):

| line | share | CI | median kJ/mol |
|---|---|---|---|
| torsions / peripheral placement | 33 % | 26-42 % | 32 |
| coordination sphere | 26 % | 19-32 % | 23 |
| frozen ligand internals | 34 % | 28-39 % | 38 |
| wrong basin | 8 % | 6-10 % | 4 |

No single line dominates. ring10 is the exception (internals 45 %). The crystal-internals oracle puts the internals
share of the MACE #1 at ~52 %. That is above the relaxation estimate of 34 % because it also removes the
solver-DOF errors that wrong internals induce. 64 % of picks relax into the reference basin (≤ 10 kJ/mol; ring10
40 %). Heavy-atom RMSD to the reference (mirror allowed) has a median of 0.97 Å. Some picks are the reference's
mirror image, which an energy metric cannot see. (An early 12-pick sample suggested the coordination sphere
dominated at ~48 %. It does not: a reminder to wait for the full sample.)

**4.2b Yardstick ceiling.** MACE vs GFN2 single points within a pool: rho 0.92, but rho_lo 0.71, and their lowest
conformer agrees within 1 kcal/mol in only 65 % of pools. A score's top-1 / rho_lo judged by one yardstick cannot be
expected to exceed roughly these values. The current 0.45 / 0.45 are measured against that ceiling, not against 1.

**4.3 Energy scale of the terms.** A single linear fit per term (within-pool, top-16 by score, energies capped at
floor + 150) gives kT per nat Q5 0.85, S_orient 0.10, Q6 0.07, Q2 0.04, Q1 0.02. **These single numbers are
misleading: the relation is strongly non-linear.** Same fit per term alone, binned by how much the term varies
within the pool (same-assignment pools):

| term | ≤ 2 nats | ≤ 5 | ≤ 20 | all |
|---|---|---|---|---|
| Q1 | 5.7 | 2.5 | 1.1 | 0.02 |
| Q2 | 4.7 | 3.2 | 1.5 | 0.02 |
| S_orient | 5.7 | 4.6 | 2.9 | 0.17 |
| Q5 | 0.6 | 2.0 | 1.4 | 1.1 |
| Q6 | (noisy, ~1) | | | 0.12 |

The Gaussian-type terms (Q1, Q2, S_orient) are **too soft at the core and far too steep in the tails**. Near the
mode, real energy rises 3–6 kT per nat: the table widths include chemical diversity, so 0.05–0.1 Å or a few degrees
off costs the score little and the energy tens of kJ/mol. Far out, the Gaussian penalty grows without bound while
the energy saturates. Q1's own widths agree at the core with physical stiffness (median sd 0.062 Å → kT/sd² ≈ 650
kJ/mol/Å² ≈ 1.1 mdyn/Å). Q5 (von Mises: bounded tails) is close to 1 kT/nat throughout, i.e. already calibrated.
Hence the failures: no single weight fixes "soft core + steep tail". Re-weighting the ranking to the linear scale
made it WORSE (top-1 0.47 → 0.32), because it mutes the tails that veto broken conformers. (Univariate slopes in
small-range pools can be confounded by co-varying terms; the consistency across Q1 / Q2 / S_orient vs Q5 supports
the mechanism.) Pairwise (ranking-objective, non-negative) weights are very stable across leave-one-complex-out
folds (Q6 0.31, S_orient 0.29, Q5 0.24, Q1 0.08, Q2 0.06). They cut the mean pick by 8 kJ/mol but lower top-1 (0.43),
and the CI includes 0: not adopted. Dropping single terms: without Q5 the pick is worse by 3.0 [1.0, 5.4] kJ/mol and
without S_orient by 1.7 [0.0, 3.3]. Both carry ranking signal despite their small energy scale per nat. Dropping Q6
lowers rho (0.68 → 0.60) but not the pick. **Re-weighting the existing terms is not a lever. Ranking costs ~6 kJ/mol
at the median; the floor is the problem.**

**4.4 Coordination sphere (116 #1 picks).** Half of M–D distances are off by > 0.05 Å (p90 0.20 Å). Of those, the
Q1 table prefers the crystal value in only ~half, and 70–79 % of them use multi-modal (pooled) tables: the wrong mode
wins. D–M–D angles 5–30° off (31 % of pairs): the Q2 table prefers the solved angle in 72 %, i.e. it does not
penalise them. Crystal internals barely reduce these errors (M–D 0.076 → 0.068 Å, CI of the change −0.013 to −0.002; D–M–D
8.8° → 8.7°, no change), so they are statistics and
solver-reach problems, not bite-angle coupling. Pairs > 30° off: first seen in 42 / 116 picks, mostly swapped
identical donors compared pair by pair. After remapping by the best graph automorphism 27 remain, and a
permutation-invariant comparison (sorted angles) leaves 2, so real arrangement differences lie between those
bounds. They are not associated with wrong-basin picks.

**4.5 What happened to rho ~0.7.** Nothing: the v6 baseline still gives 0.61–0.78 per set. Whole-ensemble rho is
dominated by separating broken from decent conformers. Within 50 kJ/mol of the floor (`rho_lo`) it is 0.27–0.56,
and it moves by ~0.09 between identical runs. The 0.33–0.53 in the Q6 ablation report is a different quantity (union
pools of 8 arms).

**4.5a A local relaxation of the #1 (owner decision: it breaks "no force field acts on the complex").** GFN2-xTB
loose optimisation of the seed-11 #1 (~8 s on one core), measured with MACE: median 82 → 5 kJ/mol (N48 69 → 3,
heldout28 104 → 12, ring10 160 → 25), runs > 200 kJ/mol 25 → 0 of 116. The reference is itself a GFN2 minimum, so
this measures how close the pick is to the right structure, which is the question the benchmark means to ask.

**4.5b Re-rank gate, validated.** The base re-score reproduces the stored ranking score (2e-6, same #1 in 32/32
pools). WCA n = 6 on the v6 walls, dev32 + N48, 3 seeds (240 pools, 80 complexes): pick +2.8 [−0.9, +6.6] kJ/mol
(MACE), +3.8 [−0.1, +7.6] (GFN2), better / worse 12 / 20. That is no detectable ranking gain, leaning worse, and
consistent with its full solve in the 10-14 ablation (+3.8 median, 8 better / 11 worse). It took 25 CPU-minutes on
fixed pools instead of a solver benchmark.

**4.6 Refit priorities this implies (predictions to test, not results).** (1) Q1/Q2 key resolution: fewer off donors
whose table prefers the solved value, measurable with `coord_audit.py` on the new DB before any solver benchmark.
(2) Embed internals: the crystal-internals oracle bounds this line at ~half of the #1 (the largest single line on
ring10). (3) Torsion / peripheral precision (a third of the floor): Q5 and Q6 act here through generation, not
ranking. Test changes with the solver benchmark after the re-rank gate. (4) Ranking-only changes act on ~6 kJ/mol
at the median: expect no detectable benchmark change. (5) Q2 widths / pair classes: moderate D–M–D distortions are
currently not penalised (the A4 site-pair key is the refit item that should change this; measure it with
`coord_audit.py`).

## 5. Tools

    python tools/jdev/budget/pools.py solve --sets n48 heldout28 ring10 dev32 --seeds 11 12 13   # GPU, all conformers
    python tools/jdev/budget/pools.py solve --sets n48 heldout28 dev32 --seeds 11 --start full_oracle
    python tools/jdev/budget/pools.py mace                                                         # GPU
    python tools/jdev/budget/xtb_stage.py sp ; python tools/jdev/budget/xtb_stage.py opt           # CPU, GFN2
    python tools/jdev/budget/xtb_dof.py ; python tools/jdev/budget/xtb_dof.py --coord              # constrained relaxations
    python tools/jdev/budget/rmsd_stage.py ; python tools/jdev/budget/coord_audit.py etkdg
    python tools/jdev/budget/coord_audit.py full_oracle
    python tools/jdev/budget/analyze.py ; python tools/jdev/budget/decomp.py ; python tools/jdev/budget/coord_report.py
    python tools/jdev/budget/gate.py --sets dev32 n48 --override Q6_MODEL=wca Q6_WCA_N=6

Output in `data/energy_scale/` (`JACOBIK_BUDGET_OUT` to change). Every stage resumes.
Benchmark statistics: `tools/jdev/bench.py` `targets` (floor, regret, rho_lo) and `paired_test`.
