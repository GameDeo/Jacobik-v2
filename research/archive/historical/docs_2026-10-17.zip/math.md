# Jacobik v3: the mathematics of the algorithm

This is a Supporting-Information-level description of what the code in `src/jacobik` computes, from input to reported
energy difference. Every constant is the value in the code (file references are relative to `src/jacobik/`).
Items marked **(v2)** were added on 2026-09-24 (S_orient, chelate-aware embed, assignment-based Q1 trans keys, optional
angle bends, Q5/FK joint alignment).

Contents: S1 notation · S2 inputs · S3 statistical quantities · S4 fitting · S5 lookup ladders · S6 joint donor orientation (S_orient) · S7 score function ·
S8 ligand embedding · S9 donor-to-site assignment · S10 kinematics · S11 initialisation · S12 optimisation ·
S13 ranking and output · S14 measurement · S15 constants · S16 known issues.

---

## S1. Notation

| symbol | meaning |
|---|---|
| $M$ | metal position (the origin at solve time) |
| $D_s$ | donor point of coordination site $s$: the donor atom for a κ site, the unweighted centroid of the bound atoms for a haptic site |
| $X_{s,i}$ | $i$-th ligand substituent of a κ donor (bonded neighbour other than $M$; H included), $k_s$ = their number |
| $\hat u(v) = v/\lVert v\rVert$ | unit vector |
| $\hat e_j$ | ideal site vector $j$ of the coordination polyhedron (unit, metal-centred) |
| $\pi$ | donor-to-site assignment, $\pi(s)$ = site index of donor group $s$ |
| $\theta$ | degrees of freedom (DOFs) of one ligand: 3 translation, 3 axis-angle, then joint angles |
| $B$ | batch size (number of parallel trials, "rows") |
| $\mathcal N(x;\mu,\sigma^2)$, $\mathcal N(g;\mu,\Sigma)$ | 1-D / multivariate normal density |
| $\mathrm{vM}(\phi;\mu,\kappa)=\dfrac{e^{\kappa\cos(\phi-\mu)}}{2\pi I_0(\kappa)}$ | von Mises density |
| $\operatorname{LSE}_k(a_k)=\log\sum_k e^{a_k}$ | log-sum-exp |

---

## S2. Inputs

A complex is specified by the metal element, the total charge $q$, the spin multiplicity $2S+1$, a coordination-geometry
label (one of the 13 polyhedra in S9.1), and one SMILES per ligand with its donor groups: a single atom index for a κ
donor, several indices for a haptic group. The total number of donor groups must equal the geometry's coordination
number. For benchmark complexes these inputs come from the tmQM record (header charge and spin, the SMILES, the metal
bonds of the crystal structure); **no crystal coordinates enter the solve**.

**Oxidation state** (`core/oxidation.py`). $\mathrm{OS} = q - \sum_{\ell} z_\ell$. Each ligand charge $z_\ell$ is the sum of its
formal charges minus its radical electrons over the non-haptic atoms. All-carbon haptic groups add −1 for sizes 3 and 5
and 0 for sizes 2, 4 and 6. If any ligand cannot be assigned, or the result falls outside $[-4,\ \mathrm{OS_{max}}]$, the
state is *unknown* (code 99). $\mathrm{OS_{max}}$ is 4 for lanthanides, the group number for listed metals, and 8
otherwise. The state enters only through Q1 keys, and the deployed DB uses the `no_state` Q1 ladder (S5), whose
state-keyed levels are skipped when the state is unknown.

---

## S3. Statistical quantities

The same key functions (`stats/key_builder.py`) label the training data (crystal structures) and the terms scored at
solve time, so the two cannot diverge.

**Donor labels.** Each donor gets a subclass from a hierarchy (e.g. `O_water` ⊂ `O_neutral_sigma` ⊂ `O` ⊂ `element_any`).
`bucket_family(sub)` returns two coarser levels of that path, the bucket (bkt) and the family (fam).

**Q1: metal–donor distance.** $d_s=\lVert D_s-M\rVert$. Key: (metal, spin, OS, subclass, geometry, trans-partner subclass).

The trans partner of site $s$ is the site $t$ minimising $\cos\angle(D_s,M,D_t)$, provided $\cos<\cos 140^\circ=-0.766$;
otherwise it is "none". It is always "none" for CN ≤ 2 and for `linear` and `other` geometries.
- In training, the partner comes from the crystal geometry.
- **(v2)** At solve time, the partner comes from the candidate assignment $\pi$ with the same rule applied to the ideal
  site vectors $\hat e_{\pi(s)}$. There is one Q1 table per candidate assignment, and each row of the batch uses the
  table of its own candidate (S7).

**Q2: D–M–D angle.** For every site pair $s<t$: $c_{st}=\cos\angle(D_s,M,D_t)$. Key: (geometry, dist class, metal, sub$_A$, sub$_B$).
The dist class is:
- `different_ligand`;
- otherwise, from the shortest heavy-atom ligand-graph path $p$ between the two sites' donor atoms: `chelate_short` if
  $p\le 4$, `chelate_long` if $p\le 8$, `same_remote` if longer.

**Q3: approach angle.** For a κ donor with $k\ge1$ substituents, $\alpha_s=\angle\big(M-D_s,\ \bar X_s-D_s\big)$ with
$\bar X_s=\frac1{k}\sum_i X_{s,i}$ (H included), scored as $\cos\alpha_s$.

For a haptic face with at least 3 heavy atoms: $\alpha_s=\arccos\big(\hat n\cdot\hat u(\bar F-M)\big)$. Here $\hat n$
is the smallest right-singular vector of the centred face coordinates, with its sign chosen so that
$\hat n\cdot(\bar F-M)\ge0$.

Key: (subclass, metal, geometry, anion bucket).

**Q4: pyramidalisation.** For a κ donor with $k\ge2$ substituents (H included), with $S=\{M,X_1,\dots,X_k\}$:
$$Q4_s=\binom{k+1}{2}^{-1}\sum_{\{a,b\}\subset S}\angle(a,D_s,b)\quad(\text{degrees}).$$
Key: (subclass, geometry, $k$, anion bucket).

**Anion bucket.** The number of *other* sites in the shell whose subclass lies under `O_anionic_any` (hydroxide, oxo,
carboxylate, phenoxide, …), capped at 2.

**Q5: torsion.** For every rotatable bond $j$–$k$ ($j$ the donor-proximal end): the signed IUPAC dihedral
$\phi=\operatorname{dih}(i,j,k,l)$. The flanks are chosen canonically: among the heavy neighbours (all neighbours if
there are none), maximise (atomic number, local bond type, heavy degree, −index).

Key: (type$_j$, type$_k$, type$_i$, type$_l$, ring context). Local types are sp3, double or aromatic, from the bond
orders. The ring context is `chelate` when the bond lies on a shortest path of length ≤ 8 between two donors of the
same ligand.

**Q6: non-bonded contact.** Every atom pair (metal and H included) more than 3 bonds apart. The bond graph used for
counting includes H and one M–D edge per donor atom. Key: the sorted element pair.

**QO (S_orient) (v2).** See S6.

**Training data** (`refit`). tmQM splits X1–X3 and LnQM. Contacts are cleaned with thresholds derived from the data:
- *Through-bond angle.* A metal contact X that has a partner Y (a stronger metal contact bonded to X) is dropped when
  $\angle M\!-\!Y\!-\!X\ge\theta^*$. $\theta^*$ is the minimum of the smoothed angle histogram between 125° and
  (peak ≥ 150°) − 10°. It is accepted if that minimum is ≤ half the smaller of the two peaks; otherwise 150°. Bins are
  5° with a σ = 1 bin smoother.
- *Second sphere.* Per (metal class, element), the valley between the first distance peak (< 3.5 Å) and the highest
  later local maximum. It is accepted if it is ≤ half the smaller peak and at least 30 contacts lie beyond it; bins are
  0.05 Å with σ = 3 bins.

---

## S4. Fitting (`stats/fitter.py`, `stats/mixture.py`, `stats/pooling.py`, `stats/orientation.py`) — 2026-10 refit

Keys with fewer than 30 rows are not fitted on their own (Q3–Q6); Q1/Q2 keys below that get pooled fits (below).

**Ancestor rows.** Every row is also copied to each coarser ladder key (S5), capped at 500 rows per (ancestor, L0
bucket). The cap uses reservoir sampling with a fixed seed. Q6 has no ancestors.

**Evidence weights.** Within a key, the $m$ rows of one complex get weight $w_i=1/m$, so each complex counts once and
$n_{\text{eff}}=\sum_i w_i$ is the number of independent complexes. All mixture fits below are weighted.

**Mixtures in one dimension (Q1 in Å, Q3/Q4, Q2 in cos-space).** Weighted EM for $K=1\ldots K_{\max}$:

$$r_{ik}=\frac{\pi_k f(x_i;\mu_k,s_k)}{\sum_j\pi_j f(x_i;\mu_j,s_j)},\quad
\pi_k=\frac{\sum_i w_ir_{ik}}{n_{\text{eff}}},\quad
\mu_k=\frac{\sum_i w_ir_{ik}u_{ik}x_i}{\sum_i w_ir_{ik}u_{ik}},\quad
s_k^2=\max\!\Big(\frac{\sum_i w_ir_{ik}u_{ik}(x_i-\mu_k)^2}{\sum_i w_ir_{ik}},\ v_{\min}\Big)$$

with $u_{ik}=1$ for Gaussian components and $u_{ik}=(\nu+1)/(\nu+(x_i-\mu_k)^2/s_k^2)$ for Student-t components
(Q2, shared $\nu\in\{2,4,10\}$ by likelihood; Peel & McLachlan 2000).
- A $K$ whose fit has a component with $n_{\text{eff}}\pi_k<10$ is not selectable; $K\le n_{\text{eff}}/10$.
- $K$ by $\mathrm{BIC}=-2\log L+p\ln n_{\text{eff}}$ ($p=3K-1$, $+1$ for $\nu$); two seeds per $K$ (crc32 of the key).
- $v_{\min}$ is a precision clamp (0.002 Å, 0.002 cos, 0.2°), not added.

**Partial pooling (Q1, Q2).** For each key its parent is the next key present in the data along the runtime candidate
order (S5) of an L0 key that reaches it. Keys with $\ge 50$ complexes are fitted on their own data; every other key
is the MAP adaptation (Reynolds et al. 2000) of its parent's fit to its own data, coarse to fine:

$$n_k=\sum_i w_ir_{ik},\ \alpha_k=\frac{n_k}{n_k+r},\quad
\hat\pi_k\propto\alpha_k\frac{n_k}{\sum_jn_j}+(1-\alpha_k)\pi_k,\quad
\hat\mu_k=\alpha_k\bar x_k+(1-\alpha_k)\mu_k,\quad
\hat s_k^2=\alpha_k(S_k+\bar x_k^2)+(1-\alpha_k)(s_k^2+\mu_k^2)-\hat\mu_k^2$$

($\bar x_k$, $S_k$ the $u$-weighted mean and scale of the key's data under component $k$). The relevance factor $r$
(independent complexes) and the Q1 ladder variant are chosen by held-out log-likelihood per complex. Pooled entries are
valid at any $n$: the lookup returns the most specific pooled entry.

**Q2 key.** $(g,c,d,M,a,b)$ with $c$ the ideal angle of the two sites in the best-fit assignment of the shell to the
ideal polyhedron of $g$ (minimum $\sum_i\lVert R v_{\sigma(i)}-u_i\rVert^2$ over assignments $\sigma$ and rotations $R$;
exact for CN $\le 6$, alternating Hungarian/Kabsch from 48 starts for CN 7–9). The solver uses each candidate
assignment's own classes.

**von Mises mixture, well model (Q5).** Rows are folded by rotor symmetry at extraction (every equivalent flank choice
$\phi+2\pi(r/n_k+t/n_j)$ is one row; the weights keep one complex at weight 1). Weighted EM as above with
$\kappa_k=A_1^{-1}(\bar R_k)$ (Best–Fisher, $\le 1/(0.2^\circ)^2$), $K$ by BIC on $n_{\text{eff}}$ with the
10-complex rule. Components with no density dip between them are merged by moment matching (same weight, circular mean
and mean resultant length): one component per well. Broad components ($\kappa<4$) are the off-well tail; it is dropped
from the scored density when it holds less than half the weight and real wells exist.

**Contact-onset wall (Q6).** Per pair key ($\text{H}_p$ = an H on N/O/F facing N/O/F/S/Cl/Br/I):
$\mu=Q_{0.001}$ (evidence-weighted quantile of the non-bonded distances), $\sigma=\max\big((Q_{0.01}-Q_{0.001})/
(z_{0.01}-z_{0.001}),\ 0.05\,\text{Å}\big)$ — the width a Gaussian left flank would have. Metal pairs are also pooled
to (period group, element).

**Full-covariance GMM for QO (v2).** See S6.3.

---

## S5. Lookup ladders (`stats/ladders.py`, `stats/stats.py`)

A query key is resolved by walking a fixed list of increasingly coarse keys and taking the first one that is fitted with
$n\ge n_{\min}=30$. Because every stored key already has $n\ge30$, this is simply the first fitted key. If none has
enough rows, the coarsest fitted key found is used.

**Q1 (deployed variant `no_state`):**
- (m, spin, OS, sub, geom, trans)
- → (m, spin, OS, sub, geom)
- → (m, sub) → (m, bkt) → (m, fam)
- → (pg, sub) → (pg, bkt) → (pg, fam)
- → (any, fam) → (fam) → (element_any)

The two state-carrying levels are skipped when the OS is unknown. pg is the metal's period group (3d, 4d, 5d, Ln). The
variant is chosen during the refit on held-out complexes by mean log-likelihood; state-keeping variants win ties within
0.01.

**Q2:**
- (geom, dist, m, sub$_A$, sub$_B$)
- → the same with bkt, then with fam
- → (geom, dist, pg, fam$_A$, fam$_B$) → (geom, dist, fam$_A$, fam$_B$)
- → (geom, dist) → (CN, dist) → (geom) → (CN) → (any)

**Q3:**
- (sub, m, geom, anion) → (sub, m, anion) → (sub, anion) → (sub, m, geom) → (sub, m) → (sub, pg) → (sub) → (bkt) → (fam) → (any)

For `O_neutral_sigma` donors, the deployed `neutral_sigma_pool` variant starts directly at (bkt).

**Q4:**
- (sub, geom, k, anion) → (sub, k, anion) → (sub, geom, k) → (sub, k) → (bkt, k) → (fam, k) → (k) → (any)

**Q5:**
- full key → without ring context → (type$_j$, type$_k$, type$_i$) → (type$_j$, type$_k$) → the two central elements → (any)

**Q6:**
- (A, B) → (pg, X)
- If neither exists: $\mu=r_A+r_B$ (covalent radii), $\sigma=0.25$ Å. For a metal pair, $\mu$ is multiplied by 1.18 and
  $\sigma=0.12$ Å.

**QO (v2):**
- $(k,\rho,\text{sub},m,\text{geom},a)$ → $(k,\rho,\text{sub},m,a)$ → $(k,\rho,\text{sub},a)$ → $(k,\rho,\text{sub},m,\text{geom})$
- → $(k,\rho,\text{sub},m)$ → $(k,\rho,\text{sub},\text{pg})$ → $(k,\rho,\text{sub})$ → $(k,\rho,\text{bkt})$ → $(k,\rho,\text{fam})$
- → $(k,\rho)$ → $(k)$

$\rho$ is the chelate-ring size (S6.1).

---

## S6. Joint donor orientation, S_orient (v2) (`stats/orientation.py`)

Q3 and Q4 describe the orientation of a donor relative to the metal with two separate one-dimensional statistics.
They discard the correlation between them and the identity of the individual substituents. S_orient replaces both
with one joint density over the complete local frame of the donor.

### S6.1 Features
For a κ donor $D$ with $k\in\{1,2,3\}$ substituents, let $u_M=\hat u(M-D)$ and $u_i=\hat u(X_i-D)$. Sort the
substituents so that $u_M\cdot u_{(1)}\le u_M\cdot u_{(2)}\le\dots$. The feature vector is

$$g=\big(u_M\!\cdot u_{(1)},\dots,u_M\!\cdot u_{(k)},\ \ u_{(i)}\!\cdot u_{(j)}\ (i<j)\big)\in[-1,1]^{d_k},\qquad d_k=k+\tbinom{k}{2}\in\{1,3,6\}.$$

These are the cosines of every angle at $D$ in the set $\{M,X_1,\dots,X_k\}$, i.e. the full Gram matrix of the unit bond
vectors. Sorting by $u_M\cdot u_i$ makes $g$ invariant to relabelling chemically equivalent substituents. For water, for
example, $g=(\cos\angle MOH_{(1)},\cos\angle MOH_{(2)},\cos\angle HOH)$. Q3 and Q4 are both functions of $g$.

The **chelate-ring size** $\rho$ of a donor is the size of the smallest chelate ring through it:
$\rho=\min_{D'}\operatorname{path}(D,D')+2$ over the other donors $D'$ reachable through the ligand graph (metal edges
removed). $\rho=0$ if there is none, and sizes ≥ 7 are pooled as 7. Carboxylate is the clearest case: the median
M–O–C angle is 128.5° monodentate, 90.5° in a 4-ring (κ²) and 118.5° in a 5-ring.

### S6.2 Density
$$p(g\mid\text{key})=\sum_{m=1}^{K}\pi_m\,\mathcal N(g;\mu_m,\Sigma_m),\qquad
S_{\text{orient}}(s)=\frac{1}{d_{k_s}}\log p(g_s\mid\text{key}_s).$$
Dividing by $d_k$ puts every donor on the scale of a one-dimensional log-density, whatever its $k$.

### S6.3 Fit
- **Exclusion.** Donors with an intramolecular H···acceptor contact below 2.3 Å (acceptors N, O, F, Cl, Br, I, S,
  excluding the donor, its substituents and the metal) are excluded. Their orientation is set by the hydrogen bond,
  which Q6 describes. Including them made water fits lopsided: in mixed shells the median difference between the two
  M–O–H angles is 12°.
- **Keys.** Every ladder key with ≥ 50 rows is fitted.
- **Mixture.** A full-covariance GMM with $K=1\ldots4$ (requiring $n\ge15K$), chosen by BIC.
- **Covariance floor.** $\Sigma_m\succeq0.05^2 I$ (`reg_covar`), so no component is thinner than 0.05 in cosine units
  (≈ 3–6° near typical angles).
- **Pruning.** Components with $\pi_m<0.05$ are dropped and the rest renormalised.
- **Seed.** crc32 of the key string.

**Hold-out check.** Complexes with crc32(code) mod 10 = 0 are held out, and the mean held-out $S_{\text{orient}}$ per
dimension is reported (notebook 03, section 6b).

### S6.3b Haptic sites (2026-09-25)
Haptic faces with 3–8 heavy face atoms are part of S_orient, with class $k = 10 + $ face size, ring $= 0$ and the same
key ladder. Features ($g\in\mathbb R^2$), computed identically in extraction (numpy) and scoring (torch):
- face centroid $c$; Newell normal $n=\hat u\big(\sum_i (F_i-c)\times(F_{i+1}-c)\big)$ over the face atoms in ring order
  (cyclic for rings, open for chains such as allyl), oriented so $n\cdot(M-c)>0$ (no SVD in the solve loop);
- tilt $g_0 = n\cdot\hat u(M-c)$ (1 = metal on the face normal);
- bend $g_1 = \text{mean}_{(A,X)}\,\hat u(X-A)\cdot n$ over every face atom $A$ and substituent $X$ outside the face
  (H included): $<0$ bent away from the metal.

Before this, S_orient skipped haptic sites and replaced Q3/Q4 entirely, so a v2 solve did not score how a Cp or
arene faces the metal at all.

### S6.4 In the score
$$\text{Q3-slot}=w_3\cdot\frac{1}{N}\sum_{s}S_{\text{orient}}(s),\qquad \text{Q4-slot}=0,$$
over the $N$ eligible κ donors that have a fitted key. It is evaluated batched per $k$ with precomputed precision
matrices and log-determinants. `orientation_model="auto"` uses it whenever the DB has QO entries; `"q3q4"` restores Q3
and Q4.

---

## S7. The score (`ik/scorer.py`, `ik/kernels.py`)

Every quantity contributes the **mean** log-likelihood over its terms. The score of a structure $X$ is the plain sum
over quantities:

$$\mathcal S(X)=\sum_{Q\in\{1..6,7\}}\bar\ell_Q(X),\qquad \bar\ell_Q=\frac1{N_Q}\sum_{t=1}^{N_Q}\operatorname{LSE}_k\big[\log w_{tk}+\log f_{tk}(x_t)\big].$$

**Gaussian terms (Q1–Q4).** $\log f=-\tfrac12\log2\pi-\tfrac12\log v-\tfrac{(x-\mu)^2}{2v}$ with the effective
variance $v=\max(\sigma^2,v_{\min})$:

| quantity | $v_{\min}$ |
|---|---|
| Q1 | 0.04 Å² (σ ≥ 0.2 Å) |
| Q4 | 4 deg² |
| Q2 | 0.0025 in cos-space |
| Q3 | 0.0025 in cos-space |

Q2 and Q3 are scored on $\cos$ of the angle, with no Jacobian.

**Q1 per candidate (v2).** For a batch holding several candidate assignments, the Q1 parameters are gathered per row,
$(\mu,v,w)_{b,s}=(\mu,v,w)[\pi_{c(b)},s]$, where $c(b)$ is the row's candidate.

**Q5.** $\log f=\kappa\cos(\phi-\mu)-\log(2\pi)-\log I_0^{e}(\kappa)-\kappa$, where $I_0^e$ is the exponentially scaled
Bessel function.

**Q6: soft-min clash wall.** For each pair, with $\mu,\sigma$ from S4:
$$h(d)=\begin{cases}-(d-\mu)^2/2\sigma^2 & d\le\mu\\0&d>\mu\end{cases},\qquad
\bar\ell_6=-\frac1\tau\log\Big(\frac1{N_6}\sum_{p}e^{-\tau h(d_p)}\Big),\ \ \tau=2.$$
This interpolates between the mean penalty ($\tau\to0$) and the worst contact ($\tau\to\infty$). It is not
normalised: it is 0 when there is no clash.

**Q7: angle-bend penalty (v2, only with `angle_bends=True`).** Over every bond angle $\beta_a$ at every bend pivot
(S10.5):
$$\bar\ell_7=-w_7\,\frac1{N_7}\sum_a\tfrac12\Big(\frac{\max(0,|\beta_a-\beta_a^0|-\beta_{\text{free}})}{\sigma_\beta}\Big)^2,$$
with $\beta_{\text{free}}=2^\circ$, $\sigma_\beta=5^\circ$, $w_7=1$ by default, and $\beta^0$ the embed's angles.

**Energy-calibrated bend prior (v2, default penalty when `angle_bends=True`).** Added to the score in the loss, the
best-snapshot choice and the ranking:
$$\ell_{\text{bend}}=-s\sum_k\frac{k_k\,\max(0,|\beta_k|-\beta_{\text{free}})^2}{2RT},$$
summed (not averaged) over bend DOFs, $\beta_{\text{free}}=2^\circ$, $RT=2.479$ kJ/mol, scale $s=1$. $k_k$ (kJ/mol/rad²)
by axis and pivot hybridisation (sp2 if the pivot has a ligand bond of order ≥ 1.4): in-plane sp2 1300, in-plane
sp3 1800, out-of-plane sp2 310, out-of-plane sp3 1100, from harmonic fits of MACE-POLAR-1 single points on 110 bend
DOFs of 12 free chelating ligands (−12…12°). An offline constant; MACE is never called during a solve.

**Quantity weights.** For Q1–Q5 a weight $w_Q$ is folded in as $\log w_Q$ inside each LSE. That only adds a constant,
so it does not change gradients or rankings (S16). Q6 and S_orient are multiplied by their weight.

---

## S8. Ligand embedding (`engine._smiles_to_conformer`, `chelate_embed.py`)

Each ligand is embedded once, with no metal present: RDKit ETKDGv3 (seed 42) followed by MMFF94 minimisation. MMFF is a
silent no-op when it has no parameters, e.g. for boron.
Since 2026-09-28 the default (`embed="gfn2"`) then optimises the ligand with GFN2-xTB (`--opt crude`), holding every
distance among its donor atoms at the embed's value; `embed="mmff"` stops after MMFF, `embed="etkdg"` after ETKDG. **After this step all bond lengths and bond angles are fixed**
(except the optional bends, S10.5). The solver moves only rigid-body DOFs and torsions.

### S8.1 Chelate-aware embed (v2, default)
For ligands with at least two κ donors, distance bounds between every donor pair $(i,j)$ of the ligand are added to the
distance-geometry bounds matrix:

$$2.4\ \text{Å}\ \le d_{ij}\le r_i+r_j,\qquad\text{and if }\ \operatorname{path}(i,j)+2\le6:\quad d_{ij}\le\sqrt{r_i^2+r_j^2-2r_ir_j\cos100^\circ},$$

- $r$ is a typical M–D length per donor element: C 2.00, N/O 2.05, P 2.25, S 2.40, Se 2.50, Cl 2.35, Br 2.50, I 2.70 Å,
  and 2.2 Å otherwise.
- The first bound says two donors cannot overlap at one metal.
- The second says both donors lie within their M–D length of a common point.
- The third says donors closing a 4-, 5- or 6-membered chelate ring span cis sites (bite angle ≤ 100°).
- These are geometric necessities of chelation; no reference structure is used.

The bounds are triangle-smoothed and a first conformer is embedded (random-coordinate start). Its violation is
$V=\sum_{(i,j)}[\max(0,d_{ij}-u_{ij})+\max(0,l_{ij}-d_{ij})]$. If $V>0$, 8 conformers are embedded with the same seed
and the one with minimum $V$ is kept (first on ties). The first conformer of that set is identical to the single embed,
so the early exit never changes the result. MMFF is then run with the same bounds as flat-bottom restraints
($k=100$ kcal mol⁻¹ Å⁻²).

**Anion caps.** A donor written as a formal anion with a lone pair ($[C^-]{=}O$, $[N^-]$, $[O^-]$, $[S^-]$) is
neutralised and capped with a temporary H for the embed and MMFF, then the cap is removed. Without it, MMFF types an
acyl $[C^-]{=}O$ carbon as isocyanide-like and straightens C–C=O to about 180°. Group-13 "ate" centres ($[B^-]$, …)
are not capped.

---

## S9. Donor-to-site assignment

### S9.1 Ideal polyhedra (`ik/targets.py`)
Unit site vectors for:

| geometry | CN |
|---|---|
| linear | 2 |
| trigonal, t_shaped | 3 |
| square_plan, tetrahedral, see_saw | 4 |
| square_pyr, trig_bipyr | 5 |
| octahedral, trig_pris | 6 |
| pent_bipyr | 7 |
| square_anti | 8 |
| tricap_pris | 9 |

(Explicit vectors are in `targets.py`.)

### S9.2 Baseline assignment
- **Cost.** $C_{sj}=\arccos(\hat u(D_s-M)\cdot\hat e_j)$ over the donor directions of the initial shell, where each
  ligand has been translated rigidly so that its donor centroid sits 2.5 Å from $M$.
- **Hungarian solution.** The linear assignment minimising $\sum_s C_{s\pi(s)}$.
- **Chelate repair.** For each same-ligand donor pair at most 4 hops apart whose assigned sites are more than 115°
  apart, try swapping one of them with every other donor so that the pair ends up ≤ 115° apart. Take the swap with
  the smallest cost increase. At most 4 passes.

### S9.3 Reachability
The hop count $h_{st}$ is the shortest heavy-atom ligand-graph path between two same-ligand donors. A pair placed on
sites with angle $\gamma$ is *reachable* if:

| hop count | allowed $\gamma$ |
|---|---|
| $h\le4$ | $55^\circ\le\gamma\le115^\circ$ |
| $h=5$ | $\gamma\le150^\circ$ |
| $h\ge6$ | any |

An unreachable baseline is replaced by the minimum-cost reachable assignment, found by depth-first branch-and-bound
(donors with the most hop partners first, sites in increasing cost; 200 000 node budget).

### S9.4 Symmetry enumeration (default on)
Used when $n_{\text{donors}}=\mathrm{CN}$ and the geometry has fixed sites.

- **Search.** Every reachable bijection is enumerated by backtracking. The next donor is the one closest in hops to
  those already placed; sites are tried in index order. It stops at 50 000 assignments or 30 s.
- **Deduplication (embed-aware, default `embed_aware_dedup=True`).** Two assignments are merged only if they are the
  same structure *for the embedded ligands*, i.e. related by
  - a **proper rotation** $\sigma\in G^+$ of the polyhedron (site permutations realised by a rotation, $\det R=+1$;
    for planar or linear site sets every site symmetry qualifies, since a reflection through the plane fixes every
    site): octahedron $|G^+|=24$ of 48, tetrahedron 12 of 24; and/or
  - a **swap of whole identical ligand instances** (same SMILES and donor count), donor $k$ of one instance onto donor
    $k$ of the other.

  Implementation: canonical key $\kappa(a)$ = the sorted tuple of the instances' site tuples per identical-ligand
  group, plus the sites of all other donors; $a$ is a duplicate if $\kappa(\sigma\circ a)$ was seen for some
  $\sigma\in G^+$. Cost $O(|G^+|\,n)$ per assignment, independent of how many identical ligands there are.

  *Why not the graph-level symmetry.* Swapping two topologically equivalent donors inside **one** ligand, or
  reflecting the polyhedron, also swaps or mirrors their 3D arrangement in the embed. Torsions cannot always undo
  that: two identical arms on a tetrahedral centre (B(pz)$_2$, C(pz)$_2$, …) have a fixed order around it that only
  inverting the centre changes. The legacy dedup (`embed_aware_dedup=False`: donor-equivalence relabellings
  $\times$ all site symmetries, reflections included) could keep only the variant that the embed cannot reach
  (VUCVUN: heavy-atom RMSD 2.94 Å with the crystal's torsions vs 0.31 Å for the other variant).
- **One row budget per topological class.** Assignments that the legacy dedup would merge form one class (key: the
  minimum over all site symmetries of the donor-equivalence-canonical key). A class of $s$ members keeps the
  $\lceil W/s\rceil$ best beam seeds per coordinate sample of each member, so it costs about one candidate's
  $M\times W$ rows; rows of members the embed cannot reach do not converge and are removed by the row cull (S12.6).
- **Solve.** All surviving candidates are solved together in one batch (rows tagged by candidate), and ranked
  together.

---

## S10. Kinematics (`topology/decompose.py`, `ik/fk.py`, `ik/angle_bends.py`)

### S10.1 Rigid bodies and joints
- **Rotatable bond.** A non-ring bond (not in the minimum cycle basis) with bond order in [0.95, 1.05] whose two atoms
  both have degree > 1 (H counted). Conjugated single bonds qualify.
- **Rigid bodies.** The connected components after cutting the rotatable bonds.
- **Root body.** A donor-free body. The code prefers bodies with no donor body adjacent, then the smallest maximum hop
  distance to a donor body.
- **Joint order.** Breadth-first over bodies from the root. Each joint $(j,k)$ has $j$ on the root side, flanks $i,l$
  (the heaviest heavy neighbour, lowest index on ties), and a downstream set = all atoms of the bodies beyond $k$.

### S10.2 Forward map
For ligand $L$ with reference coordinates $X^0$:
1. **Base transform.** $x\leftarrow R(\omega)(x-c)+c+t$, with $R(\omega)$ the Rodrigues rotation of the axis-angle
   vector $\omega$ and $c$ the mean of the ligand's donor atoms.
2. **Torsions, in joint order.** Joint angles are **absolute** dihedrals: the downstream set of joint $k$ is rotated
   about the axis $\hat u(x_k-x_j)$ through $x_j$ by $\delta=\theta_{6+k}-\operatorname{dih}(i,j,k,l)$ (Rodrigues:
   $v\mapsto v\cos\delta+(\hat a\times v)\sin\delta+\hat a(\hat a\cdot v)(1-\cos\delta)$).
3. **Branch bend joints.** For a κ donor with at least 2 outgoing rotatable branches, each branch also gets a dihedral
   joint about the donor's root-ward bond. These joints have no statistics.
4. **Macrocycle joints.** For rings of at least 8 atoms, all single bonds, holding at least 2 donors:
   - The ring is opened at a seam opposite the most substituted ring atom. The ring bonds of the two arms become
     joints.
   - Closure residuals: $r=\lVert x_a-x_b\rVert-d_0$ for the seam bond and the two 1-3 distances across it.
   - The exact Jacobian is $\partial x/\partial\phi_k=\hat u_k\times(x-p_k)$ for downstream atoms, 0 otherwise.
   - During the optimisation, each Adam step $s$ on the ring joints is corrected to
     $s'=s-\operatorname{clip}(c,\pm0.5)$ with $c=-J^\top(JJ^\top+10^{-4}I)^{-1}(r-Js)$.
   - After it, 4 damped Gauss–Newton iterations are applied:
     $\Delta\phi=-J^\top(JJ^\top+10^{-4}I)^{-1}r$, with each step clipped to ±0.5 rad.
   - Ring starting folds are drawn from an ETKDG pool: up to 64 embeds, ranked by how well the sp3 N lone pairs
     converge on one point, diversified by a ring-dihedral RMS distance ≥ 0.6 rad, and MMFF-relaxed.

### S10.3 Axis-angle normalisation
After each step, $\lVert\omega\rVert$ is clamped to $\le\pi$.

### S10.4 Q5 / joint alignment (v2)
The beam search (S11.2) and the cull signature (S12.6) look up a Q5 distribution for each FK joint. They now use the Q5
row of the **same bond**, and convert its angles into the joint's dihedral convention:
$\mu^{\text{FK}}=\mu^{Q5}+(\phi_{\text{FK}}-\phi_{Q5})\big|_{X^0}$. The two dihedrals about the same bond, measured
with different flank atoms, differ by a constant set by the rigid flanking groups.

Before this fix, the $k$-th joint of a ligand read the $k$-th Q5 row of that ligand. The Q5 rows are enumerated in a
different order (donor-rooted pivot chains vs root-body BFS): in 6 panel ligands, 49 of 52 joints read another bond's
statistics.

### S10.5 Optional angle bends (v2, `angle_bends=True`)
- **Where.** For every acyclic heavy–heavy bond $(a,b)$ (a graph bridge) on a shortest path between two κ donors of
  the same ligand, and for each end atom $p\in\{a,b\}$ that has another neighbour $r$ ($o$ = the other end). $M$ =
  the smaller side of the bridge (the same set for both ends).
- **DOFs.** Two per (bridge, end): rotations of $M$ about lines through $x_p$ with directions, from the positions
  $X^0$ the bends act on (after the torsion FK),
  $n_1=\hat u\big((x^0_o-x^0_p)\times(x^0_r-x^0_p)\big)$ (in-plane) and $n_2=\hat u(x^0_o-x^0_p)\times n_1$
  (out-of-plane). Start at 0 (the embed's angles).
- **Composition (`BendPlan`).** Bend $k$ is the rigid map $x\mapsto R_kx+t_k$, $R_k=\exp(\beta_k[n_k]_\times)$
  (Rodrigues), $t_k=x^0_{p_k}-R_kx^0_{p_k}$. Bends are applied in an order in which bend $j$ precedes bend $i$ whenever
  $p_j\in M_i$ (bends sharing a pivot: any order), so each pivot is still at $x^0_p$ when its bend acts and the axis
  line is exact. Since the only bond into $M$ is the bridge, every bond length is preserved; later bends carry
  earlier ones rigidly (a kinematic chain whose hinges ride on their pivot's body). An atom's transform is the
  product over the bends that move it, in that order; atoms with the same bend list share a chain, whose transform is
  built with $D$ (nesting depth) batched matrix products, then applied to all moved atoms in one gather. No loop over
  bends, no data-dependent control flow.
- **Penalty.** Either the energy-calibrated prior (default `bend_penalty="energy"`, S7) or the legacy Q7.
- **Exclusions.** Ligands with macrocycle joints get none.

---

## S11. Initialisation

### S11.1 Coordination targets
For each candidate assignment and donor, $M=8$ M–D lengths $\ell_{s,m}$ are drawn from the Q1 mixture (modes with a
low relative weight dropped; a family table value with σ = 0.05 Å if there is no fit). The targets are
$T_{s,m}=\ell_{s,m}\,\hat e_{\pi(s)}$. They are used **only** to place the ligands at the start; they are not part of
the score.

### S11.2 Beam search over torsion modes
Per ligand, over its base torsion joints in joint order:
1. Each partial seed is expanded with every mode mean of the joint's Q5 mixture (weights > $10^{-7}$).
2. Seeds are scored by the cumulative $\sum\log\mathrm{vM}$ at the chosen means.
3. Duplicates are removed, and the top $W=16$ are kept (padded round-robin if fewer).

The result is 16 torsion seeds per ligand, shared by all candidates. (A partial-Q6 term exists in `beam.py`, but the
engine never passes the pair list, so it is inactive; see S16.)

### S11.3 Batch and rigid placement
$B=n_{\text{cand}}\times8\times16$ rows. For each row and ligand, the base DOFs come from a Kabsch fit of the ligand's
donor points to its targets:
- $H=P_c^\top Q_c$, $R=V\operatorname{diag}(1,1,\det VU^\top)U^\top$, $t=\bar Q-\bar P$.
- For 1 donor, or 2 or collinear donors, the undetermined rotation (about the target direction, or the donor axis)
  is drawn uniformly in $[0,2\pi)$.
- Otherwise $R$ is pre-multiplied by a random rotation about a random axis by an angle $\sim U(0,\pi)$ (orientation
  diversity).
- Branch-bend joints start at their current dihedral plus $U(-\pi,\pi)$. Angle bends start at 0.

---

## S12. Optimisation (`ik/ik_solver.py`)

All ligands and rows are optimised jointly for $T=200$ Adam steps (lr 0.1, $\beta=(0.9,0.999)$, $\epsilon=10^{-8}$) on

$$\mathcal L_b=-\mathcal S(X_b)+\mathcal C^{\text{shape}}_b+\mathcal C^{\text{sym}}_b.$$

### S12.1 Shape constraint
With $\hat d_s=\hat u(D_s-M)$ and the best rotation $R^*$ taking the assigned ideal vectors onto the donors:
$R^*=\arg\max_R\sum_s\hat d_s\cdot R\hat e_{\pi(s)}$ (Horn's quaternion method, no centring, computed without
gradient; the envelope theorem makes the gradient exact to first order).

$$x_s=\lVert R^*\hat e_{\pi(s)}-\hat d_s\rVert^2,\qquad
\Delta=\frac1\tau\Big(\operatorname{LSE}_s(\tau x_s)-\log n\Big),\ \tau=2,\qquad v=\max(0,\Delta-\Delta_{\text{tol}}).$$

$\Delta$ is a power-mean soft-max of the per-donor deviations: 0 for a perfect polyhedron, the mean for uniform
deviations, the maximum as $\tau\to\infty$.

The tolerance $\Delta_{\text{tol}}$ is the 90th percentile of $\Delta$ over the crystal data:

| geometry | $\Delta_{\text{tol}}$ |
|---|---|
| linear | 0.006 |
| square_plan | 0.017 |
| octahedral | 0.047 |
| square_pyr | 0.055 |
| trig_bipyr | 0.068 |
| trigonal | 0.070 |
| square_anti | 0.070 |
| tetrahedral | 0.083 |
| pent_bipyr | 0.100 |
| trig_pris | 0.120 |
| see_saw | 0.142 |
| any other | 0.060 |

Augmented Lagrangian: $\mathcal C^{\text{shape}}=\mu v+\tfrac\rho2v^2$ with $\rho=8$ and $\mu_0=10$. Dual ascent
$\mu\leftarrow\max(0,\mu+\rho v)$. $\mu$ is frozen permanently once $\max v-\min v<0.01$ over a 20-step window, so an
unreachable constraint cannot drive it without bound.

### S12.2 Symmetry ties
For each group $G$ of equivalent donors:
- **Distance tie.** $\mathrm{Var}_{s\in G}(d_s)$, averaged over groups.
- **Angle tie.** For groups within one ligand, $\mathrm{Var}_{s\in G}(\alpha_s)$ of the approach angle.

Each tie enters as its own augmented-Lagrangian term with $\rho=8$, zero tolerance, $\mu_0=2$ (distance) and $\mu_0=1$
(angle), and the same stall freeze.

### S12.3 Bidentate null space
For a ligand with exactly two donors, rotation about the donor–donor axis $\hat n$ changes nothing in the donor
geometry. The base-rotation gradient is projected with $(I-\hat n\hat n^\top)$.

### S12.4 Q3 mode commitment
For groups of equivalent donors with a multimodal Q3 fit, each row is committed at step 0 to the single component $k^*$
maximising the group's joint log-density. That keeps equivalent donors from splitting between modes. It has no effect
when S_orient replaces Q3.

### S12.5 Convergence and best snapshot
- **Convergence.** A row is *converged* if, at some check (every 8 steps), its score varied by less than 0.02 over the
  last 8 steps. There is no early stop.
- **Best snapshot.** For each row, $\theta$ is kept at its best-scoring step, where the score for this purpose is
  $\mathcal S-1000\cdot\sum r^2_{\text{seam}}$.

### S12.6 Row culling (successive halving with niches)
Only when $B\ge256$. At step $\lceil0.3T\rceil$ the batch is reduced to $k=\max(\lceil0.35B\rceil,16)$ rows by the key

$$\kappa_b=s_b-\frac{30\,(s_{(1)}-s_{(k)})}{k}\cdot\operatorname{rank}_b(\text{basin}),$$

- $s_b$ is the row's best score.
- $\operatorname{rank}_b$ is its rank among rows sharing a *basin signature*: the candidate index, plus the nearest Q5
  mode of every backbone torsion (torsions separating donors of one ligand), hashed.

The niche penalty keeps one basin from taking every surviving slot.

---

## S13. Ranking and output
- Macrocycle seams are closed exactly (S10.2), and the final score is recomputed with the $-1000\sum r^2$ seam term.
- The top $\max(16\,n_{\text{cand}},8)$ rows are assembled into complexes and sorted by score. The highest-scoring
  conformer is the prediction.
- **No force field, MLIP or relaxation acts on the complex at any point.**

---


### S13.x Ranking score and output (2026-09-28)
After the solve, every row is re-ranked (single thread) by `Scorer.ranking_score` at the fit-time floors:
$S_{\mathrm{rank}} = \frac{1}{Z}\sum_t \log p(y_t\mid \mathrm{key}_t)$ over all features (every Q6 pair's wall term,
every S_orient donor), with $Z$ one constant per complex (the number of internal features), instead of one mean per
quantity. Q1 mixture components with $\sigma > 0.10$ Å or a mean below 1.2 Å are dropped as the outlier share and the
remaining weights renormalised (a donor keeps its table if all components would go). The bend prior and ring-closure
terms of the final score are kept. The returned conformers are then deduplicated: the best-ranked member of each group
within 0.5 Å symmetry-aware heavy-atom RMSD (automorphisms of the bonded graph incl. coordination bonds).

## S14. Measurement (benchmarks only; never used by the solver)

**Energy.** For the best-scoring conformer $X$ and the reference $X^{\text{ref}}$ (same composition, charge and
multiplicity): $\Delta E=E_{\text{MACE}}(X)-E_{\text{MACE}}(X^{\text{ref}})$, as MACE-POLAR-1-M single points in
kJ mol⁻¹. The references are tmQM crystal structures or DOE DFT-optimised aqua ions.

A useful scale: a room-temperature snapshot of an $N$-atom molecule sits about $(3N-6)k_BT/2$ above its minimum
(≈ 310 kJ mol⁻¹ for $N=85$).

**Geometry.**
- $\max_s|d_s-d_s^{\text{ref}}|$ over mapped donors.
- The heavy-atom RMSD after Kabsch alignment on the mapped heavy atoms. It is not symmetry-corrected.

**Seed noise.** Each configuration is run at several solver seeds, and changes are judged per case against the
within-configuration seed spread (`tools/jdev/bench.paired_diff`).

---

## S15. Constants (defaults)

| where | constant | value |
|---|---|---|
| solve | beam width $W$ / Q1 samples $M$ / steps $T$ / lr | 16 / 8 / 200 / 0.1 |
| solve (v2) | `chelate_embed` / `orientation_model` / `angle_bends` / `embed_aware_dedup` | True / "auto" / False / True |
| bends (v2) | prior free zone / scale / $k$ in-sp2, in-sp3, out-sp2, out-sp3 (kJ/mol/rad²) | 2° / 1 / 1300, 1800, 310, 1100 |
| fit | $n_{\min}$ (Q1–Q6) / $K_{\max}$ GMM (Q1,Q4 / Q2,Q3) / $K_{\max}$ VMM | 30 / 4, 6 / 6 |
| fit | ancestor cap per (key, bucket) | 500 |
| QO (v2) | $n_{\min}$, $K_{\max}$, covariance floor, weight floor, H-bond cut, ring cap | 50, 4, 0.05², 0.05, 2.3 Å, 7 |
| score | variance floors Q1 / Q4 / Q2,Q3 | 0.04 Å² / 4 deg² / 0.0025 |
| score | Q6 soft-min temperature τ | 2 |
| score (v2) | Q7 free zone / width / weight | 2° / 5° / 1 |
| trans | trans threshold | cos < −0.766 (> 140°) |
| embed (v2) | $D_{\min}$, bite max, small ring, candidates, restraint $k$ | 2.4 Å, 100°, ≤ 6, 8, 100 |
| assignment | chelate max bite (repair) / reachability ($h\le4$: 55–115°, $h=5$: ≤ 150°) | 115° |
| enumeration | max candidates / time budget | 50 000 / 30 s |
| optimiser | $\rho$ / $\mu_0$ shape / $\mu_0$ sym dist / $\mu_0$ sym angle / stall window, tol | 8 / 10 / 2 / 1 / 20, 0.01 |
| optimiser | plateau window, tol / cull at, keep, niche, min rows, min batch | 8, 0.02 / 0.3, 0.35, 30, 16, 256 |
| macrocycle | closure damping / step clip / final GN iterations / seam weight | $10^{-4}$ / 0.5 rad / 4 / 1000 |

---

## S16. Known issues (open; found while writing this document)

1. **(Fixed 2026-09-28)** **Post-fit pooled Q6 keys are never looked up.**
   - The fitter writes the n-weighted (period group, X) walls under `repr((pg, x))`.
   - The lookup asks for `sorted((pg, x))`, which puts the element first. So it only ever finds the raw-pooled key
     fitted before them.
2. **(Fixed 2026-09-28)** **The beam's partial Q6 is inactive.** The engine passes `ge._q6_idx_pairs`, which does not exist. Beam seeds are
   ranked by Q5 alone.
3. **Quantity weights for Q1–Q5 act as additive constants.** They are $\log w$ inside the LSE, so they do not change
   the optimisation or the ranking. Only Q6 and S_orient are truly weighted.
4. **Minor inconsistencies.**
   - The Q4 docstring says "heavy" substituents, but H neighbours count.
   - `ladders.L0_ARITY` lists Q3/Q4 as 3 (unused).
   - The Kabsch pivot (a haptic face counted once) differs from the FK pivot (every haptic atom counted) for ligands
     that mix κ and haptic donors.

Fixed on 2026-09-25:
- **Symmetry dedup merged assignments that a fixed embed cannot interconvert** (intra-ligand equivalent-donor swaps
  and reflections; S9.4). VUCVUN, 3 solve + 3 embed seeds: no bends 709–1217 → 283–302 kJ/mol; with bends + energy
  prior 3463 → 175–194.

Fixed on 2026-09-24:
- **Q5 row / FK joint misalignment** in the beam search and the cull signature (S10.4).
- **The Q1 trans key** is now taken from the assignment instead of the arbitrary initial shell (S3).
