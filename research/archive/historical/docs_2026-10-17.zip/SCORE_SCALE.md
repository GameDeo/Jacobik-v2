# Score, energy scale and curvature: terms, findings, decisions (2026-10-16)

Owner request (10-16): formalise the terminology, separate the similar-sounding but different issues, and say which
past results stand, which are reinterpreted and which are discarded. Evidence: METHODOLOGY.md (10-15 study),
ENSEMBLES.md, CHANGELOG.md "2026-10-16 b", tools in `tools/jdev/budget/`.

## 1. Two scores, one `Scorer`

The solver optimises one function and ranks with another. Both come from the same class (`ik/scorer.py`) and the same
fitted tables, but five settings differ:

| setting | solve objective (what Adam follows) | ranking score (what orders the output) | since |
|---|---|---|---|
| variance floor | "scorer" floors: Q1 sd >= 0.2 A, Q2 / S_orient >= 0.05 in cos | "fit" floors: Q1 0.002 A, Q2 0.002 cos, i.e. the true fitted widths | 09-27 (B2.7 option B) |
| aggregation | per-quantity MEAN (each Q divided by its own count) | SUM of every term / one constant Z | 09-28 (RANK_AGG) |
| Q6 | soft-min over pairs (tau 2; one contact barely counts below ~4 nats) | sum of every pair's wall / Z | 09-28 |
| Q1 broad components | kept | components with sd > 0.10 A dropped (Q1_TAIL_SIGMA) | 09-28 |
| S_orient | log p / dim per donor | log p per donor (k = 3 donors weigh ~6x more) | 09-24 |

Why: true widths during the solve made it worse (09-27, picks 158 / 186 / 1029 vs 138), because needle-thin fitted
components make a rugged landscape the optimiser gets stuck in. The floors smooth it. Ranking with true widths and
summed terms picked better (top-1 36 -> 50 %). Each choice was right for its own job. The consequence, measured
10-16: **neither function has the energy's local stiffness, and they are wrong in opposite directions on Q1** (section 3).

## 2. Four properties of a term that are easy to confuse

| property | question it answers | measured by | status 10-16 |
|---|---|---|---|
| **position** (mode means) | is the preferred value right? | crystal-positioned statistics oracle (`--targets crystal`) | right enough: ~10 % of the problem-set error, no detectable change on the dev set |
| **well weights** (mixture structure) | which well is preferred, and by how much? | "kT per nat" BETWEEN conformers (METHODOLOGY 4.3), beam behaviour | Q5 ~1 kT/nat (good); Q1 / Q2 tables contain needle components |
| **local stiffness** (curvature inside a well) | how fast does the score fall off near the mode, vs the energy? | directional curvature (`forces.py`, E1) | wrong scale per term (section 3); directions right (spearman 0.6-0.7) |
| **tail** (far from every mode) | does a broken structure get vetoed? | gates (SHAPE tail caps FAIL), validity study | needed as is: capping it fails |

Plus **weight / aggregation**: how much a term counts against the others. It is not a property of the table but of
how the score combines terms (section 1). It changes the effective stiffness of every term.

"Matches the data" (position, well weights) and "matches the energy" (stiffness) are separate properties. A table can
be right on the first and wrong on the second (METHODOLOGY principle 2).

## 3. Local stiffness, measured (E1, 10-16)

Central differences along the solver's soft DOFs (per-ligand translations, rotations, rotatable bonds), at the crystal
and at the top-4 pool conformers, 80 dev complexes. Ratio = energy curvature / kT divided by score curvature
(1 = energy-like, < 1 = score too stiff, > 1 = too soft). Sums over directions:

| term (where it acts) | ranking score | solve objective |
|---|---|---|
| Q1 (translations) | ~0.06-0.15: ~7-17x too STIFF (needle components at fit floors) | ~4.5x too SOFT (0.2 A floor) |
| Q2 | ~0.25: ~4x too stiff | ~0.5-0.65: ~2x too stiff |
| S_orient | ~0.8-1.0: about right | ~0.3-0.45: ~2-3x too stiff |
| Q5 (torsions, alone) | 0.85 (crystal) / 0.73 (top-4): about right | 0.25 / 0.22: ~4x too stiff, from the mean aggregation, not from the tables |
| Q6 | ~3x too soft (walls are zero beyond the onset) | ~no curvature (soft-min) |
| fit with one scale per term | R^2 0.25 | R^2 0.52-0.58 (production weights: negative) |

Q5 reconciled. METHODOLOGY 4.3's "Q5 ~1 kT/nat" is a between-well, finite property: the log weights of the torsion
wells track the energy difference between wells (Boltzmann inversion works for populations). The curvature here is a
within-well property, and for Q5 in the ranking score it is also about right. Its ~0 weight in the joint NNLS fit
(first report) only meant Q5 acts on torsion directions alone; it did not mean Q5 lacks curvature (corrected).
**Superseded 2026-10-16 d (section 8):** on directions where Q5 carries >= 70 % of the score curvature, the energy
curvature is ~1/5 of the score's in both profiles. The averages above mix torsions sitting on broad wells (little Q5
curvature, energy dominated by sterics) with torsions in over-sharp wells (74 % of Q5 components are sharper than the
thermal torsion width); the thermal floor acts only on the latter.

Q1 reconciled with METHODOLOGY 4.3. 4.3 said the Gaussian cores are "too soft" (3-6 kT per nat for small Q1
changes). That number came from finite differences between solver outputs, confounded by co-varying terms (a caveat
4.3 itself states). The controlled directional curvature shows the ranking score's Q1 is too STIFF (needle
components) and the solve objective's Q1 is too SOFT (floor). **Discard "the cores are too soft" as a general
statement**; it holds for the solve objective's Q1 only.

## 4. Q6: what was designed, what was built, what was tested

| form | what it is | built | tested | result |
|---|---|---|---|---|
| wall, onset (0.1 %) | quadratic wall from the 0.1 % quantile | 10-01 | solver arms 10-14, 10-16 | worse (+52 kJ/mol): discarded |
| wall, 5th percentile | quadratic wall from the 5th percentile | legacy | production | kept (`_q6p5`) |
| WCA | R_core(r) only: generalised Weeks-Chandler-Andersen core on the wall's onset | 10-14 | solver arm 10-14, gates 10-15 / 10-16 | worse: discarded |
| **PMF** (`Q6_MODEL=pmf`) | **R_core(r) + data PMF w(r) + angular term for H-bonds**: GFN2 exponential core below the onset, -ln g(r) with a pooled reference above it, and for polar H facing an acceptor two tables by D-H...A angle (>= 120 deg "lin" / "bent") mixed by a sigmoid of the angle. `WELLS=hbond` keeps wells only for H-bonds | 10-14 | 10-case check (median 136 vs wall 121), gate on the refit pools (+8.6 [-0.5, +23], n.s., leaning worse) | **never run as a solver arm on the clean refit DB** |
| summed walls in the solve (`Q6_AGG=sum`) | the ranking's summed walls also in the solve | 10-13 | solver arm 10-16 | regret -14.5 [-29, -3], top-1 up; #1 n.s. Pending confirmation |

So the R_core + Angular design was implemented, as the PMF, but only for polar-H...acceptor pairs. A general
(r, theta) term for every contact was not built. The core-only alternative (WCA) failed and was dropped; the PMF was
never given its full test. The curvature result (Q6 ~3x too soft in the ranking, ~0 in the solve's soft-min) supports
stiffer, summed sterics, consistent with the Q6_AGG=sum gain.

## 5. Words that mean two things

| word | meaning A | meaning B | use from now on |
|---|---|---|---|
| floor | **pool floor**: lowest-energy conformer the solver returned | **variance floor**: minimum width a table component is scored with | always "pool floor" / "variance floor" |
| fold | **ring fold**: conformation of a ring (macrocycle folds from `_macro_pool` / macro joints; ring puckers of smaller rings frozen in the embed; `RING_KEEP_FOLDS` keeps puckers of rings holding a haptic face) | **rotor folding** (`Q5_FOLD`): torsion statistics folded by a rotor's symmetry (a methyl's 3 wells as one) | "ring fold / pucker" vs "rotor folding" |
| isomer | **coordination isomer**: donor -> site assignment (the enumeration) | **ligand-internal configuration**: stereocentres, E/Z, ring puckers inside a ligand, fixed by the embed | "isomer" = coordination only; the other is "internal configuration" (D6) |
| strain | SP minus the UNCONSTRAINED relaxation (everything a local relaxation removes: torsions + coordination + internals) | the "internals line" (constrained relaxations, METHODOLOGY 2) | "strain" = unconstrained; "internals line" = constrained |
| window | output score window (`OUT_WINDOW`, 200 summed nats) | CREST energy window (6 kcal/mol on relaxed energies) | say which |
| kT per nat | between conformers: finite score differences vs energy differences (METHODOLOGY 4.3) | local curvature ratio (section 3) | "between-conformer scale" vs "curvature ratio" |
| data | positions of modes | widths / stiffness / mixture structure | section 2 |

## 6. Ledger of past results

**Stands**
- 5th-percentile Q6 walls over onset walls.
- Rank with true widths, summed (`RANK_AGG=sum`, `Q1_TAIL_SIGMA`).
- MACE-fitted bend prior.
- Q5 between-well scale ~1 kT/nat, now also within-well in the ranking score.
- Error-budget method and the decision protocol (METHODOLOGY).
- Output score window (10-16).

**Reinterpreted**
- "Gaussian cores too soft" (4.3): true for the solve objective's Q1 only. The ranking score's Q1 / Q2 are too stiff
  (needle components).
- Why physically correct changes were neutral: the #1 error is mostly frozen internals (61 % of the problem set) and
  search failures (36 % residual). Score-shape changes act on the ~10 % data-position share plus a ~6 kJ/mol median
  regret, below the noise. Swapping one term's shape also changes its weight against terms whose scales are already
  off in opposite directions in the two scores.
- METHODOLOGY 4.6 refit priority 1 (Q1 / Q2 key resolution): moving the modes (positions) does not help the set.
  Width / mixture structure is the open part.

**Discarded**
- onset walls; WCA; SHAPE tail caps (exp); linear and pairwise term re-weighting of the ranking; GFN2-Hessian torsion
  widths (cost); the "closest reachable pose" oracle (poses clash).
- "Isomer choice of the reference is why changes look neutral" (forcing it: median unchanged).
- "Most returned conformers are snapshots of one basin" (60-80 % relax to distinct basins).
- "Q5 carries no curvature" (misread NNLS weight; corrected above).

**Open, in the order proposed**
1. D3 beam: choose modes by probability mass, not peak density; metal-aware seeds.
2. D6 internal configuration: stereocentres, E/Z, ring folds (rule: user-specified stereo is kept as given; only
   unspecified centres / bonds are enumerated, e.g. RDKit `EnumerateStereoisomers(onlyUnassigned=True)`; tmQM SMILES
   carry none, so the benchmark exercises the enumeration).
3. E1 change: rebalance the solve objective per term to the fitted curvature scales (solve only, ranking unchanged).
4. Q1 / Q2 needle components: a minimum component width near the physical stiffness (refit level, gate first).
5. Metal 1-3 walls (Q6 class for M-D-X contacts).
6. Q6_AGG=sum confirmation and the PMF solver arm.
7. Boltzmann / basin mode, once rho_basin is above the noise.

## 7. Every setting, where it lives (2026-10-16)

Every result-changing setting is a field of `src/jacobik/profile.py`. `JACOBIK_PROFILE` selects the profile (`legacy-2026-10`, the values below and the default; `u1`, section 8, under test); `JACOBIK_PROFILE_OVERRIDES` (JSON, field -> value) overrides single fields, e.g. `JACOBIK_PROFILE_OVERRIDES='{"q6_agg": "sum"}'`. Modules read their field once at import (`profile.get`); `profile.snapshot()` reports the live module attributes, and every result records it as `profile`.

### 7.1 Profile fields

**score**

| field | module.attribute | legacy value | meaning |
|---|---|---|---|
| `score_agg` | `jacobik.ik.scorer.SCORE_AGG` | `mean` | solve objective: 'mean' = per-quantity means, 'sum' = summed log-likelihood / Z |
| `rank_agg` | `jacobik.ik.scorer.RANK_AGG` | `sum` | ranking score aggregation ('sum' or 'mean') |
| `solve_floor` | `jacobik.ik.scorer.GMM_FLOOR_MODE` | `scorer` | variance floor in the solve: 'scorer' (Q1 sd 0.2 A, Q2/Q3 0.05 cos, Q4 2 deg), 'fit', or 'thermal' (298 K widths, section 8) |
| `rank_floor_fit` | `jacobik.ik.ik_solver._RANK_FLOOR` | `true` | rank with the fit-time floors (true widths) |
| `q1_tail_sigma` | `jacobik.ik.scorer.Q1_TAIL_SIGMA` | `0.1` | ranking drops Q1 components broader than this (A); 0 = keep all |
| `q1_wall` | `jacobik.ik.scorer.Q1_WALL` | `true` | one-sided Q1 wall beyond the table's support |
| `q5_fold` | `jacobik.ik.scorer.Q5_FOLD_MODE` | `auto` | rotor folding of Q5 densities: auto / 1 / 0 |
| `q6_model` | `jacobik.ik.scorer.Q6_MODEL` | `wall` | steric model: 'wall' or 'pmf' |
| `q6_agg` | `jacobik.ik.scorer.Q6_AGG` | `softmin` | steric term in a mean-aggregated solve: 'softmin' or 'sum' |
| `q6_pmf_wells` | `jacobik.stats.q6pmf.PMF_WELLS` | `hbond` | PMF wells kept: 'hbond' or 'all' |
| `haptic_per_sub` | `jacobik.ik.scorer.HAPTIC_PER_SUB` | `true` | haptic S_orient per substituent |
| `bend_per_z` | `jacobik.ik.ik_solver._BEND_PER_Z` | `false` | bend prior divided by the score's per-complex constant Z (section 8) |

**embed**

| field | module.attribute | legacy value | meaning |
|---|---|---|---|
| `embed` | `jacobik.engine.DEFAULT_EMBED` | `gfn2` | free-ligand embed refinement: gfn2 / mmff / etkdg |
| `chelate_ez` | `jacobik.chelate_embed.CHELATE_EZ` | `true` | chelate embed fixes E/Z between donors |
| `carbene_ylide` | `jacobik.chelate_embed.CARBENE_YLIDE` | `true` | carbene donors embedded as ylides |
| `eta2_cap` | `jacobik.chelate_embed.ETA2_CAP` | `false` | temporary cap on eta2 donors in the embed |

**degrees of freedom**

| field | module.attribute | legacy value | meaning |
|---|---|---|---|
| `branch_bends` | `jacobik.ik.fk.BRANCH_BENDS` | `true` | bend DOFs on branch junctions |
| `branch_prior` | `jacobik.ik.fk.BRANCH_PRIOR` | `false` | prior on branch bends |
| `ring_open_adj` | `jacobik.ik.fk._SMALL_RING_OPEN_ADJ` | `true` | small donor rings opened next to the joint |
| `ring_joints` | `jacobik.topology.decompose.RING_JOINTS` | `true` | small donor rings as torsion joints |
| `donor_bends` | `jacobik.ik.angle_bends.DONOR_BENDS` | `false` | S_orient-priced bends of donor branches |
| `haptic_bends` | `jacobik.ik.angle_bends.HAPTIC_BENDS` | `true` | bends at haptic faces |
| `haptic_free_lean_max` | `jacobik.ik.angle_bends.HAPTIC_FREE_LEAN_MAX` | `6` | haptic faces whose lean is statistics-priced |
| `haptic_lean_wall` | `jacobik.ik.angle_bends.HAPTIC_LEAN_WALL` | `true` | wall on haptic lean |
| `local_plane_deg` | `jacobik.ik.angle_bends.LOCAL_PLANE_DEG` | `20.0` | planarity tolerance for bend typing (deg) |

**output**

| field | module.attribute | legacy value | meaning |
|---|---|---|---|
| `out_dedup` | `jacobik.ik.dedup.OUT_DEDUP` | `true` | symmetry-aware RMSD dedup of the output |
| `dedup_rmsd` | `jacobik.ik.dedup.DEDUP_RMSD` | `0.5` | dedup threshold (A, heavy atoms + metal) |
| `out_window` | `jacobik.engine.OUT_WINDOW` | `200.0` | output score window (summed nats); 0 = off |

### 7.2 Retired switches

Setting any of these environment variables raises a RuntimeError (benchmark arms pass environment variables to worker processes, so a silent no-op would hide a wrong arm). Use the override form.

| environment variable | replacement |
|---|---|
| `JACOBIK_SCORE_AGG` | field `score_agg` |
| `JACOBIK_RANK_AGG` | field `rank_agg` |
| `JACOBIK_GMM_FLOOR` | field `solve_floor` |
| `JACOBIK_RANK_FLOOR` | field `rank_floor_fit` |
| `JACOBIK_Q1_TAIL_SIGMA` | field `q1_tail_sigma` |
| `JACOBIK_Q1_WALL` | field `q1_wall` |
| `JACOBIK_Q5_FOLD` | field `q5_fold` |
| `JACOBIK_Q6_MODEL` | field `q6_model` |
| `JACOBIK_Q6_AGG` | field `q6_agg` |
| `JACOBIK_Q6_PMF_WELLS` | field `q6_pmf_wells` |
| `JACOBIK_HAPTIC_PER_SUB` | field `haptic_per_sub` |
| `JACOBIK_EMBED` | field `embed` |
| `JACOBIK_CHELATE_EZ` | field `chelate_ez` |
| `JACOBIK_CARBENE_YLIDE` | field `carbene_ylide` |
| `JACOBIK_ETA2_CAP` | field `eta2_cap` |
| `JACOBIK_BRANCH_BENDS` | field `branch_bends` |
| `JACOBIK_BRANCH_PRIOR` | field `branch_prior` |
| `JACOBIK_RING_OPEN_ADJ` | field `ring_open_adj` |
| `JACOBIK_RING_JOINTS` | field `ring_joints` |
| `JACOBIK_DONOR_BENDS` | field `donor_bends` |
| `JACOBIK_HAPTIC_BENDS` | field `haptic_bends` |
| `JACOBIK_HAPTIC_FREE_LEAN_MAX` | field `haptic_free_lean_max` |
| `JACOBIK_HAPTIC_LEAN_WALL` | field `haptic_lean_wall` |
| `JACOBIK_LOCAL_PLANE_DEG` | field `local_plane_deg` |
| `JACOBIK_OUT_DEDUP` | field `out_dedup` |
| `JACOBIK_DEDUP_RMSD` | field `dedup_rmsd` |
| `JACOBIK_OUT_WINDOW` | field `out_window` |
| `JACOBIK_Q6_WCA_N` | removed (variant deleted 2026-10-16) |
| `JACOBIK_Q6_WCA_T` | removed (variant deleted 2026-10-16) |
| `JACOBIK_SHAPE_CORE` | removed (variant deleted 2026-10-16) |
| `JACOBIK_SHAPE_TAIL` | removed (variant deleted 2026-10-16) |
| `JACOBIK_SHAPE_TAIL_FORM` | removed (variant deleted 2026-10-16) |
| `JACOBIK_SHAPE_TERMS` | removed (variant deleted 2026-10-16) |
| `JACOBIK_Q5_TEMPER` | removed (variant deleted 2026-10-16) |
| `JACOBIK_RING_LEAN` | removed (variant deleted 2026-10-16) |
| `JACOBIK_RING_KEEP_FOLDS` | removed (variant deleted 2026-10-16) |
| `JACOBIK_CARBON_STRUCTURAL` | frozen label (no switch) |
| `JACOBIK_RESONANCE_LABELS` | frozen label (no switch) |
| `JACOBIK_HAPTIC_V2` | frozen label (no switch) |
| `JACOBIK_SHAPE_LABELS` | frozen label (no switch) |
| `JACOBIK_Q6_METAL_EXCL` | frozen label (no switch) |
| `JACOBIK_Q6_THROUGH_METAL` | frozen label (no switch) |

### 7.3 Execution-only environment variables

Not profile fields: they do not change results beyond the float path.

- `JACOBIK_GPU_REPLAY`, `JACOBIK_GPU_FAST_FK`: CUDA-graph replay / batched kinematics (0 = eager / per-ligand).
- `JACOBIK_NUM_WORKERS`, `JACOBIK_WORKER_MODE`: solver worker processes.
- `JACOBIK_DEDUP_DEVICE`: device of the output dedup arithmetic.
- `JACOBIK_MACE_*`: MACE model path, batch size, device.
- `JACOBIK_XTB`: path of the GFN2 embed refinement binary.
- `JACOBIK_TEST_DB`, `JACOBIK_DB`: constraint database for tests / runs.
- `JACOBIK_BUDGET_*`: budget experiments (tools/jdev/budget).

### 7.4 Module constants that change results but are not profile fields yet

| constant | file:line | value | role |
|---|---|---|---|
| `CLASS_BUDGET` | `engine.py:819` | `"split"` | how variants of one assignment class share the row budget (`split` / `early_cull` / `none`) |
| `EARLY_CULL_AT` | `engine.py:820` | 0.05 | step fraction of the extra cull when `CLASS_BUDGET = "early_cull"` |
| `_PLATEAU_WINDOW` | `ik/ik_solver.py:57` | 8 | steps over which the score range is tested for convergence |
| `_PLATEAU_ATOL` | `ik/ik_solver.py:58` | 0.02 | score range below which the solve counts as converged |
| `_LSE_TEMP` | `ik/ik_solver.py:64` | 2.0 | power-mean temperature of the per-donor shape deviation |
| `_CULL_MIN_ROWS` | `ik/ik_solver.py:83` | 16 | rows never culled below |
| `_CULL_NICHE` | `ik/ik_solver.py:84` | 30.0 | per-basin rank penalty of the cull (0 = plain top-k) |
| `_CULL_MIN_BATCH` | `ik/ik_solver.py:85` | 256 | culling only at or above this many rows |
| `_Q6_LSE_TEMP` | `ik/scorer.py:141` | 2.0 | soft-min temperature of the Q6 per-pair penalties |
| `_GMM_VAR_MIN` | `ik/scorer.py:41` | Q1 0.04, Q4 4.00, Q2 / Q3 0.0025 | variance floor of the GMM terms in the solve (`solve_floor = scorer`); replaced by the measured thermal widths under `solve_floor = thermal` (section 8) |
| `SHAPE_TOL_P90` | `ik/targets.py:44` | linear 0.006 ... see_saw 0.142 (11 polyhedra) | p90 shape tolerance per polyhedron |

## 8. Thermal widths and the unified objective `u1` (2026-10-16 d, plan U1 / U2)

**Why a floor, and why this one.** A fitted table component can be far narrower than any one molecule's motion: tmQM
holds minima, and a cluster of near-identical minima (one ligand family in many crystals) fits a needle (sd 0.002-0.02
A). Scored literally, a needle makes the score far stiffer than the energy (the 7-17x of section 3); the old answer, a
0.2 A floor in the solve, has no reason behind its value. The physical lower bound is the width one molecule actually
has at 298 K: sigma_T^2 = kT g^T H^+ g, the variance of the feature in the harmonic Boltzmann distribution of its own
minimum (g = gradient of the feature, H^+ = pseudo-inverse of the Hessian, every other coordinate relaxing).

**Measured once, offline**, on 300 tmQM training complexes (100 per metal row, holdout excluded) with GFN2 Hessians at
the tmQM geometries (GFN2 minima, so the Hessian is taken at a stationary point of the same method):
`refit/thermal_widths.py sample | hess | sigma | fit` -> `data/refit/final/thermal_widths.json`. Model parameters,
like `BEND_K`: nothing is computed during a solve.

| floor | value | where |
|---|---|---|
| Q1 by donor element | C 0.041, P 0.053, eta 0.057, Cl 0.058, O 0.060, I 0.060, Br 0.065, S 0.069, N 0.071 A (else 0.059) | `scorer.THERMAL_Q1_BY_DONOR` |
| Q2 (D-M-D) | 4.9 deg as an angle; in cos at the component mean: Var = sin^2 s^2 + cos^2 s^4 / 2 | `scorer.THERMAL_SD["Q2"]` |
| S_orient (kappa), Q3 | 4.2 deg, same conversion; covariance floored in the Loewner order (C >= diag(floor^2)) | `scorer.THERMAL_SD["SO"]` |
| Q4 (no S_orient tables) | 4.2 deg | `scorer.THERMAL_SD["Q4"]` |
| Q5 (torsions) | 13.8 deg: von Mises kappa <= 1 / sigma_T^2 = 17.3 (bond class moves it < sqrt 2) | `scorer.THERMAL_SD["Q5"]` |
| haptic S_orient | not floored (features not measured) | |

Metal row and coordination number move the widths by less than 10 %; donor element by a factor 1.7 (M-C stiffest). Q5 was first left out (section 3's "Q5 alone ~1"); the per-term read of the u1 check showed Q5 5x too stiff in both profiles (the section 3 number came from NNLS scales confounded by correlated terms), and 74 % of its wells are sharper than thermal.
About half of the Q1 / Q2 table components are narrower than their thermal width.

**Profile `u1`: one objective for the solve and the ranking.** S = (sum over every feature of log p, floored at the
thermal widths; S_orient summed; Q6 walls summed; bend prior as log-probability) / Z. Fields: `score_agg = rank_agg =
sum`, `solve_floor = thermal`, `rank_floor_fit = false`, `q1_tail_sigma = 0`, `bend_per_z = true`. Z (number of
internal features) is one per-complex constant: it changes no argmax and keeps the Adam step and plateau tolerance on
the old scale. Under legacy the bend prior is added raw to a summed / Z score, i.e. weighted Z times its
log-probability. Offline checks and the solver arm: CHANGELOG 2026-10-16 d.
