# src changelog

One line per change: date, what, why, how it was validated. Newest first. (Started 2026-09-23; entries
before that are reconstructed from the project notes.)

## 2026-10-17 d (cleanup review: correctness findings, triaged; none applied yet where results would change)
A read-only review of `src/` and `refit/` (cleanup P2 A3). Findings that would change results go through the
evidence workflow; the others are cleanup work.

**1. Oxidation state of carbene complexes (CONFIRMED on dev80; result-changing).**
- **Defect:** `core/oxidation.ligand_ionic_charge` adds `formal_charge - n_radical_electrons` per atom. An L-type
  carbene written `[C]` (two radical electrons) counts -2 instead of 0.
- **Training labels:** `os_from_smiles` takes the metal's bracket charge.
- **dev80 measured (`ComplexBuilder` deduces the OS; the benchmark never passes one):** the deduced OS differs from
  the training label in 13 of 80 complexes:
  - carbenes +2 too high: LEVVUH Ir 3 -> 5, XEMJUY / AFANAY / SEJXIQ Pd 2 -> 4, IGUWAI Ru 2 -> 4, XIYZIS Au 1 -> 3,
    ESOVIU Ag 1 -> 3, YIYXEJ Fe 2 -> 4;
  - haptic -> unknown (99): XINMOA, TALRIH, EHUZAI;
  - other: KIQYEQ Cu -1 -> 1, ZEXDOV Fe 2 -> 1.
- **Consequence:** their Q1 keys (and OS-keyed levels) use the wrong oxidation state or the metal-only fallback.
  YIYXEJ's stretched Fe-carbene bond may be this.
- **Fix to test:** count a two-electron radical carbon as 0, matching the training labels. Validate the deduction
  itself first: agreement with the training label over training complexes, before / after. Then gate and arm.

**2. A failed GFN2 embed is cached (result-changing only on failure).** `engine._gfn2_refine` caches its fallback
(the MMFF geometry) after a failure: one transient xtb failure (timeout under load, missing xtbopt.xyz) keeps the
process on the MMFF embed. Nothing records which embed was used.
- Fix: no caching on failure; record `embed_used` per result.
- Also seen in the cleanup: without xtb on PATH every solve silently uses MMFF (the worktree agents' false golden
  differences).

**3. Silent fallbacks (results change only for mismatched input).**
- `engine._order_sites_like_donor_groups` only warns when the classifier's sites do not match the donor groups (the
  docstring's own Cp*Fe(dppe)X failure mode).
- Scorer stats-lookup failures become hard-coded broad priors with a WARNING (Q1 2.1 A, Q5 flat, ...).
- `stats._fallback_q6` / `_resolve` fall back silently.
- The benchmark input mapper falls back to element-only matching (the QOSGIP mode).
- Proposal: count fallbacks per solve and expose them; a `strict` setting raises.

**4. Smaller:**
- `engine`: `"[H" in smiles` also matches `[Hg] / [Hf] / [Ho]`; with a real explicit [H] the donor indices shift
  (MolFromSmiles removes H).
- `refit_lib.merge_shards`: the Q6 re-cap over per-shard reservoirs over-represents small shards (affects the
  quantiles of the legacy walls only).
- `ik_solver` / `solver_replay`: `_SC_MODE` is an import-time copy (only matters if an experiment sets the scorer
  global directly).
- `angle_bends`: the eta7 / eta8 lean free zones exist but are gated off (`HAPTIC_FREE_LEAN_MAX` 6).
- Q1 / Q3 / Q4 padded mixture components are not made inert (Q2 / Q5 are).

**Checked and found correct** (reviewer's list): solver threading and copies; every cache key; the profile mechanism;
scorer maths (VMM / t normalisers, walls, floors, S_orient and haptic features vs the extractor); q6pmf binning,
angle classes, `rep_energy` continuity; beam layout; fit weights, BIC, EM; benchmark-code exclusion in every
quantity and histogram; thermal-width units; embed stereo / capping / surrogate mapping; dedup automorphisms.

**Side finding (cleanup P2):** the QG / QP geometry and partition priors are fitted by the refit but read by nothing
at runtime (their accessors had no caller and were deleted). The fit is kept; whether to use or drop them is open.

## 2026-10-17 c (plan 3 rev. b, branch N: Q6 = physical repulsion, NCI = statistical attraction)
Owner decision (supersedes the calibration proposal in 10-17 b): Q6 becomes a purely repulsive physical term; a new
statistical term ("NCI") carries noncovalent attractions (H-bonds first; agostic, pi-stacking, CH-pi, halogen bonds
where a census shows them missing). Ownership rule: each pair distance above its 0.1 % onset is priced by one term;
the core below the onset is shared.
- **u1c baseline (u1 = contact Q6 + E/Z + surrogate + lean; dev80 x 3 seeds, MACE float64; `etkdg_u1_contact`):**
  #1 median / mean 72.0 / 101.7, floor 60.0 / 81.4, regret 7.8 / 20.4. vs u1+lean+contact: #1 -4.3 [-13.0, +2.1],
  floor -4.4 [-11.0, +0.2] (SOKVET 372 -> 208 E/Z, KIQYEQ 419 -> 140 surrogate). PEWBOL 256 -> 337 and XIPLUD
  184 -> 242 at an unchanged floor (ranking among the E/Z-enlarged pools; to watch in N1 / N2).
- **Measured for the design (crystal histograms, all splits, class 5):** the physical contact distance (Alvarez 2013
  vdW sums) lies inside the walls' 5th percentile (C...H 2.97 vs 3.17 A, H...H 2.40 vs 2.68, C...C 3.54 vs 3.61);
  2.4-3.8 % of class-5 crystal pairs are inside it; mean physical repulsion 0.002-0.006 kT per pair (GFN2 A, b), i.e.
  ~5-10 kT per near-crystal complex (walls 9.2, PMF 37.8). The 13 most frequent element pairs cover 95 % of class-5
  pairs within 4 A; 6 of them have GFN2 parameters now.
- **N1 design (written before code):** class-5 non-polar pairs: U(r) = A [e^(-b r) - e^(-b r_m) + b e^(-b r_m)
  (r - r_m)] / RT below r_m = R_i + R_j (Alvarez), 0 beyond (zero value and force at r_m), linear above 50 kT; class 4
  / metal / polar-H pairs keep the contact form (core below the onset; polar-H wells until N2). A, b: per-element
  GFN2-xTB parameters with the Buckingham combination rule (A_ij = sqrt(A_i A_j), b_ij = (b_i + b_j) / 2), fitted
  JOINTLY to dimer interaction energies summed over all atom pairs (a head-on scan of hydride probes also contains
  the H...X pairs, which the scorer counts separately); the existing 8 head-on values are the comparison.
- **N1 predictions:**
  - check 1 (pressure): near-crystal Q6 sum <= 10 kT per complex; 0.7 A rigid pull-off gain <= walls (+0.4 to +2.3);
  - check 2 (curvature): Q6 energy/score 0.7-1.5; Q5 ratio 1.82 -> <= 1.3 (uncertain: the repulsion acts inside the
    walls' range; if Q5 stays > 1.5 the missing stiffness is contact attraction or Q5's width: N1b / S4, not a
    stiffer Q6);
  - check 3 (gate vs u1c pools): no FAIL, -2 to -5; DEVFUG / TACZUT to the better pick; class-4 variant (full
    repulsion also on 1-5 pairs) measured alongside, kept only if better;
  - arm vs u1c: #1 mean -6 to -12, regret median / mean <= 6.0 / 14 (u1c 7.8 / 20.4), DEVFUG <= 140, TACZUT <= 180, YOMGUC
    <= 230, XAQRUC <= 300, PEWBOL <= 340 (no worse), no expansion signature. Adopt: #1 / floor CI upper <= +5,
    regret not worse. Falsifier: CI excluding 0 on the worse side, expansion signature, curvature out of range.

- **N1 code in (default off):**
  - **Mode:** `q6pmf` `PMF_WELLS="repulsive"` (`rep_pair_params`, `rep_energy`, per-pair tensors in `build_runtime`);
  - **Profile fields:** `q6_pmf_wells` gains "repulsive"; new field `q6_rep_class4`;
  - **Test:** `test_q6_repulsive_form`.
  - **Parameters from the new tool `tools/jdev/budget/gfn2_dimer_scan.py`:**
    - 17 probes without polar H, 14 688 GFN2 dimers at 0.70-1.15 x r_m;
    - per-element repulsion plus damped C6 fitted jointly over all atom pairs (the first fit without dispersion
      degenerated: B / Br / I / Se A ~ 1e8);
    - fit R^2 0.94, Spearman 0.93 on repulsive configurations, median predicted / observed 0.93;
    - b at its 2.5 / A bound for B, N, O, P, S, Si;
    - output `data/refit/q6rep/`.
  - **Physics finding:** at 0.88-1.15 x r_m GFN2 dimers are net attractive (median -1 to -3 kJ/mol), the repulsion
    part alone is 7 -> 0.5 kJ/mol. Repulsion-only is mild in the flank by construction.
- **S2 code in (default off):**
  - **Fit tool `refit/bvs_fit.py`:**
    - R0 ladder (metal, el) -> (period-group, el) -> (el): 444 entries;
    - V levels (metal, OS) -> (period-group, OS) -> (metal): 124, of which 21 with c = 0;
    - derived DB `constraints_refit_q6p5_bvs.json` + meta "extends"; report `data/refit/bvs/fit_report.txt`.
  - **Scorer:** component "QV" = -c / 2 (V / ref - mu)^2 / Z, one per complex, sigma-only complexes
    (`scorer._bvs_runtime`); profile field `bvs`; `StatsLookup.bvs_tables`; test `test_bvs_runtime_ladder_and_term`.
  - **Strength by metal** (nats at a 10 % V / OS deviation):
    - lanthanides 1.8-2.6, Ti(IV) 0.87, Zr(IV) 0.52;
    - Ni / Zn / Pd(II) 0.3, Cu(I) 0.14, Ta(V) 0.12;
    - Pt(II), Re(I), Fe(II), Ru(II) ~0.
  - **Correction to the plan's expectation:** S2 cannot rescue XAQRUC by itself. Its stretch costs ~0.3 nats, and its
    pool spans -1.3 to -2.2 nats under QV; VUJYEG's pool spans -0.3 to -4.1. Revised S2 prediction: -0.5 to -2 mean;
    the gain is tail protection for early metals and lanthanides.
  - **S2 gate prediction (written before the run; base = u1 with the repulsive Q6, pools `etkdg_u1_rep`):** no FAIL,
    about 0 to -1 kJ/mol; changes only on early-metal / Zn / Ni / Pd / lanthanide pools (Fe / Ru / Pt / Re: c ~ 0,
    no change by construction).

- **N1 check 1 (pressure) PASSED** (walls arm #1 of 80 complexes, seed 11; Q6 raw kT, and the gain in log p when
  every ligand moves rigidly 0.7 A off the metal):

  | form | Q6 at #1, mean | Q6 at #1, p90 | pull-off gain, mean | max | pools > +1 |
  |---|---|---|---|---|---|
  | walls | 9.16 | 21.6 | +1.40 | +11.7 | 34 |
  | contact | -0.15 | — | -0.06 | — | — |
  | repulsive | 0.82 | 3.3 | +0.54 | +6.3 (CBTYCO) | 19 |
  | repulsive + class 4 | 1.76 | — | +0.54 | — | — |

  Class 4 does not move under rigid ligand moves, as expected. No pressure; the repulsive form carries ~1/10 of the
  walls' near-crystal penalty.
- **N1 check 2 (curvature) PASSED** (`forces.py`, cached directions, 80 complexes; per-term energy/score on
  directions that term dominates, pool / crystal):

  | form | Q1 | Q2 | Q3 | Q5 | Q6 | torsion directions (median) | Spearman | kS <= 0 |
  |---|---|---|---|---|---|---|---|---|
  | contact (u1c) | 1.43 / 1.64 | 1.28 / 1.86 | 1.41 / 1.57 | 1.82 / 1.52 | 0.72 / 0.92 | 1.46 / 1.69 | 0.83 / 0.80 | 0.03 / 0.09 |
  | repulsive | 1.36 / 1.49 | 1.00 / 1.87 | 1.03 / 0.96 | 1.09 / 0.93 | 1.45 / 1.50 | 1.25 / 1.26 | 0.87 / 0.84 | 0.01 / 0.05 |
  | repulsive + class 4 | 1.35 / 1.49 | 1.05 / 1.78 | 1.15 / 0.99 | 1.08 / 0.86 | 1.46 / 1.35 | 1.19 / 1.19 | 0.87 / 0.83 | 0.01 / 0.05 |

  - **Predictions met:** Q5 <= 1.3 (1.09 / 0.93) and Q6 within 0.7-1.5.
  - **At the edge:** Q6 sits at the soft end of its range, and the Q5 / Q6 exchange rate is 1.33 (target <= 1.3; was
    2.5).
  - **Still soft:** Q2 at the crystal (1.87) and Q1 (1.4-1.5) are unchanged by Q6; that is not Q6's to fix.
  - **Class 4:** slightly better on torsions (1.19 vs 1.25), decided by the gate.
- **N2a NCI census -- first run SUPERSEDED (pair-rule bug, below; corrected run follows)**
  (`tools/jdev/budget/nci_census.py`, `<OUT>/nci_census.{csv,txt}`; dev80 crystals vs the u1c #1,
  seed 11; 3000 training crystals of tmQM X1):

  | type | dev80 crystals with it | of those, the #1 misses it | training share | admitted |
  |---|---|---|---|---|
  | H-bond | 3 (CBTYCO, YIYXEJ, PEWBOL) | 0 | 5.5 % | yes (training share) |
  | agostic | 2 | 1 | 2.2 % | **no** |
  | pi-pi | 6 | 4 | 10.3 % | yes |
  | CH-pi | 11 | 8 | 29.6 % | yes |
  | halogen bond | 0 | — | 0 % | no |

  - The misses include JEFJUZ (#1 335, a u1 regression: its pi-stack and one of two CH-pi missing), ETAXEC (123:
    both), SOKVET (208) and FETSUU (109, CH-pi).
  - PEWBOL's pick has all 8 crystal H-bonds at 337 kJ/mol: its remaining error is not H-bond count.
  - **N2 v1 is therefore H-bond + pi-pi + CH-pi; agostic is dropped** (the plan had expected it to pass).
- **N2 code in (default off):** NEW `src/jacobik/stats/nci.py`.
  - **Candidates:** topology only, so extraction and runtime agree. sp2 5- / 6-rings = ring atoms with <= 3 ligand
    neighbours; class-5 pairs only.
  - **Features:** torch, differentiable; ring normal = normalised sum of consecutive cross products.
  - **Tables:** s = ln g, with g = crystal density / random placement (r^2 sin angle), normalised to 1 in a shell
    beyond the interaction range; counts and volumes smoothed with the same 3x3 kernel; pseudo-count 5;
    clip +-4; cos^2 taper. The unit test caught counts-only smoothing making a +0.5 edge artefact.
  - **Ladder:** H-bond (donor el, acceptor el) -> (*, acceptor el) -> (*, *); pi-pi and CH-pi pooled.
  - **Wiring:**
    - scorer component "NCI" (summed, / Z); profile field `nci`; with it on, the contact / repulsive Q6 drops its
      polar-H wells (core only);
    - `StatsLookup.nci_tables`;
    - NEW `refit/nci_hist.py` (hist over the refit's training shards, 118 ms/mol; fit -> derived `<db>_nci.json`
      with meta "extends");
    - test `test_nci_features_reference_and_taper`.
- **N1 check 3, gate (repulsive vs contact, u1c pools, 79 complexes / 237 pools, MACE float64): -1.71 [-4.86,
  +1.55]**: no FAIL, no detectable change.
  - **Counts:** better / worse 17 / 9; top-1 0.397 -> 0.435; pick median 74.1 -> 72.6.
  - **Prediction -2 to -5:** the direction is met, the size is at the low end.
  - **Gains:** XIPLUD 219 -> 170, YAVFEG 376 -> 332, PEWBOL 337 -> 306, ETAXEC 124 -> 94, XAXGOW 111 -> 87, YOMGUC
    264 -> 248.
  - **Losses:** KIQYEQ 185 -> 269 (the Cu-B case again), XAQRUC 523 -> 547, XEMJUY / TEDTIG / NAYPUC +15-17.
  - **Missed: "DEVFUG / TACZUT flip to the better pick"** (DEVFUG 169 -> 169, TACZUT 215 -> 211). Their losses under
    contact are not fixed by re-ranking; in their u1c pools the better structures may be missing (search), to check
    in the arm.
  - **Class-4 variant (full repulsion also on 1-5 pairs): -1.32 [-4.35, +1.88]**, better / worse 18 / 11, top-1
    0.418: slightly worse than without it (-1.71, top-1 0.435).
    - It differs from the plain repulsive form on 17 complexes, mean +0.4: ETAXEC +20, LAKDUW +18, OVODUZ +11;
      NAYPUC -10, TEDTIG -8.
    - **Not kept:** class 4 stays core only. Curvature was marginally better (torsions 1.19 vs 1.25), the gate
      marginally worse, both within noise; the simpler form without double counting wins the tie.
    - This was the first gate run with the cached scorers: no base re-score mismatch in 237 pools.
  - The arm (u1c+rep, class 4 off) was launched before this gate finished (owner decision, to use the idle GPU).
- **S2 gate (bond valence on top of the adopted repulsive Q6, pools `etkdg_u1_rep`, MACE float64): FAIL (ranks
  worse).**
  - **Result:** #1 +0.49 [+0.02, +1.18], better / worse 0 / 2, top-1 0.511 -> 0.485. Only 11 of 237 pools change
    pick: NAYPUC +11 / +15 / +22 and CUWMEP +19 / +19 / +16 in every seed, XAXGOW s11 +10, EBUXAE mixed
    (-8 / +12 / +5), TACZUT s13 -4.
  - **Prediction:** about 0 to -1, no FAIL. Missed.
  - **Decision:** S2 stops here, no arm. The owner's condition was "build it for correctness if gate and arm are
    good". **Owner: keep it as an off-by-default module, not deleted.**
  - **Diagnosis:**
    - **The term is calibrated.** On the 51 dev80 crystals it applies to, crystal QV averages -0.31 nats (a correct
      reference ratio gives -0.35), median crystal x - mu +0.014; only 5 crystals below -1 nat.
    - **The failure is pool-limited.** Where it flips a pick, it flips TOWARD the crystal's bond valence onto a
      conformer strained elsewhere:
      - NAYPUC: x 1.33 -> 1.12 (crystal 1.10), Q2 -0.8, Q5 -0.8; MACE 62 -> 73;
      - CUWMEP: x 0.70 -> 0.99 (crystal 1.13), Q2 -2.4, Q3 -1.3, Q6 -1.6; MACE 105 -> 124.
      A correct partial preference on fixed pools picks "right in one respect, worse in three"; only the solve
      (an arm) could make conformers that satisfy both.
    - **Weaknesses:**
      - R0 per (metal, donor element) pools geometries and spin states (Ni(II) square-planar and octahedral 4 + 2:
        training spread 0.105, dev80 crystals 0.156);
      - meaningless for pi-acceptor C donors (EBUXAE Cu(I) isocyanides: crystal x 1.48, the whole pool at -7.5).
  - **Future test (owner: noted, not now):** R0 and levels keyed by coordination number and spin, pi-acceptor C donors
    excluded; then gate and arm.
- **N1 ARM: ADOPTED** (u1c+rep vs u1c, dev80 76 complexes x 3 seeds, MACE float64; pools `etkdg_u1_rep`).

  | | #1 median / mean | floor median / mean | regret median / mean |
  |---|---|---|---|
  | u1c | 72.0 / 101.7 | 60.0 / 81.4 | 7.8 / 20.4 |
  | u1c+rep | 65.1 / 88.0 | 54.6 / 73.1 | 3.6 / 14.9 |
  | paired, b - a | **-13.7 [-22.5, -7.0]**, better / worse 30 / 2 | **-8.3 [-14.6, -4.2]**, 20 / 1 | **-5.5 [-9.9, -0.9]**, 16 / 4 |

  All three CIs exclude 0 on the good side. The prediction (#1 -6 to -12) was beaten.
  - **Recovery targets:**
    - XAQRUC 529 -> 260 (target <= 300; the Ta-N stretch is gone in all 3 seeds);
    - DEVFUG 178 -> 123 (<= 140), TACZUT 216 -> 178 (<= 180): fixed by the arm though not by the gate, so search;
    - PEWBOL 337 -> 256 (<= 340);
    - YOMGUC 259 -> 243 (target <= 230: missed).
  - **Other gains:** JEFJUZ 335 -> 252, YAVFEG 387 -> 306, XIPLUD 242 -> 159, XAXGOW 127 -> 65, ETAXEC 123 -> 73,
    YIYXEJ 114 -> 87, SOKVET 208 -> 183, JAYSUX 140 -> 114, NAPNID 139 -> 110.
  - **Losses:** KIQYEQ 140 -> 290 (Cu-B detached again in s12 / s13, +0.76 A; s11 fixed), OVODUZ 173 -> 200, FIGHOT
    209 -> 225, COPYIP 146 -> 163 (its floor 132 -> 85: ranking).
  - **Expansion check:** #1 with a metal-donor stretch > 0.2 A vs crystal 6.7 % -> 9.2 %, median Rg - crystal +0.021
    -> +0.039 A (rule: the ~9 % base rate, |shift| < 0.02).
    - Of the newly flagged picks, all but KIQYEQ s12 / s13 and COPYIP s12 have LOWER MACE energy (LITBOJ 92 -> 48,
      XAXGOW 127 -> 65, JEFJUZ 369 -> 250): the proxy (nearest heavy atoms vs crystal) flags harmless differences.
    - The un-flagged ones include XAQRUC x 3 and KIQYEQ s11. No general expansion; the one real stretch is the known
      Cu-B case.
  - **Profile u1:** `q6_pmf_wells` "contact" -> "repulsive" (class 4 core only); test updated.
  - **Pending per the plan:** delete the PMF modes no profile uses ("all", "hbond", and "contact" as its own mode);
    the walls stay while legacy is the default (S5).
- **PEWBOL under u1c (contact Q6), owner by eye + geometry**
  (xyz in `data/inspect/PEWBOL/`: crystal, u1c s11-13 #1 and floor):
  - **Crystal:** Ni(H2O)4L2, the two anilines trans, SO3 groups anti (S-N...N-S dihedral -180, N-Ni-N 180); each
    ligand's SO3 takes two water O-H...O H-bonds.
  - **#1 picks carry more H-bonds than their floors in every seed:**

    | seed | #1 pick | geometry | floor |
    |---|---|---|---|
    | s11 | 388 kJ/mol, 8 H-bonds | trans, SO3 syn: a water H squeezed between them | 185, 6 H-bonds |
    | s12 | 337, 11 H-bonds | cis, crowded | 226, 4 |
    | s13 | 287, 7 | cis "V" with SO3 anti (owner: plausible, a cool structure) | 218, 6 |

  - **Trans + anti conformers (|dihedral| > 120, N-Ni-N > 150) exist in every u1c pool but rank low:**
    - s11: 4 of 32, best 185 (the floor, rank 4; dihedral +132, only partly anti);
    - s12: 3, best 226, rank 30;
    - s13: 3, best 270, rank 28.
  - **Older pools for comparison:** u1+lean (walls) and legacy were all trans, but nothing below ~340.
  - **Reading (owner):** nothing explicitly wrong, precision. The search now finds the right family; the contact
    form's polar-H wells over-reward squeezed, extra H-bonds in the ranking.
  - **Prediction for N1 / N2:** the trans-anti conformers move up the ranking; over-bonded syn / cis picks lose their
    lead; N2 (angle-resolved H-bond statistics against random placement) more than N1.
- **Finding: CPU solves are not bit-reproducible under CPU load.**
  - **Source:** the GFN2 (xtb) free-ligand embed is OpenMP-threaded. Under load its reductions change order, and the
    solve can return a different conformer set.
    - Two golden records made while other CPU jobs ran: YAVFEG (legacy) a different set, X up to 14.5 A; HUYNEU (u1)
      scores 3.5e-4 apart.
    - On a quiet machine the default settings reproduce exactly, and the solver's thread-chunk count does not matter.
    - With `OMP_NUM_THREADS=1` the result is exact and slightly different from the default (HUYNEU's 2nd score
      1.424245 -> 1.424248).
  - **Owner decision:** pinning is opt-in, since determinism is not always needed and costs speed. NEW profile field
    `deterministic_embed` (default off): the GFN2 embed runs with OMP_NUM_THREADS=1 (`engine._gfn2_refine`).
  - `tools/jdev/golden.py` runs with `OMP_NUM_THREADS=1`.
- **NCI pair-rule fix and refit:**
  - **Bug:** `nci.candidates` used `pair_class != "4"` as "far", which lets 1-2 / 1-3 pairs in (the first fit's
    N-H...N peak at 40 deg was the H...N of an N-N bond).
  - **Fix:** "far" = more than 4 ligand bonds apart or no ligand path; also in `nci_census.py`. Histograms
    re-extracted, tables refit (17).
  - **Remaining artefact, to fix before the N2 gate:**
    - `('hb','*','Cl' / 'Br' / 'F')` and `('hb','N','N')` peak at ~2.5 A and 88-112 deg: an N-H on one metal donor
      next to a halide or N bound to the same metal. That is a cis D-M-A arrangement fixed by the coordination
      sphere, which the random-placement reference does not know about.
    - Exclude H-bond candidates whose donor atom and acceptor are both bonded to the metal (Q2 prices that
      geometry).
  - The first census is superseded; its rerun is pending.
- `gate.py`: one scorer per (complex, arm), reused across seeds (it was rebuilt, free-ligand embed included, for
  every pool and arm: 456 builds per variant on dev80, now 152). Each pool checks that the base re-score equals the
  stored ranking score (logged if > 1e-4); 2-complex test: 6 pools in 23 s, no mismatch.
- `gate.py`: `--override module:ATTR=value` (attributes outside the scorer) and boolean values; pools with float64
  MACE only are read (they were skipped silently: the first N1 gate printed nothing).

## 2026-10-17 b (owner decisions: contact Q6 kept in u1, S2 to be built; Q6 calibration proposed)
- **u1 now uses the contact Q6** (`profile.py` u1: `q6_model` pmf, `q6_pmf_wells` contact; test updated). Owner:
  the H-bond cases are what Q6 is for, and the losses are a few specific, addressable cases. The arm missed the written
  rule (+6.3 [-3.4, +17.6]); this is an owner override, recorded as such. New baseline pools `etkdg_u1_contact`
  (arm "u1c" in `tracks.py`: contact + E/Z + surrogate + lean), float64 MACE.
- **S2 (bond-valence term) to be built**, measured on top of u1c (it is the guard for the XAQRUC stretch).
- **Proposed, not built: Q6 data region by reference ratio against the model itself.** Diagnosis: all three PMF forms
  failed for one reason, the reference p_ref (pooled over keys, other molecules), which carries nothing the rest of the
  model knows. "all" kept the shape / composition junk (compaction, BIDHEB), "hbond" clamped it (outward pressure),
  "contact" cut it off and with it the real repulsive flank between the onset and the bulk of each distribution
  (score 1.7x soft along torsions, Q6 / Q5 exchange rate ~2.5x off: DEVFUG, TACZUT; no gradient before a contact:
  XAQRUC). Proposal: w(r) = -ln(p_crystal(r) / p_model(r)) per key with p_model the pair distances of the u1 solver's
  own predictions (Q6 = core only) on the SAME training complexes (`tmqm:` cases), iterated to self-consistency
  (iterative Boltzmann inversion); fixed point: the solver's predictions reproduce the crystal pair statistics key by
  key. Same table grid and code path as now. Predictions and checks to be written before any run.

## 2026-10-17 (plan 3, S2 offline checks: bond-valence coupling at the metal) -- measurement only
Plan 3 S2 asks whether independent per-bond Q1 misses a coupling between the M-D bonds of a complex (Brown's bond-valence
sum V = sum exp((R0 - R) / 0.37) ~ oxidation state), to be added as a reference ratio log p_obs(V) - log p_indep(V)
if it exists. Tool `tools/jdev/budget/bvs_check.py` (report `data/refit/bvs/report.txt`, R0 `data/refit/bvs/r0.json`).
- **Checks 1-2 (R0 fitted on half of 79 771 sigma-only training complexes with a known OS, 383 metal-element pairs;
  V / OS measured on the other half):** median 0.989 (Brown's rule holds on tmQM); robust sd 0.138 real vs 0.212 when
  every bond is replaced by a random bond of the same (metal, OS, donor subclass) key: coupling exists (ratio 1.53),
  but by metal: lanthanides 4-5, Ti 2.35 / V 1.87 / Zr 1.92, Ni / Zn / Cd ~1.7, Pd 1.29, Cu 1.32; **none** for the
  soft / covalent late metals (Fe 1.02, Ru 1.02, Re 1.00, Pt 0.97, Rh 1.01, Ir 0.97, Os 0.97, W 1.03; their V spread
  0.24-0.37 is wide too: Brown's rule is weak for pi-acceptor chemistry). Metal-only level (no OS): 0.105 vs 0.218.
  A reference-ratio term would therefore act only where the coupling exists, by construction.
- **Check 3 (haptic donors) not done:** complexes with a haptic donor were left out.
- **Check 4 (do failing picks stand out; V relative to the crystal's V):** the Ta stretches yes (XAQRUC PMF #1 -0.80,
  VUJYEG -0.68); KIQYEQ's detached boryl no (-0.01: Cu-B pairs too rare for an R0, Cu coupling weak); YIYXEJ no
  (Fe: no coupling; the whole u1 pool sits at -0.25, so nothing separates good from bad); OVODUZ no (not a stretch).
  Over all u1+lean pools |dV| > 0.4 marks a tail (MACE median 538 vs ~130 below 0.1; within-pool Spearman 0.23).
- **Reading:** a real, data-derived coupling that guards early-metal and lanthanide complexes against correlated
  stretching (the PMF failure mode), but it does not address the Cu / Fe cases that motivated it. Expected dev80 gain
  under u1 small (tail protection); priority set after the S1 arm (if the contact form shows a stretching signature,
  S2 becomes its guard).

## 2026-10-16 f (why the Q6 PMF lost: component decomposition) -- diagnosis only, no behaviour change

Tool `tools/jdev/budget/q6_diag.py` (terms / report / pairs): every Q6 pair of the conformers of both arms' pools
(u1+lean walls, u1+lean+pmf), split by category (polar-H...acceptor "hp", metal "m", 1-5 "c4", rest "c5", no table)
and region (core d < r0 / data d >= r0); reproduces both arms' stored rankings to 1e-6. `q6pmf.build_runtime` now also
returns each row's onset r0 (diagnostics only). MACE float64.
- **Split of the loss (+34.6 [+10.7, +65.9] kJ/mol):** search (pool floor +29.9 [+8.9, +57.3]) AND ranking (same
  union pool, PMF vs walls +16.5 [+5.1, +29.6]).
- **Re-ranking the union pool with one PMF part changed at a time (vs walls):** as run +16.5; without the polar-H
  wells +19.6 (they help); without the angle classes +16.4 (no effect); core only -0.8 [-4.7, +3.3]; core + polar-H
  full -3.2 [-10.1, +2.6]; **non-polar data region set to 0: -2.9 [-9.7, +2.6]**; walls + polar-H wells -2.3
  [-7.6, +0.8]. The core is not the problem, the angular part is irrelevant, the H-bond part helps: the loss is the
  data region of the NON-polar pairs.
- **Accounting of the 94 pools where the PMF #1 is > 20 kJ/mol worse** (b1 - a1, nats in favour of the PMF pick): c4
  data region +9.6 (median 6.6, 98 % of pools), c5 data region +4.3 (91 %), m data +0.8 (80 %); polar-H +0.25; every
  other term prefers the wall pick (Q1 -2.0, Q2 -1.0, S_orient -1.0, Q5 -1.0, bend -0.7) and the walls see the bad
  contacts (c5 -12.7, c4 -2.8).
- **Mechanism.** w = -ln(p_key / p_ref) with p_ref the pooled distance distribution of the class: away from contact it
  is +-1 kT of composition / shape difference, not an interaction. PMF_WELLS = "hbond" clamps every non-polar pair to
  max(w, 0), so the noise becomes one-sided: on near-crystal structures (wall #1, 80 complexes) the non-polar PMF sums
  to +37.8 kT per complex, 76 % of it at 3.5-5.5 A (unclamped: -61 kT; walls +9.2 kT, all below 3.5 A). With the taper
  to 0 at 5-6 A this is a net outward pressure: moving every ligand rigidly 0.7 A off the metal RAISES the PMF log p by
  +12.9 (XAQRUC), +8.6 (VUJYEG), +4.6 (ANIYAA) nats (walls +0.4 to +2.3). On 1-5 pairs (c4) it is in addition a
  second, unspecific torsion potential (H_H|4 +1.3 kT at 4.0 A, +2.9 at 4.5 A).
- **What it does to the structures.** All 13 pools with a PMF loss > 100 kJ/mol have stretched metal-donor bonds
  (median +0.71 A) and an expanded complex (radius of gyration +0.26 A); over all pools the loss correlates with the
  expansion (r 0.64). XAQRUC: all six Ta-N 2.05 -> 2.5-2.8 A (912 kJ/mol); VUJYEG: three Ta-N 2.07 -> 2.7 A; KIQYEQ:
  Cu-B 2.05 -> 3.6 A. MACE per-atom energies put the loss on the metal and the donors. xyz in data/inspect/<code>/q6pmf_*.
- **Amplifier outside Q6: Q1 broad components (u1 keeps them).** Ta-N keys pool dative and covalent N: Ta-N_amidinate
  mu 2.35 sd 0.23 w 0.62, Ta-N_donor mu 2.43 sd 0.34 w 0.38: pulling XAQRUC's ligands 0.7 A off costs only 18.7 nats of
  Q1 (VUJYEG 120, ANIYAA 198). Same pattern as KIQYEQ's Cu-B (10-16 d).
- **H-bonds.** Only 11 of the 80 dev complexes ever form a polar-H...acceptor contact < 2.2 A. PEWBOL (aqua /
  sulfonate network): walls #1 421 kJ/mol, walls + polar-H wells 223 (floor 208); JALSEY 93 -> 79; YIYXEJ 110 -> 134
  (one N-H...O at 1.84 A, -7.3 kT, whose strain the other terms price at only 2.8 nats); LEBNOX 221 -> 231. The
  short-range part alone (< 2.2 A) does not move PEWBOL: the -1.5 to -2.2 kT polar plateau at 2.4-3.5 A is part of it.
- **What the tables are made of** (`tools/jdev/budget/q6_dists.py`, figure `data/inspect/q6pmf_tables.png`). The
  PMF was designed (10-14) with a data region w = -ln(p_key / p_ref) from the onset r0 out to 5 A, tapered to 0 at
  6 A; only the metal 1-3 class (10-16 d) is core-only. Class 5 (C_H, H_H, C_C: 81 % of the reference): beyond
  ~3.5 A p_key and p_ref nearly coincide (both are molecular size), w wiggles by 0.1-0.3 kT; a crystal pair pays
  +0.02-0.03 kT on average after the clamp, x ~1500 pairs = ~30 kT per complex. Class 4 (1-5 pairs): distances are set
  by torsions, p_key is spiky and differs from the pooled class-4 reference (C_H 38 %, H_H 25 %, C_C 18 %), so the
  table has +1.5 to +5 kT barriers between a key's own torsion peaks (H_H|4 at 4.4-5.3 A); a crystal pair pays
  +0.12-0.16 kT. Hp_O|5: enriched against the reference at every distance below 4.5 A (polar groups cluster): -2 kT
  plateau from 2.2 to 3 A, 0 at 4.5 A. Summing -ln g over every pair also counts the same molecular shape once per
  pair (the double counting principle 4 of the plan warns about).
- **H-bond well range:** walls + polar-H wells cut at 2.8 A (the usual H...A criterion) -1.8 [-6.9, +1.6], PEWBOL 237
  (all ranges: 223; <= 2.2 A: 430); PMF core + polar-H <= 2.8 A -3.4 [-9.5, +1.8], PEWBOL 241.
- **Process miss:** plan U4 asked for the PMF's curvature check and a gate under u1 before the solver arm; neither was
  run (the last gate was 10-16, legacy profile, "no detectable change"). The gate under u1 (+16.5 [+5.1, +29.6] above)
  would have failed it before the arm.
- **Next Q6 form ("contact": owner-agreed design) and predictions, written before any code or run.**
  Q6 = sum over pairs of c(d) + sum over polar-H...acceptor pairs of h(d, angle), kT, summed, / Z, weight 1:
  c(d) = kappa (exp(b (r0 - d)) - 1) below the key's 0.1 % onset r0 (GFN2 b, kappa as now), 0 above (the metal 1-3
  class form); h = min(w_angle(d), 0) for d >= r0 with a cos^2 taper 2.6 -> 3.0 A, held at min(w(r0), 0) below r0
  (continuous; the offline variant dropped the well below r0). Pairs without a table keep their wall; the beam
  pre-screen keeps the walls. No other data region. The "all" / "hbond" PMF modes leave the code if this wins.
  Offline (same conformers, MACE float64): wall-arm pools only -1.5 [-4.4, +0.8], H-bond subset -1.4; union with the
  PMF pools -3.4 [-9.4, +1.9], H-bond subset -12.4: the H-bond gain needs the solve to generate H-bonded conformers
  (PEWBOL's floor 368 walls / 196 PMF solve).
  - Checks in order: (1) `forces.py` curvature on Q6-dominated directions: energy/score within 0.5-2 (walls 0.80;
    the core is softer for H...H 2.1-2.6 A, so expected higher, ~1-1.5); > 2 = core too soft, stop. (2) gate on the
    u1+lean pools: no FAIL (expected about -1.5, CI incl. 0). (3) arm u1+lean+contact vs u1+lean, dev80 x 3 seeds.
  - Arm prediction: #1 mean -3 to -8 kJ/mol, median about 0 (CI will include 0: MDE ~35-40); floor similar; H-bond
    subset (11 complexes with a polar-H contact < 2.2 A) mean -10 to -25, PEWBOL #1 < 300 in >= 2 of 3 seeds; the rest
    within +-5; no expansion signature (pools with a metal-donor stretch > 0.2 A vs u1+lean #1 at the base rate ~9 %,
    median radius-of-gyration change |.| < 0.02 A).
  - Adopt if: #1 and floor CI upper bounds <= +10, H-bond subset better, no expansion signature, curvature in range.
    Falsifier: a CI excluding 0 on the worse side, the expansion signature, or the curvature check failing.
  - **Code in:** `q6pmf.evaluate` mode `q6_pmf_wells="contact"` (core excess below each row's r0, angle-mixed;
    polar-H well min(w, 0) held at its r0 value below r0, `HBOND_TAPER` (2.6, 3.0)); test
    `test_q6_contact_form_is_core_plus_hbond_wells`.
  - **Check 1, curvature (u1 + contact, cached directions): passed.** Q6 energy/score on Q6-dominated directions
    0.72 pool / 0.92 crystal (walls 0.83 / 0.57; range 0.5-2). Other terms' ratios rise (Q1 1.43 / 1.64, Q2 1.28 /
    1.86, Q5 1.82 / 1.52): the walls carried part of the torsional curvature, the score is now ~1.7x soft along
    torsions at the crystal (walls 0.68). Spearman 0.80 / 0.83 (walls 0.81 / 0.86), R^2 unit scales 0.34 / 0.39.
  - **Check 2, gate (u1+lean pools, base walls, MACE float64): -1.56 [-4.54, +0.79]**, better / worse 11 / 10, top-1
    0.403 -> 0.429: no detectable change, as predicted (~-1.5). No FAIL: arm u1+lean+contact launched.
  - **Arm result (2026-10-17; u1+lean+contact vs u1+lean, dev80 x 3 seeds, MACE float64): prediction missed, NOT
    adopted.** #1 +6.3 [-3.4, +17.6] (predicted -3 to -8; the rule needed an upper bound <= +10), median +3.3, better /
    worse 20 / 25; floor +0.3 [-7.3, +8.9]; regret +6.0 [+2.0, +10.6] (worse). Gains:
    - PEWBOL 428 -> 256 (floor 368 -> 215; prediction < 300 met);
    - XIPLUD 220 -> 184 (floor 185 -> 108);
    - OVODUZ 198 -> 176 (floor 129 -> 103);
    - JAYSUX 187 -> 140, IYONIW 194 -> 157, FIGHOT 240 -> 209.
    Losses: XAQRUC 251 -> 525 (floor 246 -> 445), KIQYEQ 212 -> 419, DEVFUG 130 -> 177, TACZUT 170 -> 214, YOMGUC
    225 -> 260. No general expansion (stretched pools 7 % vs ~9 % base rate, Rg median -0.02 A), but XAQRUC (3 / 6 Ta-N
    +0.35 A) and KIQYEQ (Cu-B > +1 A) in every seed.
  - **Why (term-by-term, under the contact score itself):**
    - **XAQRUC / KIQYEQ are SEARCH failures.** The contact score prefers the walls arm's #1 by 6-10 nats (XAQRUC)
      and 3-4 (KIQYEQ), almost all Q1; the contact solve does not reach it. With nothing above the onset, the
      landscape between contacts is flat and the donors drift along Q1's broad components: the summed walls were
      also a search aid.
    - **DEVFUG / TACZUT are RANKING losses** (+5.1 / +3.4 nats for the worse pick, via Q2 / S_orient / Q5): the
      torsional softness the curvature check flagged (score 1.7x soft along torsions without the walls).
  - **Reading:** as a ranker on the same conformers the contact form is slightly better (gate -1.56; PEWBOL, OVODUZ)
    and it brings the H-bond cases; as a solve landscape it is worse. Candidates (not run):
    - the plan-2 principle-3 continuation (repulsion broadened early in the solve, exact contact objective at the
      end; Rosetta's fa_rep ramp in reverse);
    - S2's bond-valence guard for the Ta stretch (it flags XAQRUC);
    - KIQYEQ stays the known Q1 Cu-B case.
    The walls stay in u1 for now.
  - Known risks: H...H 2.1-2.56 A becomes free (walls up to 2.1 nats) where the walls may stand in for strain other
    terms under-price (Q1 broad components, 10-16 f); an H-bond well (-7 kT) can outbid strain those terms price too
    low (YIYXEJ); the H-bond evidence is essentially one complex (PEWBOL), so held-out must confirm.
- **The u1 regressions (owner, by eye: OVODUZ an isomer change, YIYXEJ a carbene donor a bit far; both bound).**
  `isomer_check.py` (job scratch): both arms' pools scored with u1, best conformer per donor -> site assignment.
  OVODUZ: every isomer is in both pools. Legacy's best (asg 2, 71 / 76 kJ/mol) carries 19-30 nats of summed wall
  penalty under u1 for mild contacts MACE does not mind; the u1 solve removes them (Q6 -25 -> -5) at +50-70 kJ/mol and a
  worse Q5 (-8.5 -> -14.2), and among its own strained structures the isomer preference flips (asg 8 / 1): a RANKING
  failure of the summed walls. Under the contact Q6 the legacy asg-2 structure is the top-scored conformer of either
  pool (1.756 vs <= 1.570): ranking fixed; whether the solve finds it is for the arm. YIYXEJ: a SEARCH miss (u1 scores
  the legacy #1 higher, 2.08 vs 2.03, but its solver does not reach it; floor 5-20 -> 97-105): the u1 picks have a
  stretched Fe-C donor that Q1 prices at ~1.2 nats (Fe C_carbene keys carry 2.1-2.5 A broad components, w 0.15-0.3);
  the Q1 broad-component weakness again.
- **Not tested here:** the PMF core is softer than the walls between its onset and the wall's mu for H...H / C...H
  (H...H 2.0 A: wall 2.96 nats, PMF ~0); in re-ranking this costs nothing (core only -0.8), in the solve it is unmeasured.

## 2026-10-16 e (MACE evaluation memory; float32 energies are not reproducible) -- tooling, no solver change

- **Cause of the GPU spill into system RAM:** the MACE energy stage, not the solver. MACE-POLAR-1-S peaks at ~2-3.4 MB
  per atom per conformer, and the batch was a fixed 32 conformers: 12.3 GB peak for a 113-atom pool (DEVFUG), 8.2 GB
  at 83 atoms, on an 8 GB card. The Windows driver's system-memory fallback served the excess from shared system RAM
  instead of raising, so the out-of-memory halving never ran (and a 16 GB host ran short; likely the low-memory kill of
  the sur/pmf job). Solve stage measured at < 0.5 GB on the largest dev80 complexes.
- **Fix (`benchmark/energy.py`):** batches capped by total atoms as well as conformers (600 atoms in float32, 300 in
  float64; `JACOBIK_MACE_BATCH_ATOMS`), and the caching allocator capped at 85 % of the card
  (`JACOBIK_MACE_MEM_FRACTION`) so an oversized batch raises and the halving runs. Peak 12.3 -> 2.0 GB (DEVFUG); the
  five-pool probe ran in 6.3 s (no slowdown).
- **Found on the way:** float32 MACE energies vary by up to 5-10 kJ/mol for the same structures (run to run, and with
  batch composition) on ~80-atom complexes (absolute E ~ -75 000 eV; float32 rounding + non-deterministic GPU sums).
  float64 is exact across batchings, 1.6x slower, 2.5x memory. The stored pool dE values (all float32) carry this
  noise: unbiased, small next to the paired-test CIs (+-30 kJ/mol), but it is measurement noise in every arm.
  Not yet switched (owner decision: switching means re-running MACE on the ~2 900 existing pools, ~1-1.5 h GPU).

## 2026-10-16 d (U1: thermal widths from GFN2 Hessians on training crystals) -- measurement only, in progress
Plan principle 2: no table component narrower than the thermal width at 298 K. sigma_T^2 = kT g^T H^+ g per feature
(g = gradient of the scorer's own feature, H^+ = pseudo-inverse of the GFN2 Hessian at the tmQM minimum, rigid and
negative modes dropped): the width of that feature's marginal in the harmonic Boltzmann distribution, every other
coordinate relaxing. GFN2, not MACE: tmQM geometries are GFN2 minima, so the Hessian is taken at a true stationary
point of the same method (MACE would need a re-minimisation first). Parameter of the statistical model, measured on
training crystals only (BEND_K precedent); it never acts on a structure being solved.
- Sample: 300 X1 complexes, 100 each 3d / 4d / 5d, <= 80 atoms, holdout codes excluded, seed 0
  (`refit/thermal_widths.py sample`; chosen from raw xyz headers, 47 s instead of a full-split parse).
- **Predictions (written before the Hessians finished):**
  - median Q1 sigma_T 0.06 A (k ~ 650 kJ/mol/A^2), spread 0.04-0.10 A (stiff 3d-C / N to long axial or weak dative);
  - Q2 sigma_T (cos D-M-D) 0.05-0.10, i.e. the current 0.05 Q2 floor is at or below the thermal width;
  - S_orient angles 3-8 deg;
  - 30-50 % of Q1 table components (the needle ones, fitted sd 0.002-0.02 A) are narrower than sigma_T;
  - Q5: broad (> 20 deg) for sp3 rotors, narrow (< 10 deg) for conjugated bonds; reported only, Q5 is not floored.
- Falsifier for the plan's principle: if the median Q1 sigma_T came out >= 0.15 A, the thermal floor would roughly
  reproduce the 0.2 A floor and the ranking-side stiffness would be the only change.
- **Results (299 / 300 complexes, 9456 features; `data/refit/thermal/report.txt`, `data/refit/final/thermal_widths.json`):**

  | feature | median sigma_T | p10-p90 | prediction |
  |---|---|---|---|
  | Q1 (M-D) | 0.059 A | 0.036-0.104 | 0.06 A: hit |
  | Q2 (D-M-D angle) | 4.9 deg (0.086 cos at 90 deg) | 3.2-7.8 deg | 0.05-0.10 cos: hit |
  | S_orient angles | 4.2 deg | 2.8-7.4 deg | 3-8 deg: hit |
  | Q5 (harmonic, report only) | 13.8 deg | 8.7-27 deg | |

  Metal row and CN do not move the widths (3d / 4d / 5d Q1 0.060 / 0.060 / 0.056). Donor element does: Q1 for C 0.041,
  P 0.053, eta 0.057, Cl 0.058, O 0.060, Br 0.065, S 0.069, N 0.071 A (factor 1.7, beyond the plan's sqrt 2), so Q1 is
  floored per donor element (`scorer.THERMAL_Q1_BY_DONOR`), the rest per quantity (`scorer.THERMAL_SD`).
  Table components narrower than the thermal width: Q1 49 % (22 % narrower than half of it), Q2 46 % (23 %), S_orient
  41 % (0 %: its fit-time cov floor already caps it at half). The 0.2 A solve floor is 3.4x the thermal Q1 width (12x in
  variance), consistent with the "4.5x too soft" solve curvature of 10-16 b.
- Method notes: angles measured in angle space (the tables' cos has zero slope at 180 deg; trans Q2 came out 0 in
  cos); per-feature dropping when a feature touches an atom the crystal map cannot place (H count per parent differs
  between SMILES and crystal; was a 38 % whole-complex loss); 47 complexes with small negative modes kept (modes
  dropped in H^+, medians within 2 % with / without them); one complex failed to embed.
- **U2 profile `u1` (code in, default unchanged):** `score_agg=sum`, `rank_agg=sum`, `solve_floor=thermal`,
  `rank_floor_fit=false` (the ranking keeps the solve's floors), `q1_tail_sigma=0`, new field `bend_per_z=true` (the
  bend prior, a log-probability in nats, is divided by the same per-complex constant Z as the summed statistics; under
  legacy it is added raw, i.e. weighted Z times its log-probability against a summed score). Thermal floors:
  Q1 / Q4 scalar; Q2 / Q3 per component at the component's own mean cos (Var cos = sin^2 s^2 + cos^2 s^4 / 2);
  kappa S_orient covariances floored in the Loewner order (eigenvalues of the floor-whitened covariance clipped at 1);
  haptic S_orient features not measured, unchanged. Tools: `gate.py --profile`, `forces.py` per-profile score
  curvatures on cached directions and MACE curvatures (`curvature2/geom`), `pools.rank_terms` follows
  `rank_floor_fit` as `ranking_score` now does.
- **U2 predictions (written before any u1 number):**
  - (a) curvature, ranking = solve under u1: energy/score ratio within a factor 2 of 1 for Q1 (legacy ranking 7-17x
    too stiff, legacy solve 4.5x too soft), Q2 (4x / 2x too stiff), S_orient and Q5; Q6 still ~3x too soft (waits for
    U4). R^2 with unit scales clearly positive (legacy ranking: negative).
  - (b) gate u1 vs legacy on the 10-16 pools: no FAIL; most likely "no detectable change" (mode positions are the
    same; only widths and the bend weight move).
  - (c) rho_within >= 0.68 (legacy 0.68); rho_isomer about unchanged (0.59).
- **U2 results, first u1 (Q5 not floored)** (dev32 + N48 pools, 80 complexes, 15055 directions; logs in the job tmp):
  - (a) curvature. NNLS per-term scales turned out unreliable (correlated terms: Q6 moved 2.6 -> 0.5 with an
    identical formula, absorbing Q1's misfit), so the per-term read is now the energy/score ratio on directions where
    one term carries >= 70 % of the positive score curvature (per-complex median):

    | term | legacy ranking | u1 |
    |---|---|---|
    | Q1 | 0.26 | 1.35 |
    | Q2 | 0.27 | 1.01 |
    | S_orient | 0.46 | 0.80 |
    | Q6 | 0.64 | 0.80 |
    | Q5 | 0.16 | 0.19 |

    Spearman of curvatures 0.64 / 0.74 -> 0.72 / 0.79 (crystal / pool); R^2 with unit scales -85 / -142 -> 0.30 / 0.36.
    Hit for Q1, Q2, S_orient, Q6; **miss for Q5: 5x too stiff in both profiles.** The 10-16 b "Q5 alone ~1" came from
    the confounded NNLS view and is withdrawn. Cause checked: one torsion feature per bond (no double counting); 74 %
    of Q5 wells are sharper than the thermal kappa 17 (median kappa 31, p75 144).
  - (b) gate u1 vs legacy: MACE #1 median 77.1 -> 76.3, mean +3.6 [-3.9, 13], top-1 0.375 -> 0.409; GFN2 SP +1.2
    [-7.4, 9.6], top-1 0.414 -> 0.397: no detectable change (as predicted).
  - (c) two rho (both arms on their full score incl. bend): rho_within 0.70 -> 0.71, rho_isomer_sp 0.59 -> 0.67,
    rho_isomer_relaxed 0.23 -> 0.34, rho_basin 0.17 -> 0.19, pick in lowest basin 0.41 -> 0.44 (as predicted or better).
- **Decision (plan principle 2 applies to every term, the plan's "Q5 as is" rested on the withdrawn number): Q5 wells
  floored at the thermal torsion width**, kappa <= 1 / sigma_T^2, sigma_T = 13.8 deg (bond class conjugated 12.1 vs
  single 13.9 deg: < sqrt 2, one value). Prediction: Q5 ratio 0.19 -> 0.6-1.2; the other terms unchanged; gate still no
  FAIL; rho_within not lower.
- **U2 results, u1 with the Q5 floor (final u1):** per-term ratio (pool / crystal) Q1 1.33 / 1.39, Q2 0.93 / 1.50,
  S_orient 0.87 / 0.73, **Q5 0.87 / 0.71** (prediction 0.6-1.2: hit), Q6 0.83 / 0.57; torsion directions 0.55 -> 0.79;
  curvature Spearman 0.81 / 0.86 (legacy 0.64 / 0.74); R^2 with unit scales 0.37 / 0.40 (legacy -85 / -142). Gate vs
  legacy: MACE +3.7 [-3.8, 13.3], top-1 0.375 -> 0.392; GFN2 SP +2.0 [-7.2, 11.0]: no detectable change, no FAIL.
  rho_within 0.72, rho_isomer_sp 0.67, rho_isomer_relaxed 0.36, rho_basin 0.19, pick in lowest basin 0.44.
  **Every U2 stop rule passed**: no term needs a fitted weight (all within a factor 2 of the energy without one).
- **U3 measurement, how far the solver moves each feature** (`tools/jdev/budget/start_error.py`, dev32 seed 11, CPU
  path): median |f_end - f_start| Q1 0.25 A, Q2 21 deg, S_orient 13 deg = 4.1 / 4.2 / 3.0 thermal widths; p90 Q1
  1.8 A (rows that change mode). One dimensionless continuation start s0 ~ 4 sigma_T would cover every term.
- **Next: solver arm u1 without continuation** (pools.py under `JACOBIK_PROFILE=u1` -> `pools/etkdg_u1`, dev32 + N48,
  seeds 11-13, CUDA; `tracks.py --arms O u1`). A narrow Gaussian is quadratic everywhere (no vanishing gradient) and
  Adam normalises the step, so continuation is built only if this arm shows a search failure. Prediction: pool floor
  lower or equal (Q1 no longer 3.4x too soft in the solve), #1 not worse (CI includes or is below 0); falsifier: #1 or
  floor worse with the CI excluding 0.
- **U3 result, solver arm u1 (no continuation) vs production O** (dev32 + N48, 76 valid complexes x seeds 11-13,
  CUDA, `tracks.py --arms O u1`): #1 median 73.9 -> 71.2, mean 115 -> 111, paired -4.5 [-37.5, +28.7]; floor median
  61.1 -> 61.4, mean 90.5 -> 85.7, paired -4.8 [-21.2, +7.6]; regret +0.3 [-21, +29]: no detectable change on any
  (MDE 47 / 22 / 36). Prediction (floor lower or equal, #1 not worse) not falsified. Share of returned conformers
  > 1000 kJ/mol 10.6 % -> 5.3 %; #1 > 1000: 1 -> 3 of 240 pools (all YAVFEG). Pools are smaller (median 32 -> 17.5
  conformers: the 200-nat output window bites harder on a sharper score). Large moves both ways: TAPWUG 643 -> 101
  (the beam needle-mode case), JIHMAR 376 -> 60, DEVFUG 201 -> 133, IDAVES 111 -> 58; YAVFEG 326 -> 1194 (#1, floor
  unchanged), XIPLUD 142 -> 217, KIQYEQ 164 -> 204.
  YAVFEG diagnosed: in all 3 seeds the whole u1 top 5 sits at ~1200 kJ/mol; the #1 has a ring H 2.41 A from Zr (the
  lowest-energy conformer has no H among the metal's 8 nearest atoms). Same class as COPYIP: a metal 1-3 pair, not
  seen by Q6. The sharper Q1 / Q6 make the blind spot easier to exploit; U4's m13 class is the planned fix.
  **Decision:** u1 meets the plan's U3 rule (not worse on #1, curvature much better, obscene share halved).
  **Continuation is not built:** the arm shows no search failure it would address (floor unchanged; the big losses are
  ranking failures of a known blind spot, the big wins are search successes), so adding a schedule would be
  unjustified complexity. The default switch waits for U4 (one check of u1 + m13 together); legacy stays.
- **G / D3 beam, code in (profile field `beam_mode_score`, legacy "density"):** "mass" ranks a torsion mode by its
  log weight (the probability of the well) instead of the log density at its mean (~ log w + log kappa / 2). Audit on
  dev80 (rows with >= 2 modes; a miss = the beam's top mode has < 80 % of the dominant weight): legacy 114 / 599 rows
  (19 %) in 50 complexes, u1 83 / 599 (14 %) in 39 (the thermal Q5 cap already removes part); mass: 0 by construction.
  **Prediction for the arm u1 + mass vs u1** (dev80, seeds 11-13): floor lower or equal (dominant wells seeded), #1 not
  worse; falsifier: #1 or floor worse with the CI excluding 0.
- **U4 revision before any measurement: metal 1-3 class by donor kind, and as walls under the wall model.** Fitted on
  the first pass, the pooled class put the H onset at 1.67 A (agostic C-H and bridging H of kappa donors), which hides
  that a Cp ring H never comes closer than ~2.6 A (YAVFEG's u1 #1: Cp H 2.41 A from Zr). Now two classes, `m13`
  (X bonded to a kappa donor) and `m13h` (X bonded to a haptic face atom): H...Zr onset 2.59 A for m13h. And since u1
  scores sterics with the q6p5 walls, the 1-3 pairs get the same wall form (mu = 5th percentile, sigma = mirrored
  left tail, >= 0.1 A; `q6pmf.fit_m13_walls`) under the new field `q6_m13` (legacy off); the PMF core rows are the
  same class for the PMF model. 68 walls / 68 core tables (>= 3000 pairs); e.g. H...Zr m13h mu 3.09, sigma 0.23 (YAVFEG
  #1's 2.41 A: 4.5 nats; good structures ~2.9 A: 0.4); C...M m13 pooled mu 2.76, sigma 0.11. DB:
  `constraints_refit_q6p5_m13.json` (production DB + Q6P m13 entries, which only q6_m13 / the PMF read).
  **Prediction (gate u1 vs u1 + q6_m13 on the u1 pools):** no FAIL; YAVFEG's #1 moves off the 1200 kJ/mol family in
  at least one seed; the share of #1 > 1000 kJ/mol not higher. Falsifier: gate FAIL (CI > 0).
- **D3 result, arm u1 + mass vs u1:** floor +0.5 [-1.1, +2.2] (identical seeds in effect), #1 +20.6 [-0.5, +53.2]
  (median 0, better / worse 4 / 9), regret +20.1 [-0.7, +52.5]: no detectable change, leaning worse on #1. Not adopted.
  The thermal Q5 cap had already removed the needle peaks that mattered (TAPWUG fixed by u1 alone).
- **YAVFEG root cause (owner, by eye on data/inspect/YAVFEG): a Cp ring H folded INTO the ring, at the centroid.**
  Measured: u1 #1-#3 have one Cp H 0.17-0.21 A from the ring centroid, ~170 deg from its outward direction; legacy #1,
  floors and the reference have every Cp substituent within ~15 deg of outward. Three gaps line up: (1) the lean bend
  of an eta4-eta6 face's substituent had stiffness 0 (the lean wall existed for eta2 / eta3 only); (2) the
  per-substituent bend statistic is unit(X - A) . n, so an H in the ring plane pointing inward reads 0, a perfect flat
  Cp-H; (3) every pair the folded H forms is excluded from Q6 (ring C and ring H within 3 ligand bonds, Zr 1-3).
  Why under u1: the #1 wins on Q6 (+6.3 nats) and the bend prior (+3.5); u1 sums every wall in the solve (legacy:
  soft-min), so parking an H where it has no scored pairs at all became worth finding. Not u1-specific: pools scan
  (an atom within 0.8 A of a metal-bound 4-7 ring's centroid): legacy 1.8 % of conformers in 7 complexes (COPYIP,
  ETAXEC, JEFJUZ, KAQFUD, NIMJAW, OVODUZ, YAVFEG; 1 #1), u1 3.0 % (3 #1). COPYIP's "Cp H into W" of 10-16 b was most
  likely this fold, not a metal 1-3 contact.
- **Fix: lean wall for every haptic face size** (profile field `haptic_lean_all`, legacy off). Ranges by the 09-27
  method, now per face size (refit QO observations via `orientation.per_sub_rows`, 2.5 / 97.5 % of the per-substituent
  bend, larger of H and heavy; reproduces eta2 58 / eta3 40): eta4 50, eta5 17, eta6 16, eta7 11, eta8 18 deg.
  Check (YAVFEG seed 11, u1, CPU): without, #1-#3 folded at MACE 1199 / 1238 / 1236 kJ/mol; with, no fold in #1-#3,
  MACE 359 / 375 / 345 (legacy #1 ~326, pool best ~300).
- **m13 gate (u1 vs u1 + q6_m13, on the u1 pools):** MACE -8.2 [-31.9, +7.3], better / worse 4 / 1: no detectable
  change. YAVFEG fixed in the re-rank (1190 / 1200 / 1194 -> 307 / 352 / 466: the folded H sits ~2.2-2.4 A from Zr,
  inside the m13h wall at 3.09 A). KIQYEQ worse in all seeds (~200 -> 390-426): every pool member has a 1-3 O at
  2.2 A from Cu (crystal: nearest O 3.12 A), so the wall flags a real defect the whole pool shares and the re-rank can
  only trade one bad structure for another; only a solve with the wall can show whether it pulls the O out.
- **Next arms (each vs u1):** u1 + haptic_lean_all (prediction: YAVFEG #1 ~350 in every seed, folded share ~0, no
  other complex worse; falsifier: #1 or floor worse with the CI excluding 0); then u1 + lean + q6_m13 (KIQYEQ the
  case to watch).
- **Result, arm u1 + haptic_lean_all vs u1:** #1 mean 110.8 -> 99.4, paired -11.5 [-34.4, +1.2]; floor -0.6 [-2.4,
  +0.6]; regret -10.9 [-33.2, +1.0]: no detectable change by the CI. YAVFEG 1194 -> 359 (as predicted), SOKVET 452 ->
  372 (floor 415 -> 355). Folded conformers 3.0 % -> 0 of 7900. Losses JEFJUZ 278 -> 313, JAYSUX 157 -> 187 (seed
  noise: 7-9 conformer pools, one isomer, seeds 156 / 146 / 190 -> 138 / 186 / 190): my "no other complex worse" was
  not met, the falsifier was not hit. **Adopted into profile u1** (removes a physical defect; not worse on #1 / floor).
  The `pools/etkdg_u1` pools predate it (their recorded snapshot has haptic_lean_all false); `etkdg_u1_lean` is u1 now.
- **KIQYEQ (owner: "a boronic thing, the O-B-O head squashed"): an embed defect from the SMILES.** Every pool member,
  both profiles: B-O 1.27 A (crystal 1.40), O-B-O 137 deg (crystal 107). tmQM writes the bound pinacolboryl as
  `CC1(C)OB=[O+]C1(C)C`, the Cu-B electron pair pushed into a B=O pi bond; ETKDG embeds a double bond and the GFN2
  refinement relaxes a free two-coordinate B. With O-B-O stuck at 137 deg the two Cu-B-O angles cannot both reach the
  ~125 deg of the statistics; both profiles tilt the boryl (one angle at its mode, the other into a broad tail), u1
  harder (Cu-B-O 92 -> 79 deg, Cu...O 2.48 -> 2.18 A). Of the 30 donor=[X+] bonds in dev80 the rest are CO, isocyanides
  (correct Lewis structures) and one azide. **Fix (profile field `bound_surrogate`, default off):** a group-13 donor
  (B, Al, Ga) written as D=[X+] is embedded as its bound, H-capped form (bond made single, X neutralised, one H cap on
  D), through ETKDG / MMFF / the GFN2 refinement, then placed on the ligand as written (cap dropped; topology and labels
  unchanged; `chelate_embed.bound_surrogate / map_surrogate_positions`). KIQYEQ's boryl: B-O 1.27 -> 1.35 A, O-B-O
  137 -> 113 deg (crystal 1.40 / 107; free H-Bpin ~1.36 / 113). Test `test_bound_surrogate_caps_group13_onium_donors_only`.
  Only KIQYEQ is affected in dev80: its arm is that one complex.
- **Refit note (owner question on the per-substituent bend):** inside the data range the lean is still priced by the
  S_orient per-substituent bend (k = 0 there); the wall only removes the mirror well the feature cannot see (cos to
  the face normal is the same for an outward and an inward in-plane H). At the next refit make the feature injective
  (signed angle from the in-plane radial component) so S_orient prices the flip itself and the wall can go.
- **Result, arm u1+lean + q6_m13 (metal 1-3 walls) vs u1+lean, dev80:** #1 +2.7 [-1.5, +8.1], floor +1.8 [-1.1,
  +5.6]: no detectable change; better / worse 8 / 7. KIQYEQ worse in the solve too (203 -> 344, floor 195 -> 289: with
  the squashed boryl head the wall cannot pull the O off Cu without wrecking the other Cu-B-O angle), XIPLUD 217 ->
  319, XAQRUC 251 -> 312; JEFJUZ 313 -> 286, YOMGUC 231 -> 213. **Not adopted** (q6_m13 stays off). The 1-3 blind
  spot's cases (YAVFEG, COPYIP) were the Cp-H fold, now closed by the lean wall at its source.
- **Result, arm u1+lean + ez_enumerate vs u1+lean** (the 7 complexes with undecided E/Z bonds; 6 valid): floor -34.8
  [-87.0, -1.6] (better: CI excludes 0), #1 -34.3 [-88.7, +0.6], regret +0.5; better / worse floor 3 / 0, #1 2 / 0.
  SOKVET 372 -> 200 (floor 355 -> 200). JAYSUX first failed ("Bad Conformer Id": one combination cannot be embedded);
  fixed: an unembeddable combination is skipped, not fatal. **Adopted into profile u1.**
- **Queued arms and predictions (written before the runs):**
  - u1+lean + bound_surrogate, KIQYEQ only: #1 and floor below ~200 kJ/mol in every seed (the Bpin head no longer
    squashed); falsifier: not lower.
  - u1+lean + q6_model=pmf (plan U4, the PMF with H-bond wells only, summed; ez off so the arm differs in one field),
    dev80: #1 not worse, floor not worse; gains expected where H-bonds or close contacts decide the pick. Falsifier:
    #1 or floor worse with the CI excluding 0, or a BIDHEB-type compaction (10-14) among the #1s.
- **Results of the two queued arms (MACE in float64, `.mace64.json`, 2026-10-16 e; `tracks.py --energy mace64`).**
  The base u1+lean and the E/Z arm were re-evaluated in float64 too: E/Z unchanged (floor -35.3 [-88.2, -2.0]).
  float32 vs float64 on the 240 base pools: #1 dE differs by sd 3.8 kJ/mol (max 25, mean -0.3): noise, no bias.
  - **bound_surrogate (KIQYEQ): prediction met for the floor, 2 of 3 seeds for #1.** Seed medians #1 212 -> 30, floor
    204 -> 29 (per seed #1 30 / 22 / 232, floor 30 / 22 / 29). The head is now right in every conformer (B-O 1.35 A,
    O-B-O 113 deg). Seed 13's #1 is a different failure: the boryl is not bound (Cu...B 2.97 A; the bound pose,
    29 kJ/mol, ranks 2nd by 0.03 / complex). The Cu-B Q1 table (`('Cu','B_donor')`, n = 33, pooled) has a broad
    component at 2.83 A (sd 0.61 A, weight 0.31), so detaching B costs only 3 nats of Q1, and the bound pose loses
    3.2 nats in Q6. That is a Q1 data question (what are tmQM's 2.8 A "Cu-B bonds"), not the embed. **Adopted into u1**
    (it changes only the start geometry of group-13 D=[X+] donors; KIQYEQ is the only such dev80 complex).
  - **q6_model=pmf: falsified.** #1 +33.1 [+8.3, +66.4] worse, floor +28.3 [+6.7, +57.5] worse, regret +4.8
    [-0.6, +10.7]; better / worse #1 15 / 35. Gains PEWBOL 428 -> 231, JEFJUZ 317 -> 258; losses XAQRUC 251 -> 1166,
    VUJYEG 275 -> 936, KIQYEQ 212 -> 467. **Not adopted**; plan U4 (PMF replaces the walls) fails as designed. The
    walls stay; the XAQRUC / VUJYEG blow-ups are the place to look if the PMF is revisited.
- Full suite on `_q6p5` (legacy profile) after every change above: 272 passed, 3 xfailed, 0 failed (8 new tests in
  `tests/test_unified_objective_2026_10_16.py`; the time-budget test no longer flaky).
- **U4 code in (not yet measured): core-only metal 1-3 Q6 class** (`q6pmf.M13`, `metal_13_pairs`, `m13_records`;
  runtime adds the pairs to the PMF sum; tables zero at and beyond the 0.1 % onset, GFN2-type core below, since the
  data region is already priced by the M-D-X angle of S_orient / the haptic bend). Histograms over the refit's training
  shards: `refit/q6_m13_hist.py hist | fit` -> `data/refit/final/constraints_refit_q6p5_m13.json` (a copy; the
  production DB is unchanged). Test: `test_m13_tables_are_core_only`.
- **G / D6 preparation (reading of `internal_stereo.txt`):** with crystal internals (full_oracle) E/Z mismatches drop
  6 -> 2 and puckers 4 -> 2, but sp3 stereocentre mismatches stay 6 -> 6: those are centres created by binding (which
  face of an N / P / S binds), set by the solve, not by the embed. The embed-only failure is E/Z, and it is the
  expensive one (SOKVET 525 kJ/mol, YAVFEG 332, JEFJUZ 210). The unassigned bonds are all imine-type (C=N, N=N:
  Schiff bases, amidinates, hydrazones), mostly in or next to chelate rings where `CHELATE_EZ` should already decide
  them: first step of D6 is to find why it did not. Triage of the 5 worst: (1) bonds the rule never sees: SOKVET
  (second donor is a haptic face; the rule pairs kappa donors only), CBTYCO (exocyclic N=C off the donor-donor path):
  ETKDG's coin flip, the D6 enumeration case; (2) bonds the rule fixes but the #1 still mismatches: YAVFEG, VUYWIX,
  JALSEY: either the rule predicts the wrong configuration there or the mismatch metric counts another bond; to be
  checked bond by bond before relying on the rule's 22 / 22 (N48, 09-30).
  Checked: the rule is right on all 5 bonds it fixes there (crystal dihedrals), and 97-100 % of those pools' members
  carry the crystal configuration: the "mismatches" were other bonds (the metric labels by geometry, not RDKit
  stereo bonds). The bonds the rule never sees are wrong in EVERY pool member (SOKVET N8=C9, CBTYCO N3=C4: 0 %).
  dev80 has 10 such undecided bonds in 7 complexes (5 C=C, 5 C=N), at most 4 combinations per complex.
- **D6 E/Z enumeration, code in (profile field `ez_enumerate`, default off):** `chelate_embed.undecided_ez /
  ez_variants / set_ez`; `ComplexBuilder.solve` solves each combination (cap 2^3) and merges by score with the output
  window across them (`embed_idx` = combination). Configurations written in the SMILES and bonds the chelate rule
  decides are never enumerated (owner rule; test `test_ez_enumeration_keeps_given_stereo_and_chelate_rule`).
  First check (CPU, seed 11, legacy score): the score's #1 picks the crystal configuration on every undecided bond of
  SOKVET (combination score -1.15 vs -2.1 to -3.6 for the other three) and CBTYCO (0.78 vs 0.20). Energies and the arm
  follow once the GPU is free.
- Fixed on the way: `site_enumeration` time budget used `time.monotonic` (15.6 ms ticks on Windows: a zero budget
  never truncated, a flaky test) -> `perf_counter`; `gate.py --profile` and `forces.py report` imported jacobik before
  putting src on the path.

## 2026-10-16 c (U0: one place for every result-changing setting; discarded variants removed) -- defaults unchanged
Owner (10-16): "I don't want 30 different variants and not knowing which ones are used where"; plan U0-U3/U4/G/H
(unify the solve objective and the ranking score; justified widths; one physical Q6).
- **NEW `src/jacobik/profile.py`.** Every result-changing setting is a field of a named profile
  (`legacy-2026-10` = production as of 10-16 b, bit-identical); `JACOBIK_PROFILE` selects it,
  `JACOBIK_PROFILE_OVERRIDES` (JSON field -> value) overrides fields for an experiment; modules read their globals
  from it at import (`profile.get`); `profile.snapshot()` reads the live module attributes (in-process tools such as
  gate.py still set them) and is recorded in every result: run_panel / bench JSON (`"profile"`), pools.py npz.
  27 fields: score (11), embed (4), degrees of freedom (9), output (3). Table: SCORE_SCALE.md section 7.
- **Retired environment switches raise** (`profile.RETIRED_ENV`): the 27 old per-setting switches and the removed /
  frozen ones; a benchmark arm that still passes one fails instead of silently running the default. `bench.py` arms
  pass `JACOBIK_PROFILE_OVERRIDES` (test_devices updated); `tools/q6_ablation/q6_core_ablation.py` ported (WCA arms /
  rankers removed, results kept in its report).
- **Removed (SCORE_SCALE.md ledger):** `Q6_MODEL="wca"` (+ `Q6_WCA_N/T`, `q6_wca_cost`), `SHAPE_CORE / TAIL /
  TAIL_FORM / TERMS` (+ helpers), `Q5_TEMPER`, `RING_LEAN`, `RING_KEEP_FOLDS`; tests `test_q6_wca_core`,
  `test_shape_lp_math`, `test_shape_switch_on_a_solve`. **Frozen as constants:** `CARBON_STRUCTURAL`,
  `RESONANCE_LABELS`, `HAPTIC_V2`, `SHAPE_LABELS` (geometry labels), `Q6_METAL_EXCL` = 2, `Q6_THROUGH_METAL`.
- Not yet profile fields (listed in SCORE_SCALE.md 7.4): `CLASS_BUDGET`, `EARLY_CULL_AT`, plateau / cull constants,
  `_LSE_TEMP`, `_Q6_LSE_TEMP`, `_GMM_VAR_MIN` (the 0.2 A floor), `SHAPE_TOL_P90`. U2 / U3 replace or justify them.
- Execution-only switches stay environment variables (GPU replay / fast FK, workers, dedup device, MACE, xtb).
- Tests: `test_profile_fields_overrides_and_retired_switches` (subprocess: defaults, overrides, retired switch raises,
  unknown field raises). Full suite on `_q6p5`: 264 passed, 3 xfailed, 0 failed.
- Left: `notebooks/01_benchmark.ipynb` mentions `JACOBIK_DONOR_BENDS` (would raise; switch it to the override form).

## 2026-10-16 b (ensemble stance; isomer-matched track; data-vs-solver oracles; output score window; curvature)
Owner request (10-16): formalise conformer vs Boltzmann / isomer vs basin; stop the 1000+ kJ/mol members; trace the
problem complexes into data vs solver (crystal-positioned statistics); a measurable route to an energy-like score
(curvature, for the later 2-shot relaxation). Plan: ENSEMBLES.md. Refit DB `_q6p5`, dev32 + N48 pools in
`data/energy_scale_refit` unless stated.

### Predictions (written before the runs they concern)
- **A' isomer-matched track** (`pools.py --isomer ref`). I vs O, #1: median change small (-5 to 0 kJ/mol), mean lower,
  driven by the ~10-20 % of complexes whose open pick is another isomer; floor not lower (the open pool can hold
  lower isomers); regret lower (fewer competitors). Falsifier: median #1 drop > 20 kJ/mol (then isomer choice, not
  precision, was most of the "neutral" results).
- **Crystal internals on the refit DB** (O+int vs O): about halves the #1 as on v6 (N48 69 -> 31).
- **Crystal-positioned statistics** (I+tgt vs I; I+int+tgt vs I+int; `--targets crystal`, oracle_targets.py): a
  moderate gain, #1 median -10 to -25 kJ/mol (P0: the tables prefer the solved value for 37 % of off donors and 67 %
  of off D-M-D angles). Falsifier: < 5 kJ/mol -> data positioning is not the lever; the solver (search, Q6, frozen
  internals) is. Residual I+int+tgt #1 = the solver line, predicted median 20-30 kJ/mol.
- **Curvature (E1, forces.py)** at the crystal and at the top-4 pool conformers, energy/kT vs score along the soft
  DOFs: rigid-body directions (where Q1 / Q2 / S_orient act) energy-to-score ratio > 3 (cores too soft, METHODOLOGY
  4.3); torsions closer to 1 (Q5 ~1 kT/nat). Falsifier: ratios ~1 everywhere (then curvature is not why the floor is
  high).

### Done (no change to the default solve except the output window and the cache key)
- **NEW `ENSEMBLES.md`**: definitions (isomer class, basin, snapshot, conformer vs Boltzmann ensemble), the reference
  as one isomer's minimum, two benchmark tracks, metrics per level, preconditions for a Boltzmann mode.
- **NEW `tools/jdev/budget/ensemble_stats.py`**: bond-graph check of every GFN2 relaxation, basin labels, rho_isomer /
  rho_within (owner: two rho), rho_basin, strain of the #1. v6 (116 relaxed pools) / refit (80):
  - The -218 to -592 kJ/mol "lower than the reference" relaxations (JAYSUX, LEBNOX, QOSGIP) broke a bond: artefacts.
    Real lower basins (> 10 kJ/mol below the relaxed reference): 16 % / 7 % of pools (largest PEWBOL -90 / -64).
  - #1 strain (SP - relaxed) median 103 / 88 kJ/mol; its basin +2.8 / +5.6 above the reference basin; pick in the
    lowest relaxed basin 47 % / 41 %; reference basin in the pool 88 % / 89 %.
  - two rho (MACE SP, median over pools): rho_isomer 0.60 / 0.59 (pools with >= 3 classes), rho_within 0.68 / 0.68.
    The owner expected within to be much worse: it is not on single points. On RELAXED energies the score barely
    ranks isomers (0.48 / 0.20) or basins (0.22 / 0.15): it ranks snapshots by strain, not minima by energy.
  - Pools are multi-basin: relaxed energies spread a median 50 kJ/mol per pool; 60-80 % of returned conformers relax
    to distinct basins (v6, by energy / RMSD criteria). (Correction of the plan's guess that most were snapshots of
    one basin.)
- **NEW `tools/jdev/budget/validity.py`** (offline, fixed pools): per conformer, Q1 distance to the nearest mode (sd,
  A), Q1 wall excess, min Q6 d/mu, min heavy-atom contact >= 3 bonds, score gap below the pool best (summed nats).
  Refit 240 pools / v6 348 pools: 10.6 % / 8.6 % of conformers > 1000 kJ/mol; their donor sits a median 0.9 / 0.55 A
  from every Q1 mode and 787 / 375 nats below the pool best. Filters (refit / v6): score window 200 nats removes
  92 % / 78 % of > 1000, 0.6 % / 0.4 % of conformers within 50 kJ/mol of the floor, no isomer class with a good member,
  no #1 changed (floor lost in 2 / 3 pools: TAPWUG, whose whole pool has a donor ~1 A off its table). Q1-distance
  filters empty pools (TAPWUG); steric filters catch little.
- **Output score window, default ON (`engine.OUT_WINDOW`, `JACOBIK_OUT_WINDOW`, default 200 summed nats, 0 = off).**
  Rows more than 200 nats (score x Z) below the best row are not returned; applied before the dedup counts slots.
  The #1 cannot change. Test `test_output_window_drops_only_rows_far_below_the_best`. `engine.output_window` is shared
  with the benchmark's multi-seed assembly (`tools/jdev/multiseed.py`, which bypassed it at first:
  `test_seeds_in_one_pass_match_separate_solves` caught it). Full suite on the refit `_q6p5` DB before that fix: 264 passed, 3
  xfailed, 2 failed (that one, fixed and re-run with test_gpu_fast_path.py: 20 / 20 pass) and `test_enumerate_assignments_time_budget_can_truncate` (pre-existing, untouched code: a zero time budget
  is expected to truncate, but the 720-permutation enumeration finishes inside one Windows timer tick).
- **Score blind spot found: metal 1-3 contacts.** The > 1000 conformers the window misses (COPYIP 33, YAVFEG 29 of 78)
  score like the best conformers on every term. COPYIP s12 #1 (866 kJ/mol MACE, 884 GFN2): a Cp ring H points into W
  (W...H 2.10-2.22 A; good conformers ~3.0 A). The pair is metal 1-3 (W-C-H), excluded from Q6 by design, and the
  haptic orientation term hardly changes; same class as BIDHEB's Pd...O (10-14). Over all refit pools, the closest
  atom two bonds from the metal sits at a median 1.78 A in > 1000 conformers vs 2.90 A in good ones (relative to the
  pool median: 0.58 vs 0.97; < 0.8 x flags 82 % of > 1000 and 88 % of those the window misses, 0.7 % of good). A plain
  M-D-X angle cut is too blunt (good conformers reach 57 deg). Candidate score fix (not done): fitted metal 1-3
  walls (Q6 class "m13") so the solve sees the contact, not only a filter.
- **FIX `engine._gfn2_refine` cache key** now includes the start geometry: keyed on SMILES alone, every embed seed after
  the first got the first seed's GFN2 geometry, so `solve_multi_embed` under the default embed returned one embed n
  times. Test `test_gfn2_cache_keyed_on_start_geometry`.
- **Beam audit (D1):** distinct torsion seeds per ligand (16 slots): median 12; ligands with 1 joint 4, 2 joints 7
  (exhaustive: padding repeats them), > 4 joints 14-16 (top-16 of up to 3^J combinations; shared by every
  assignment and coordinate sample).
- **NEW `tools/jdev/budget/isomer.py` + `pools.py --isomer ref`**: the reference's donor -> site assignment (best proper
  rotation of the ideal polyhedron + Hungarian; mirror images distinct); resolves 80 / 80 dev complexes (median 10 deg
  off the ideal sites, max 25: JEFJUZ). Output `pools/<start>_isoref/`.
- **NEW `tools/jdev/budget/oracle_targets.py` + `pools.py --targets crystal`** (DIAGNOSTIC): every Q1 / Q2 / Q5 /
  S_orient curve translated so its nearest mode sits on the crystal value (widths, weights, folds kept; the Q1 wall
  moves along; crystal H mapped per parent by position). `--targets reach` (closest reachable pose: the solver driven
  to the crystal) was tried and dropped: without the score's other terms the closest poses clash (CUWMEP best
  +12 400 kJ/mol; with Q6 kept still +45 000) and NAPNID at 0.26 A RMSD sits at +278 vs the production #1's +129, so
  "closest" is not a meaningful energy floor here.
- **NEW `tools/jdev/budget/forces.py`** (E1): curvature of MACE energy vs each score term along the soft DOFs
  (rigid-body + rotatable bonds, central differences, 0.1 A) at the top-4 pool conformers and the crystal. (A first
  version compared gradients with MACE forces: meaningless, the pool conformers are stationary points of the solver's
  score.)
- **NEW `tools/jdev/budget/tracks.py`**: paired comparison of the arms (O, I, +int, +tgt) and the problem-set shares.
- **NEW `tools/jdev/budget/internal_stereo.py`** (owner: is isomer choice also cis/trans / ring stereo inside the
  ligands?) and **`export_xyz.py`** (`data/inspect/<CODE>/`: reference, top-5 / floor / all frames per arm).

### Results vs the predictions (`data/energy_scale_refit/tracks_report.txt`; 76 valid complexes x 3 seeds, CUDA)
| arm | #1 median / mean | floor median / mean |
|---|---|---|
| O (production) | 73.9 / 115.3 | 61.1 / 90.5 |
| I (reference isomer) | 74.2 / 143.1 | 68.6 / 116.1 |
| O+int (crystal internals) | 36.7 / 68.5 | 25.6 / 43.4 |
| I+int | 34.1 / 72.1 | 25.4 / 47.6 |
| I+tgt (statistics on the crystal) | 84.4 / 141.9 | 64.8 / 114.0 |
| I+int+tgt | 30.2 / 67.2 | 20.4 / 41.5 |
- **A' isomer: prediction half right.** I vs O #1 median +0.1 (predicted ~0), mean +27.8 [+5.5, +55.1] (predicted
  lower: falsified). Forcing the crystal isomer makes some complexes much worse (FIGHOT 209 -> 475, TAPWUG 643 ->
  1229, COPYIP 118 -> 181): the solver handles the crystal isomer worse than its own choice there. Isomer choice is not
  what made the earlier changes look neutral. (I pools hold 16 conformers, O pools 32: the floor comparison favours O.)
- **Crystal internals: as predicted.** O+int vs O #1 median -24.8, mean -46.8 [-72.5, -18.2], 53 better / 9 worse;
  floor -29.6. The refit did not change the internals line (v6: N48 69 -> 31).
- **Crystal-positioned statistics: falsified on the set.** I+tgt vs I #1 median +3.3, mean -1.2 [-16.4, +13.1];
  I+int+tgt vs I+int median -0.4, mean -4.8 [-26.4, +11.8]: no detectable change (predicted -10 to -25). Where the
  tables put their modes is not the general lever. On the problem complexes it is large but only together with
  crystal internals (SOKVET 97 -> 15, JIHMAR 555 -> 7, LEBNOX 84 -> 14, IDAVES 17 -> 2, XAXGOW 31 -> 7): with the wrong
  ligand shapes the tables cannot all be satisfied at once. Problem set (26 complexes, open #1 >= 100), median shares
  of the open #1: isomer 3 %, internals 61 %, data positioning 10 %, residual with everything at the crystal 36 %
  (median 58 kJ/mol; TAPWUG 479, PEWBOL 438, YAVFEG 179, FIGHOT 148, DUKMED 113, JAYSUX 99).
- **Ligand-internal configuration (owner's cis/trans question)**: 16 / 80 open #1 picks carry a configuration the
  crystal does not have (6 with a stereocentre, 6 E/Z, 4 ring puckers); their #1 median 99 vs 69 kJ/mol. SOKVET (525):
  two wrong E/Z bonds; crystal internals take it to 70. tmQM SMILES have no stereo tags, so the embed picks at random
  and the solver can never repair it (internals frozen). 10 remain with crystal internals: solver-chosen (partial
  double bonds that are torsion joints, macrocycle folds).
- **TAPWUG (Pt N^C^N pincer, 643): a beam failure.** Both pyridyl N sit 3.0-3.2 A from Pt in every arm, even with
  crystal internals: the pyridines are flipped 180 deg. Q5 for both pyridyl-aryl joints has weight ~1 on the crystal's
  180 deg mode, but every beam row takes the ~0-weight 0 deg mode (kappa 502): the beam scores a mode by the density at
  its mean (log w - log 2 pi I0e(kappa)), so a narrow, nearly weightless spike beats the broad dominant mode (beam Q5:
  3.19 for (0, 0) vs 0.27 for the crystal's (180, 180)), and the beam never sees the metal. The optimiser cannot turn a
  pyridine through the metal afterwards. Over the dev set: 34 multi-mode joints in 16 complexes have every beam row on
  a mode with < 20 % of the dominant mode's mass (AFANAY, BULGAT, CUWMEP, DEVFUG, ETAXEC, FETSUU, IYONIW, JAYSUX,
  KIQYEQ, LEVVUH, NIMJAW, SOKVET, TIFRUX, VUYWIX, XAJQEI, YAVFEG).
- **FIGHOT (Zr, two 11-membered N,O,N macrocycles, 209): macrocycle folds.** Ring torsions differ from the crystal by up
  to 119 deg in the open pick and with crystal internals (the folds come from the macro pool and the macro joints,
  not from the frozen embed); every Zr-N/O is stretched (2.25 vs 2.09 A); forcing the crystal's fac arrangement on the
  wrong fold costs more (475).
- **Curvature (E1): falsified, the other way round** (`curvature/report_etkdg.txt`; 80 complexes, 15 055 directions).
  The RANKING score is 2-3x too STIFF along the soft DOFs (median energy/kT : score curvature 0.3-0.8 by DOF type),
  not too soft; which directions are stiff agrees with the energy (spearman 0.65 at the crystal, 0.74 at the top-4).
  Per-term NNLS scales at the crystal (1 = energy-like): Q1 0.06 [0.03, 0.14], Q2 0.25 [0.01, 0.50], S_orient 0.80
  [0.30, 2.02], Q5 0.00 [0.00, 0.06], Q6 2.88 [1.78, 3.93] (R^2 0.25). (Q5's ~0 NNLS weight does NOT mean "no
  curvature": Q5 acts on torsion directions only; alone, its torsional curvature matches the energy's, energy/Q5 0.85
  at the crystal, 0.73 at the top-4. Corrected in SCORE_SCALE.md.) Reading: Q1 tables contain needle components
  (fit sd 0.01-0.02 A; a physical M-D stiffness corresponds to ~0.06 A), so at fit floors Q1 is ~20x too stiff; Q6
  walls are ~3x too soft; S_orient is calibrated. This does not contradict METHODOLOGY 4.3 (kT per nat between
  conformers, i.e. finite moves across a multi-modal table) but it changes the reading: the problem is needle modes
  in the ranking tables, not a uniformly soft core.
- **Curvature of the SOLVE objective** (`curvature_solve/report_etkdg.txt`; scorer floors, per-quantity means, Q6
  soft-min, x Z): per-term NNLS scales at the crystal Q1 4.67 [3.62, 5.95], Q2 0.65 [0.46, 0.81], S_orient 0.44
  [0.28, 1.44], Q5 0.01 [0.00, 0.02], Q6 0.17 [0.04, 0.37] (R^2 0.58 with fitted scales, -0.74 with production's
  unit scales); top-4 pool points the same (Q1 4.24, Q2 0.47, SO 0.32, Q5 0.02, Q6 0.00; R^2 0.52). Stiff directions
  agree with the energy (spearman 0.61 / 0.66). Reading: the objective the optimiser follows is ~4.5x too SOFT in Q1
  (the 0.2 A scorer floor), ~2x too stiff in Q2 and S_orient, ~4x too stiff in Q5 along torsions (energy/Q5 0.22-0.25;
  from the per-quantity MEAN aggregation, which up-weights Q5 relative to its summed value: the tables themselves are
  about right, see the ranking score), and the soft-min Q6 carries almost no curvature. Ranking and solve thus
  err in OPPOSITE directions on Q1 (ranking ~20x too stiff, solve ~4.5x too soft). A per-term curvature rebalancing of
  the solve objective is the first literature-backed (force / curvature matching) calibration with a measured target;
  it explains about half of the directional energy curvature (R^2 0.55) where the production weights explain none.
- **NEW `SCORE_SCALE.md`** (owner: formalise the terminology and the ledger): the two scores and their five differing
  settings, four properties of a term (position, well weights, local stiffness, tail), the curvature table, Q6 design
  history (the PMF is the R_core + angular H-bond design; never run as a solver arm on the clean DB), words with two
  meanings (pool floor vs variance floor, ring fold vs rotor folding, coordination isomer vs internal configuration),
  and what stands / is reinterpreted / is discarded / is open. METHODOLOGY 4.3's "Gaussian cores too soft" is
  reinterpreted: true for the solve objective's Q1 only; the ranking score's Q1 / Q2 are too stiff.

## 2026-10-16 (refit benchmark; output dedup 2x faster; post-refit experiments: predictions BEFORE the runs)
- **FIX benchmark validity check (`tools/jdev/bench.py` `_valid`, `run_panel.py` `n_donor_atoms`).** A case counted as
  "invalid input" when the donor GROUPS given to the solver differed from tmQM's MND, but MND counts every metal-bonded
  atom (Cp 5, arene 6, eta2 2): 33 of 108 dev32 / N48 / heldout28 cases were dropped, 24 of them correct haptic inputs,
  i.e. the paired tests were biased toward simple complexes. Now donor ATOMS vs MND (older result files: the table in
  `data/benchmark_runs/2026-10-16_post_refit/donor_atoms.json`); 7 cases still differ (XINMOA, YEHTAG: more donor
  groups than MND; TALRIH, EHUZAI, VEGMIH, PUSSIF, BIDHEB: off by 1-2 atoms, possibly MND conventions; not checked
  one by one) + AXUVEV / IJEVIC (no SMILES). All results below use the corrected check.
- **Benchmark v6 vs the refit DB** (`data/benchmark_runs/2026-10-15_refit1/`, `analysis_atoms.txt`; N48 26 +
  heldout28 22 complexes without the metals the run-1 bugs touched, seeds 11-13, CUDA, MACE every conformer; 43
  complexes valid). `refp5` (refit, 5th-percentile walls) vs v6, #1 |dE|: N48 +1.6 [-16.8, +28.1] (MDE 33),
  heldout28 -27.4 [-61.7, -3.9] (BIDHEB, GIZGUR catastrophes gone), pooled -9.9 [-28.3, +9.8]: no detectable change.
  (With the old group check: pooled -24.8 [-48.6, -5.0] on 36 complexes; that number was an artefact of the subset.)
  Same picture on the 80 dev complexes from the error-budget pools (v6 pools of 10-15 vs refp5 pools, same code
  otherwise, `data/energy_scale_refit/compare_v6_pools.txt`): #1 -0.2 [-26, +30], floor -5.2 [-22, +13], regret +4.7
  [-8, +19]; top-1 N48 0.45 -> 0.36, dev32 0.49 -> 0.45. **The refit by itself is neutral on the dev set.**
  `ref` (onset walls) vs v6: #1 pooled +52.3 [+22.9, +84.5]: the onset wall loses again on clean data (as 10-14), so
  the q6alt question is settled: the 5th-percentile wall stays. Base for every experiment below: `refp5`.
- **`ik/dedup.py` (same selections, faster).** Profile of the slowest benchmark complex (YAVFEG, 3 seeds in one pass):
  output dedup 104 s vs solver 20 s. The selection only needs "is some automorphism within 0.5 A", not the minimum:
  `_full_any` discards (row, automorphism) pairs by a per-automorphism radial lower bound (one matrix product) and a
  Frobenius upper bound on the overlap, then Newton stops as soon as the iterate falls below the needed overlap
  (monotone from above) or converges above it; `_upper` is no longer tried first (it rarely decided).
  `deduper_for(mol)` reuses the automorphism enumeration across seeds. With at most 48 automorphisms (`BLOCK_MAX_MAPS`)
  `select` works in blocks of rows (`_pair_dup`: every (block row, kept row) decision at once, then the block in
  order): there the per-row loop of small tensor operations was the cost (VOSCAK 2 304 rows, 4 automorphisms). Above
  48 the row-by-row scan with early exit wins (blocks lose it: JEFJUZ 3.6 -> 44 s), so both are kept. On 46 benchmark
  complexes x 3 seeds (captured solver rows, 6 CPU threads): identical selections 138 / 138 for each path; total
  144 -> ~38 s (YAVFEG 42 -> 15 s, VOSCAK 17.5 -> 0.6 s, VEGMIH 13 -> 2.6 s, PUSSIF 9 -> 0.4 s).
  Test `test_dedup_pruned_decision_matches_full_scan`. On the GPU the same code is slower except for YAVFEG (per-row
  sync latency), so DEDUP_DEVICE stays "cpu".
- **`tools/jdev/budget/pools.py`:** `JACOBIK_BUDGET_DB` selects the pools' DB (default v6); the solve stage records it
  in `<OUT>/pools_db.txt`, and gate / coord_audit refuse pools of another DB.

### Post-refit experiments: predictions (written before any of them ran; METHODOLOGY section 3)
Pools: `JACOBIK_BUDGET_OUT=data/energy_scale_refit`, `JACOBIK_BUDGET_DB=data/refit/final/constraints_refit_q6p5.json`,
dev32 + full N48 (80 complexes; the hydride / M...H fixes make the excluded metals usable), seeds 11-13.
- **P0 (coord_audit, no solver).** Refit predictions 1 and 5 (METHODOLOGY 4.6): of the #1 picks' M-D distances off by
  > 0.05 A, the share whose Q1 table prefers the solved value drops below v6's ~50 %; of D-M-D angles 5-30 deg off,
  the share the Q2 table prefers drops below 72 % (A4 site-pair key). Falsifier: no drop -> the coordination-sphere
  line is a statistics problem the refit did not fix, and core reshaping of Q1 / Q2 (P1) cannot act on it.
- **P1 SHAPE_CORE=4, SHAPE_TAIL=8 (exp; Q1, Q2, S_orient) -- primary configuration, fixed now.** Line: ranking regret
  (median ~6, mean 12-50 kJ/mol) via the gate; coordination sphere via generation. Mechanism: the core of the
  Gaussian-type terms charges 3-6 kT per nat (too soft), the tails grow without bound (too steep); x4 at the core and
  saturation at 8 nats move both toward Q5's ~1 kT / nat. Prediction (gate): mean regret down, pick mean down by a
  few kJ/mol, top-1 not lower. Risk, stated in advance: capped tails stop vetoing broken conformers (how linear
  re-weighting dropped top-1 0.47 -> 0.32). Falsifier: pick worse with the CI excluding 0, or top-1 down by > 0.05.
  Exploratory grid (CORE 2 / 4, TAIL 8 / 16, form log), reported as exploration only.
- **P2 Q6_MODEL=pmf, Q6_PMF_WELLS=hbond.** First DB whose PMF tables were really fitted (merge bug), without hydride
  contacts or benchmark codes. Line: torsions / periphery (33 %), through generation mostly; the gate sees its ranking
  part. Prediction: gate neutral to slightly better (H-bond wells reward real H-bond geometry; repulsive cores like the
  walls elsewhere). Falsifier: gate pick worse (CI excludes 0) or #1s with compacted peripheries (BIDHEB type).
- **P3 Q6_AGG=sum (steric term summed in the solve; ranking unchanged).** Generation only, so no gate: straight to a
  solver arm. Line: torsions / periphery. Prediction: fewer Q6 pairs < 0.85 mu in the #1s, floor lower on crowded
  complexes, neutral to slightly worse on uncrowded ones; overall #1 mean -5 to -10 kJ/mol (10-14 `wall_sum_v6`:
  median -1.3, 11 better / 6 worse on dev32). Falsifier: #1 or floor worse with the CI excluding 0.
- **P4 Q6_MODEL=wca, n = 6, on the 5th-percentile walls.** Low prior (`wca6_v6` +3.8, n.s.). Gate only; dropped
  without a gain.

### Post-refit experiments: results (vs the predictions above)
- **P0 coordination audit** (`data/energy_scale_refit/compare_coord_audit.txt`; seed-11 #1 picks, the 80 complexes
  both audits cover, v6 -> refp5). Q1: donors > 0.05 A off 42 % -> 43 %; of those the table prefers the solved value
  45 % -> 37 % (69 % multi-modal tables). Q2: pairs 5-30 deg off 30 % -> 22 %; table prefers solved 72 % -> 67 %.
  Pairs > 30 deg off 6.9 % -> 9.7 %, table prefers solved 93 % (arrangement differences the Q2 table accepts: a basin /
  assignment question, not widths). **Direction predicted, size small:** the tables still accept most moderate
  distortions; the coordination-sphere line remains largely a statistics (resolution) problem.
- **P3 Q6_AGG=sum, solver arm** (`data/benchmark_runs/2026-10-16_post_refit/analysis_base_q6sum.txt`; dev32 + N48,
  76 valid complexes, 3 seeds). #1: pooled -9.9 [-25.9, +3.2] (median -0.9, better / worse 16 / 15, MDE 22): not
  detectable. Floor +4.6 [-0.8, +10.6] (not lower: the predicted mechanism did not show). Regret -14.5 [-29.3, -2.7]
  (better; N48 -14.0 [-32.9, -0.6]); top-1 dev32 0.46 -> 0.52, N48 0.31 -> 0.42; rho_lo N48 0.42 -> 0.51; catastrophes
  fixed (YAVFEG 673 -> 323, TAPWUG 881 -> 544, COPYIP 360 -> 102), some losses (FIGHOT +116, JIHMAR +83, GIQQAA +72).
  Solve median 1.63 -> 1.17 s. Reading: the summed steric term in the solve does not find lower-energy conformers; it
  produces pools in which the (unchanged) ranking picks better, i.e. fewer clashing decoys that outscore good
  conformers. The #1 effect is within the noise; the regret / top-1 gain is the signal to confirm.
- **Re-rank gates** (`data/energy_scale_refit/gates/*.txt`, per-pool CSVs; refp5 pools, dev32 + N48, 232 pools /
  78 complexes, MACE; candidate #1 vs production #1 on the same conformers, mean diff kJ/mol [95 % CI]):
  - **P1 SHAPE_CORE=4 SHAPE_TAIL=8 (primary): FAIL**, +79.5 [+1.2, +223]; medians 77.1 / 77.3, top-1 0.375 / 0.379,
    better / worse 12 / 14. Driven by TAPWUG (881 -> 6 103: the capped tails no longer veto a broken conformer, the risk
    stated in the prediction) and LAKDUW (97 -> 715). **Falsified as written.**
  - Exploration only: CORE 4 alone FAIL +11.6 [+0.6, +28]; TAIL 8 alone +66 [-2, +201] (no detectable change, same
    tail failures); CORE 2 TAIL 8 +71 [-1, +209]; CORE 4 TAIL 16 FAIL +80 [+2, +223]; CORE 4 TAIL 8 log form +4.2
    [-2.4, +13.2] (top-1 0.375 -> 0.405, better / worse 14 / 9; COPYIP +245, TAPWUG +197). No configuration ranks
    better; the bounded (exp) tail is the harmful part, the log tail is neutral.
  - **P2 Q6_MODEL=pmf (hbond wells): no detectable change**, +8.6 [-0.5, +23]; top-1 0.375 -> 0.392, better / worse
    19 / 21; COPYIP 363 -> 869. Prediction (neutral to slightly better) not met; leaning worse. By the protocol it can
    still act only through generation (its main predicted route); a solver arm is the remaining test.
  - **P4 Q6_MODEL=wca n 6: FAIL**, +8.0 [+0.2, +18.2]; dropped as planned.
  - COPYIP gets worse under every candidate (its production #1 relies on the steep tails).
- **Summary.** On clean data: the 5th-percentile wall beats the onset wall (settled); no scorer reshaping tested here
  ranks better than production; the summed steric term in the solve (P3) improves ranking regret / top-1 but its #1
  gain is below this design's MDE (22 kJ/mol pooled). Defaults unchanged.

## 2026-10-15 b (refit audit before the full run: LnQM export, independent structures, PMF fixes)
Owner request: check extraction + refit end to end before the one big refit. Mini end-to-end refit (700 complexes per
tmQM split + 1 500 LnQM, all stages) run three times; the full run follows (`data/refit/refit_run.log`).
- **NEW `refit/export_lnqm.py`** (the exporter lived on the laptop): lnqm.h5 -> tmQM layout
  (`data/refit/source/lnQM`; stage clean runs it when missing). Coordinates 'coord' Bohr -> A; S = unpaired electrons;
  charge read as int64 (stored uint64). **Ligand-internal bond orders from GFN2-xTB Wiberg, metal-ligand from the DFT
  Mayer orders.** LnQM's Mayer orders are unusable inside ligands (aromatic C-H at 1.09 A: -1.0 to +0.38 or absent;
  aromatic C-C at 1.40 A alternating 2.06 / 0.21); without SMILES the mapping reads them raw, so C-H bonds vanished
  and their H became Q6 contacts: the mini refit's C...H wall came out at mu 1.09 A, sigma 1.75 (39 / 4 000 LnQM C-H
  rows < 1.6 A). With GFN2 orders: 0 / 4 000, wall 2.43 / 0.32 (tmQM-only dev walls 2.43 / 0.30); rings aromatic
  (C-C 1.38-1.45). 0.1-0.2 s per entry, cached (`gfn2_wbo.npz`).
- **Independent structures (`stats.mixture.structure_id`).** LnQM is 1 205 ligand sets x up to 15 Ln (17 269
  entries). The evidence weights (fitter, pooling: 1 / rows of the same STRUCTURE per key) and the pooling's
  independent-complex counts use the ligand set; the held-out split (`refit_lib.holdout_mask`) hashes it (siblings
  were split across train / held-out); unweighted fits (S_orient training groups, QG / QP priors) take one sibling per
  ligand set at their metal-free and period-group levels; Q6 PMF histograms weight each sibling 1 / siblings.
  tmQM codes are unaffected (metal-specific keys see each sibling once anyway).
- **FIX Q6 PMF never fitted in the refit.** Shard histograms (`obs/shards/q6hist_<shard>.npz`) were never merged into
  the `obs/q6hist_<dataset>.npz` that stage fit reads; `merge_shards` sums them now (mini: 64 Q6P tables).
- **FIX benchmark codes in the PMF histograms.** The 10-14 entry said the refit's extraction leaves them out; it did
  not pass `q6_hist_exclude`. Now it does (histograms cannot be filtered after extraction).
- **Hold-out list + DEV32** (`benchmark_holdout_codes.json`): the 32 dev complexes of `tools/q6_ablation/dev_tmqm`
  (re-rank gate / error budget set) were in the training data; now held out (188 codes).
- **Found in the first full run (20:34; DB kept in `data/refit/final_run1_m_sub_early`, `final_no_state`), fixed,
  full re-run from clean (`data/refit/refit_run2.log`):**
  - **Hydride M-H bonds were Q6 "contacts"** (`mapping.raw_metal_bond_exclusion_pairs(q6=True)`, used by the Q6 keys
    and the PMF). The Q6 exclusion skipped every M-H edge below BO 0.75 (the donor-admission rule); 993 of 4 041
    terminal M-H bonds in tmQM (760 complexes) have Mayer BO 0.25-0.75. Fe...H wall 1.44 / 1.30 A (v6 3.00 / 0.57),
    Ru 1.55, Mo 1.63, Co 1.71, Rh 1.76, Mn 1.91 (sigma 1.2-1.8): no penalty for H on those metals. Now an H whose
    strongest bond is the metal is excluded from Q6 at any BO; agostic / bridging H stay contacts; donors unchanged.
  - **LnQM 1,3 artefact contacts were donors** (`export_lnqm.py`): Mayer M-X >= 0.08 on the central atom of k2
    carboxylates (C, 2.7-2.9 A) and nitrates (N, 2.9 A), Ln-N/O-C carbons (3.2-4.2 A: 1 289 C "donors" > 3.2 A in
    1 131 LnQM complexes; tmQM X1: 125 of 43 537), H on donor atoms. Dropped when X is covalently bonded to an atom
    that binds the metal more strongly and sits > 0.3 A closer AND GFN2 sees no M-X bond (9 948 contacts, list in
    `source/lnQM/dropped_13_contacts.csv`; < 3.0 A: 622 nitrate N, 379 carboxylate C, 17 H).
  - **Run 2 (22:54, DB kept in `data/refit/final_run2`):** M...H walls fixed (Fe 1.44 -> 2.13, Mo 1.63 -> 2.57,
    Mn 1.91 -> 2.46, W 2.28 -> 2.69 A; Ru / Co still sigma 1.18 / 0.94); Q1 `m_sub_early` (with both fixes the
    state-free lead shrank 0.013 -> 0.006, inside the old 0.01 band). But LnQM C "donors" > 3.2 A only 1 289 ->
    1 043: **LnQM's metal-ligand Mayer orders are unreliable too.** Over 1/4 of LnQM: contacts both Mayer and GFN2
    see 29 315 (median d / rcov 0.94); Mayer only 3 187 (median 1.32, 56 % beyond 1.3: e.g. Ln...C 3.6-3.8 A at
    Mayer 0.12 while the O donor it hangs on has Mayer 0); GFN2 only 1 182 (median 0.98: donors Mayer missed).
    New LnQM donor rule (`export_lnqm.py`): keep a contact if GFN2 >= 0.08, or Mayer >= 0.08 at d <= 1.15 x rcov
    sum; drop 1,3 artefacts (partner binds by either method). Export: contacts beyond 1.3 rcov 2 168 -> 421;
    raw CN 1-12 -> 4-11 (mode 7-8); Ln-O +2 050. **Run 3** (`data/refit/refit_run3.log`): only what changed was
    redone: the 5 LnQM shards + 11 tmQM shards a stopped full run had already truncated (`run_refit.py --shards`;
    the other 23 shard files kept: the clean stage re-derived identical TM thresholds, theta 147.5 and every
    3d/4d/5d cutoff; re-extracted X2 rows identical to run 2), selection re-picked from the cached held-out
    evaluations (Q1 `m_sub_early`, r 4 / 4, as in runs 1-2), full fit. **Final DB 00:04 2026-10-16:
    `data/refit/final/constraints_refit.json`** (+ `_q6p5`; not installed). LnQM C donors > 3.2 A 1 289 -> 1 043
    -> 432 (of 7 196 C rows); LnQM CN 4-11 (mode 7); M...H walls as run 2; element walls unchanged. Full suite on
    the new DB: 263 passed, 3 xfailed.
  - Q1 variant: selection now picks among state-keeping variants only (`Config.q1_require_state`, owner): run 1
    picked `no_state` (held-out 1.588 vs `m_sub_early` 1.575, outside the 0.01 preference band).
  - `fitter.fit_all`: keys sorted by size and dealt round-robin into chunks (run 1: Q5's last chunk 204 -> 668 s).
  - Tools for partial re-fits: `refit/refit_q1_variant.py`, `refit/refit_q6_only.py`.
- Parser failures are counted (`n_parse_failed`, reported per shard); stage fit expands the quantities in parallel
  (`refit_lib.expand_parallel`, 3 at a time: memory); Config `tm_dir` = data/tmQM (this PC's layout).
- `refit_lib.py` was read-only (copy attribute from 10-02); cleared to edit it.
- Seen, not changed: ~5 % of tmQM complexes fall back to heuristic bond orders (SMILES alignment fails); LnQM has many
  Ln-D distances > 3 A (mostly real: Ln-I / Ln-P ~3.0-3.2 A; some Ln...C 3.6 A contacts, for the data-derived
  second-sphere cut).
- **NEW scorer switch: energy-like shaping of Q1 / Q2 / S_orient (`SHAPE_CORE`, `SHAPE_TAIL`, `SHAPE_TAIL_FORM`,
  `SHAPE_TERMS`; env `JACOBIK_SHAPE_*`; default off = bit-identical).** Per term, around the table's peak log
  density p: pen = p - log p(x) is multiplied by SHAPE_CORE (x4 ~ widths / 2), then saturated at SHAPE_TAIL nats
  ("exp": bounded, like von Mises; "log": Student-t-like). Solve and ranking; read at call time, so
  `gate.py --override SHAPE_CORE=4 SHAPE_TAIL=8` tests it on fixed pools. For after the refit (owner, 10-15).
- Tests: `test_shape_lp_math`, `test_shape_switch_on_a_solve`. Full suite on the v6 DB (JACOBIK_TEST_DB): 263 passed,
  3 xfailed. Note: without JACOBIK_TEST_DB the DB tests use data/refit/final/constraints_refit.json, which the
  refit now writes (they skip until it exists).

## 2026-10-15 (error-budget study; benchmark statistics; re-rank gate; METHODOLOGY.md) -- solver unchanged
Owner request: why have correct-looking changes (Q6 onset wall, WCA, PMF, Hessian torsion widths) made results worse,
and how to predict outcomes before benchmarking. Nothing in `src` changes. Full numbers: `METHODOLOGY.md` S4.
- **NEW `tools/jdev/budget/`** (GPU solves + MACE, CPU GFN2-xTB): `pools.py` keeps every returned conformer with the
  production ranking score split per term (exact: 2e-7); `xtb_stage.py` GFN2 single points + loose relaxations;
  `xtb_dof.py` constrained relaxations (ligand internals frozen; `--coord` also the coordination polyhedron) for the
  split torsions / coordination sphere / internals / basin; `rmsd_stage.py` symmetry- and mirror-aware heavy-atom
  RMSD to the reference; `coord_audit.py` / `coord_report.py` per-donor Q1 / per-pair Q2 values at the pick vs the
  crystal and the table's preference (crystal remapped by the best graph automorphism: without it swapped identical
  donors showed fake D-M-D errors > 30 deg in 42 / 116 picks); `analyze.py` (error budget, kT per nat of each term,
  re-ranking incl. leave-one-complex-out learned weights), `decomp.py`; `gate.py` offline re-rank gate.
  Data: `data/energy_scale/` (v6 DB; N48, heldout28, ring10, dev32 x seeds 11-13; crystal-internals oracle seed 11).
- **Findings (v6 DB).** (1) Noise: identical code + DB on CUDA (10-03 vs 10-13) moved set medians up to 29 kJ/mol and
  rho medians up to 0.07; the onset / WCA losses of 10-14 are real (p < 0.001). (2) #1 = pool floor + ranking regret:
  N48 70 = 62 + 6, heldout28 104 = 82 + 8 (MACE medians); crystal internals halve the #1 (N48 69 -> 31). (3) The #1's
  GFN2 energy (116 complexes, share of the sum) splits into torsions / periphery 33 %, coordination sphere 26 %, frozen
  internals 34 %, wrong basin 8 %; 64 % of picks relax into the reference basin. (4) kT per nat within pools is non-linear for Q1 / Q2 / S_orient: 3-6 kT per nat near the mode,
  ~0.02 over the full range (steep Gaussian tails); Q5 ~1 throughout (bounded von Mises tails). Re-weighting the ranking to that scale is worse (top-1 0.47 -> 0.32), pairwise-fitted weights are not a detectable
  gain: not adopted. (5) Half the M-D distances are > 0.05 A off; for about half of those the (mostly multi-modal) Q1
  table prefers the solved value; D-M-D angles 5-30 deg off (31 % of pairs) are preferred by the Q2 table in 72 %. (6) MACE vs GFN2 within a pool: rho 0.92, rho_lo 0.71, same lowest conformer (1
  kcal/mol) 65 % -- the ceiling for any score's top-1 / rho_lo on one yardstick. (7) rho ~0.7 is unchanged on v6
  (0.61-0.78); within 50 kJ/mol of the floor it is 0.27-0.56. (8) A GFN2 loose relaxation of the #1, measured
  with MACE: median 82 -> 5 kJ/mol, > 200: 25 -> 0 of 116 (owner decision; not implemented).
- **`tools/jdev/bench.py`:** `_ensemble_metrics` adds `best_dE` (floor), `regret`, `rho_lo` (top1 / top3 now read
  from the scores, not the list order); `targets` reports `floor_median`, `regret_median`, `regret_mean`,
  `rho_lo_median`; NEW `paired_test` (per set: cluster-bootstrap CI of the paired mean, better / worse counts, minimum
  detectable effect, verdict). A/A check on the 10-03 / 10-13 runs: "no detectable change" in every set; MDE panel 5,
  N48 17, heldout28 69, ring10 194 kJ/mol.
- **`gate.py`** validated: its base re-score equals the stored ranking score (2e-6), same #1 in 32 / 32 pools; WCA n = 6
  on the v6 walls (dev32 + N48, 3 seeds, 240 pools): pick +2.8 [-0.9, +6.6] kJ/mol MACE, better / worse 12 / 20 -- no
  ranking gain, consistent with the 10-14 full solve of that arm.
- **NEW `METHODOLOGY.md`:** principles, the error budget, the decision protocol (prediction -> ceiling -> calibration
  -> re-rank gate -> paired benchmark -> held-out once), evidence and refit predictions.
- Tests: `tests/test_methodology_2026_10_15.py` (2).

## 2026-10-14 b (WCA steric core; Q6 core ablation tool)
- **Scorer switch `JACOBIK_Q6_MODEL=wca` (default "wall").** Per Q6 pair, a generalised Weeks-Chandler-Andersen core
  R = eps [(mu/d)^n - 1]^2 for d < mu (0 beyond), eps = mu^2 / (2 n^2 sigma^2), from the pair key's fitted wall
  mu / sigma: same onset, zero slope and curvature at the onset as the quadratic wall; n (`JACOBIK_Q6_WCA_N`, default 6)
  sets the hardening under compression (R / wall at 0.9 / 0.8 mu: 2.2x / 5.5x for n = 6, ~4x / ~20x for n = 12);
  continued linearly above `JACOBIK_Q6_WCA_T` = 50. Summed over pairs / the per-complex constant in the solve and the
  ranking; read at call time. No new fitted quantity; uses the refit's onset walls as they are. Proposal: external
  review of 10-14 (Astra), owner preference for simplicity/extensibility over the GFN2 core.
- **`tools/q6_ablation/q6_core_ablation.py`** (GPU, run on the PC): 6 solve arms (base_v6, wall_sum_v6, wall_soft,
  wall_sum, wca6, wca12) x 32 dev complexes (random tmQM X1 after the first 8000, no benchmark codes;
  `tools/q6_ablation/dev_tmqm`) x 3 seeds; MACE dE of every returned conformer; re-ranking of the union pool with 4
  ranking functions; geometry checks incl. the pairs Q6 excludes (ligand 1-4, metal 1-3); report.md / results.json.
  Dev onset walls (`q6_onset_walls_dev.json`) fitted on the first 8000 X1 complexes (C-C 2.97 / 0.32, C-H 2.43 /
  0.30, H-H 2.06 / 0.25 A), merged over the v6 DB at load. Local check: 1 case x 6 arms runs end to end (CPU).
- Test: `test_q6_wca_core`.
- **FIX `engine.py` GFN2 ligand pre-optimisation:** xtb output is no longer captured (it was never used; the geometry is
  read from xtbopt.xyz). On Windows the cp1252 decode of that output raised UnicodeDecodeError in subprocess reader
  threads and printed tracebacks (harmless, but noisy).

## 2026-10-14 (Q6 potential of mean force; experimental, scorer default unchanged)
Owner-approved redesign of the steric term (Q6 wall forms: owner Q&A 10-13/14; through-metal pairs incl. H: kept).
- **NEW `stats/q6pmf.py`.** Per Q6 key (polar-H keys included), bond-separation class ("4" = exactly 4 ligand bonds,
  "m" = with the metal, "5" = the rest, incl. other ligands and through-metal pairs) and, for polar H facing an acceptor,
  D-H...A angle class (>= 120 deg "lin" / "bent"): w(r) = -ln g(r) with g = p_key / (prior x p_ref), p_ref = the pooled
  distance distribution of every key of the class (an r^2 reference turned molecule size into 1-2 kT fake wells at
  4-5 A on 16k X1 complexes), prior = random-orientation share of the angle class (0.25 / 0.75). Below the key's 0.1 %
  onset r0: physical core w(r0) + kappa (exp(b (r0 - r)) - 1) from GFN2-xTB head-on dimer scans (H-H, C-H, H-O, H-N,
  C-O, Hp-O, Hp-N, C-C; O-O left out as electrostatic), generic b = 4.0 / A (H) or 3.2 / A otherwise, linear above
  50 kT; data region clipped to +-8 kT, tapered to 0 between 5 and 6 A. Evidence (16k X1 + dimers, 10-14): tmQM onsets
  sit at the GFN2 repulsion onset; the physics is far steeper than the walls (C...H 1.9 A ~+15 kT vs 1.5-1.8 nats);
  the PMF has the H-bond well (Hp...O -6.7 kT at 1.73 A; GFN2 -7.0 kT at 1.9 A), which the walls cannot represent.
- **Extraction (`extractor.extract_split(q6_hist=True, q6_hist_exclude=...)`):** uncapped histograms (0.02 A to 8 A)
  of every Q6 pair -> `q6hist_<split>.npz`; benchmark codes left out at extraction (refit `_extract_task`). ~60 ms/mol
  extra (Python pair loop). **Refit:** `merge_shards` sums them per dataset; `stage_fit` fits one set of tables over
  every dataset and adds `Q6P:` entries to `constraints_refit.json` (+ `final/q6pmf_summary.json`); `q6alt` keeps them.
  **Needs a fresh extract** (`run_refit.py all --force` or delete `data/refit/obs`), as do the 10-13 fixes.
- **`load_db` / `StatsLookup.q6_pmf_tables()`** read `Q6P:` entries (older DBs: {}).
- **Scorer switch `JACOBIK_Q6_MODEL=pmf` (default "wall").** Q6 = -sum over contact pairs of w(r) / the per-complex
  constant, in the solve and the ranking (overrides `JACOBIK_Q6_AGG`); polar-H pairs mix their lin / bent tables by a
  sigmoid of the D-H...A angle (differentiable); pairs without a table (rare keys, raw M...X pairs) keep their wall.
  No Q6P tables in the DB -> warning, wall used. The beam pre-screen still uses the walls.
  `JACOBIK_Q6_PMF_WELLS` (default "hbond"): keep wells only for polar-H...acceptor pairs, every other pair max(w, 0);
  "all" = the full w(r). Reason: summed over ~10^3 pairs the generic ~-1 kT wells reward compaction (BIDHEB, below).
- **Small check (not a benchmark).** Tables from 7 993 tmQM X1 complexes (benchmark codes excluded; 86 tables), v6
  DB otherwise, CPU, seed 11, 8 conformers, 10 development cases, MACE-POLAR-1-S #1 dE (kJ/mol) wall / pmf-all /
  pmf-hbond: XECSON 62/99/133, MELLUN 141/106/125, TINBIE 107/63/64, GIZGUR 265/203/251, MUXHAP 231/300/287,
  DEVFUG 80/163/86, HAFZOG 195/138/242, PIDXOT 89/94/105, KUGWIV 135/146/138, BIDHEB 99/2458/591; median 121/142/136.
  BIDHEB pmf-all: acyl O folded onto Pd (Pd...O 1.22 A; the pair is a metal 1-3 pair, not in Q6) while Q6 collected
  -70 kT of contact wells; pmf-hbond: a 1-4 C-H...O at 1.53 A (not in Q6). Ranking only (re-ranking each wall pool
  with pmf-all): better pick 1 case, worse 3, same 5. No sign of a gain on this set; one seed, 10 cases, so
  undecided: benchmark arm only.
- Tests: `test_q6pmf_tables_shape`, `test_q6pmf_scorer_switch` (tests/test_audit_2026_10_13.py, 13 pass on v6 DB).

## 2026-10-13 (audit: torsions at linear atoms, sp typing, inert padding, through-metal Q6 pairs, q6alt, Q6_AGG switch)
Accuracy-side audit before the refit (owner request). CPU results change for most complexes (padding, Q6 pairs); the
GPU fast path is unaffected structurally (it reads the kinematics tables; `test_complex_fk_matches_reference` passes).
- **FIX torsions at linear (sp) atoms (`stats/key_builder.flank_side`, `q5_flanks`, `ik/fk.py`).** A torsion flank at an
  sp atom is collinear with the bond (178-180 deg), so the dihedral is rounding noise. Runtime: XECSON atoms moved
  2.05 A for a 1e-6 A shift of the reference coordinates (0.0000 A now). Extraction: on tmQM X1 (first 3000 complexes)
  190 of 35 018 Q5 rows (117 complexes, 3.9 %) were such noise, filed under keys such as (C_sp3, C_sp3), (C_sp3, C_ar),
  (N_sp3, C_ar). Now the flank is taken from the first off-axis atom along the linear chain (Ph-C#C-Ph: the far
  ring's ortho C), for the Q5 rows (extraction and runtime, shared) and the kinematics joints. A bond with no off-axis
  atom on one side (M-C#C-R, M-N#C-R, R-C#C-H seen from R) has no torsion: no Q5 row, and the joint is left out (its
  rotation is the ligand's own base rotation, or moves only collinear atoms). Benchmark fixtures: 24 joints in 12
  complexes touch an sp atom; 22 are left out (XECSON's two diphenylacetylene joints get far-ring flanks). Rotor
  symmetry (Q5 folding) follows the same chain.
- **FIX sp atom typing (`key_builder._build_type_map`).** C and N with a triple bond (BO >= 2.75) or two double bonds
  are "C_sp" / "N_sp"; before, they fell through to "_sp3", so alkyne / nitrile / isocyanide rotors were pooled with
  sp3 rotors in the Q5 keys. Back-off: C_sp -> C (`stats._Q5_TYPE_TO_ELEM`, `ladders.q5_elem`). Old DBs have no C_sp
  keys; those rotors back off to the element level.
- **FIX padded mixture components inert everywhere (`ik/scorer.py`).** Q5: padding (weight 0, kappa 0) was made inert
  only for SCORE_AGG="sum" or folded DBs, and the tables are built once, so with an unfolded DB (v6) the ranking score
  floored every torsion at ~-18 nats. Per-candidate Q1 tables: padding (mean 0, variance 1) floored a donor at ~-19
  nats ~6 scorer sd from its components. Both now -1e4 log-weight (as Q2 since 2026-10-01).
- **CHANGE Q6 scores ligand pairs joined only through the metal (`topology/graph.q6_topological_exclusions`,
  `JACOBIK_Q6_THROUGH_METAL`, default 1; 0 = old rule).** X-D-M-D' pairs (3 bonds through the metal: a donor's
  substituent and another donor, a Cp H and a cis donor) were excluded as "topologically constrained", but no bond or
  angle holds them. tmQM X1 (16 000 complexes): their lower tail matches ordinary contacts of the same element pair
  (0.1 % quantile C-H 2.53 vs 2.44 A, C-C 2.92 vs 3.00 A), so they share the element-pair walls. In the 10-03 CUDA run
  #1 structures put such pairs well inside that range: KUGWIV H...C 1.50 A, YAVFEG C...H 2.09, COPYIP O...C 2.32,
  NOBBEN C...C 2.62 A. Donor-donor pairs and the metal's own pairs within 2 bonds stay excluded. Shared by extraction
  and runtime, so it must be decided before the refit. Fixtures: +5 809 scored pairs over 154 complexes.
- **ADD refit stage `q6alt` (`refit/run_refit.py`, `fitter.fit_all(q6_model=...)`):** a second DB that differs only
  in the Q6 wall, the pre-2026-10 5th-percentile wall on the new keys (`final/constraints_refit_q6p5.json`). Reason:
  on tmQM X1 the onset wall is much softer against clashes (C...C mu 3.63 -> 3.00 A, H...H 2.53 -> 2.04 A, C-H 3.02 ->
  2.44 A at sigma ~0.3 A); a contact 1.1 A inside the v6 wall costs C-C 6.2 -> 0.9 nats, H-H 13.4 -> 2.4 nats.
- **ADD `JACOBIK_Q6_AGG` (experiment switch, default "softmin" = unchanged).** The solve's steric term is
  -LSE(-tau p)/tau + log(M)/tau over M contact pairs (thousands): a contact adds almost nothing until its own penalty
  exceeds ~log(M)/tau = 3.5-4.5 nats (KUGWIV #1: -0.03 in this form, -15.8 nats summed; MUXHAP -2.0 vs -79). "sum"
  scores the summed walls / the per-complex constant (the ranking form) while Q1-Q5 keep their means.
  JACOBIK_SCORE_AGG=sum (every term summed) was tried first: it removed clashes but lost on uncrowded cases (13 cases,
  seed 11, CPU, v6 DB: XECSON 64 -> 160, PIDXOT 80 -> 139, HATSAZ 95 -> 121 kJ/mol). Steric-only sum on 11 cases
  (seed 11, CPU, v6 DB, with the fixes above): #1 median 103 -> 87, mean 188 -> 142 kJ/mol; BIDHEB 538 -> 165, DEVFUG
  257 -> 101, MUXHAP 330 -> 202, MELLUN 83 -> 43; HAFZOG 295 -> 347, XECSON 65 -> 81, PIDXOT 63 -> 77. These are
  development cases at one seed: a benchmark question, default unchanged.
- **FIX notebook 02:** no hard-coded configuration names (paired plots, overlay cell), per-set figures, targets table.
- Found, not changed (see the progress page journal 2026-10-13): the solve's Q6 soft-min (log(M)/tau offset) is
  blind to contacts below ~4 nats each; the v6 C-H wall is twice as wide (sigma 0.59 A) as the legacy fitter gives on
  current data (0.27 A); IJEVIC / AXUVEV have no tmQM SMILES (benchmark input, not the solver).
- Fixes vs the 10-02 code, same CPU solver, seed 11, v6 DB, MACE-POLAR-1-S, 11 cases: #1 median 103 -> 103, mean
  195 -> 188 kJ/mol (XECSON 90 -> 65, MELLUN 100 -> 83, BIDHEB 659 -> 538, PIDXOT 74 -> 63; MUXHAP 228 -> 330, a case
  whose seeds span 152-344 on the PC). Neutral to positive at this noise level; the PC benchmark decides.
- Tests: `tests/test_audit_2026_10_13.py` (11). Suite on the Linux CPU copy: 254 passed, 2 skipped (CUDA),
  3 xfailed. Expected on the PC: 256 passed, 3 xfailed, plus the known time-budget failure if it persists.

## 2026-10-03 (output dedup: automorphism scans without per-matrix SVDs; dedup back on the CPU by default)
All devices. Same criterion and selections; CPU results bit-identical (see validation).
- **Why.** First benchmark run with the 14:45 package (N48, 3 seeds per pass, PC): JEFJUZ 214 s per pass, TACZUT,
  XEPKAF, KAQFUD 61-65 s, the GPU busy throughout. That was the dedup, now on the GPU: these complexes have 3 200 to
  20 000 (the cap) automorphisms of the heavy-atom graph, and each visited row cost a (kept rows, automorphisms,
  atoms, 3) float64 gather plus one 3x3 SVD per kept row and automorphism. Moving that to the GPU did not make it
  cheap (about 70 s per seed for JEFJUZ).
- **`ik/dedup.py`, `StructureDeduper`:** (1) `inv_maps`: sum_n f(A[n], B[map[n]]) = sum_k f(A[inv[k]], B[k]), so the
  correlation matrices of one candidate against all kept rows under all automorphisms are ONE matrix product
  (`_full`), and the best automorphism for a fixed rotation is an argmax of one matrix product (`_upper`).
  (2) `_max_overlap`: the optimal-rotation overlap s1 + s2 + sign(det) s3 as the largest eigenvalue of Horn's 4x4
  matrix by Newton's method on its quartic from an upper bound (Theobald's QCP), elementwise for all
  (row, automorphism) pairs; no SVD in `_full`.
- **`DEDUP_DEVICE` default is "cpu" again** (`JACOBIK_DEDUP_DEVICE=solver` for the GPU): the CPU dedup is now fast and
  is the same code path for CPU and CUDA solves.
- **Validation (Linux CPU copy).** `_max_overlap` vs SVD on random, near-identical and planar sets: RMSD within
  4e-13 A. Old vs new `select` on the rows of real solves (all conformers returned, 60 steps), 12 complexes: identical
  selections; seconds old -> new: JEFJUZ 39.5 -> 2.4, KAQFUD 19.6 -> 1.0, XEPKAF 15.3 -> 1.1, TACZUT 14.9 -> 1.0,
  JIHMAR 4.2 -> 0.28, CUWMEP 1.28 -> 0.30, PIDXOT 0.72 -> 0.40, XECSON 0.30 -> 0.07; unchanged within 0.05 s for
  PIJYAJ, OVODUZ, AHIGOQ, MELLUN. New test `test_dedup_overlap_matches_svd_and_brute_force`.
  **Not yet run on the PC.**

## 2026-10-03 (benchmark on CUDA: all seeds of a complex in one solver pass)
Tooling only (`tools/`, `tests/regression/`, notebook 01); nothing in `src` changes.
- **Why.** On the GPU fast path a solve is a fixed 0.9-1.5 s of launch overhead plus a per-row part, so stacking the
  rows of several seeds into one pass shares the fixed part: 1.6-3.1x per seed at 8 seeds, PC, 5 cases
  (`gpuwork/11_multiseed_bench.py`).
- **`tools/jdev/multiseed.py` (new): `solve_seeds(builder, seeds, max_rows=None, **solve_kw)`.** A seed only changes the
  starting rows (Q1 target lengths, bend-joint starts, macrocycle folds, random part of the base-pose fit), all inside
  `ComplexBuilder._beam_search_all_candidates`. solve() runs once up to there; that function runs once per seed with
  the seed's generators while the seed-independent objects it builds (kinematics, geometry extractor, scorer, beam
  result, decomposition) are built once and handed back by replacing their constructors for the duration; the rows of
  all seeds go through `_run_joint_ik` together; dedup and assembly run per seed. Needs the no-culling recorded-step
  solver (with culling the seeds would be culled against each other): CUDA with `JACOBIK_GPU_REPLAY=1`.
  This reaches into `ComplexBuilder` internals; a proper `solve(seeds=...)` API is for the main chat.
- **`tests/regression/run_panel.py`**: with `--plan`, result files that differ only in the seed are run as a group
  (`--seeds-in-one-pass auto|on|off`; auto = the plan asks for it and the solver is inline on CUDA): per case one pass
  (`_worker_seeds`, which calls the unchanged `_worker` once per seed with `ComplexBuilder.solve` replaced), one result
  file per seed as before. `solve_s` = pass time / seeds; `solve_pass_s`, `seeds_in_pass` are recorded. If the joint
  pass is not possible (other solver, GPU out of memory) the seeds are solved one by one and
  `seeds_in_pass_skipped` says why. At most `JDEV_SEEDS_MAX_ROWS` (6000) rows per pass. `_run_one` is split into
  `_RunFile` (record / finish) with the same output; the CPU / loky path is unchanged.
- **`tools/jdev/bench.py`**: `run_plan(..., seeds_in_one_pass=None)` (None = on for a CUDA solver) writes the flag into
  the plan. **`notebooks/01_benchmark.ipynb`**: `SEEDS_IN_ONE_PASS` passed to `bench.run_all`.
- **Validation (Linux CPU copy, rewritten loop forced on the CPU).** Each seed's scores and coordinates bit-identical
  to its own solve: XECSON, MELLUN (200 steps), PIDXOT, CUWMEP, AHIGOQ (40 steps), seeds 11-13. Runner: a plan of
  2 N48 cases + a legacy case x 3 seeds gives the same score, ensemble scores, convergence count and M-D error per
  seed grouped and ungrouped, and the same xyz files; the fallback path was exercised. New test
  `test_seeds_in_one_pass_match_separate_solves`. **Not yet run on the PC through the benchmark** (the multi-seed
  pass itself was run there by `gpuwork/11`, `12`, `14`).

## 2026-10-03 (CUDA solves: output dedup on the GPU, conformers from one batched kinematics pass)
CUDA only; CPU results bit-identical before and after (XECSON, MELLUN, AHIGOQ, PIDXOT x seeds 11-13, one thread).
- **Why.** `notebooks/01_benchmark` (DEVICE = 'cuda') stalled on N48 complex 32, JEFJUZ, with the CPU busy and the
  GPU idle. Reproduced on the Linux CPU copy with the benchmark's settings (n_conformers unset -> 64 returned): the
  output dedup took 53 of 65 s (3200 automorphisms of the heavy-atom graph: two Cp rings, two phenyls; 99 upper-bound
  and 79 full scans, each an SVD per kept conformer per automorphism in float64). The fast path keeps every row
  (no culling), so the dedup also sees more rows than on the CPU path.
- **`ik/dedup.py`: `select_distinct(mol, X_all, score, k, device)`** = `StructureDeduper.select`, with the RMSD work
  on the solver's GPU for a CUDA solve (`JACOBIK_DEDUP_DEVICE=cpu` keeps it on the CPU; a GPU `RuntimeError`, e.g.
  out of memory, falls back to the CPU with a warning). Same algorithm and float64; `StructureDeduper` is unchanged.
- **`engine._assemble_conformers`**: for a CUDA solve the dedup goes through `select_distinct` and the returned
  conformers' coordinates are taken from ONE batched kinematics pass (the pass the dedup already needs) instead of
  one pass per conformer and ligand (each some hundred eagerly launched GPU operations; 64-192 conformers in a
  benchmark). `engine.BATCHED_ASSEMBLY` forces the batched read on the CPU for the test. The CPU path is unchanged.
- **Validation.** `tests/test_gpu_fast_path.py`: batched read vs per-conformer pass on CPU (same rows and
  scores, coordinates within 1e-4 A; MELLUN n_conformers=8, AHIGOQ all conformers); `select_distinct` on CPU equals
  the deduper; CUDA test that the GPU dedup keeps the rows the CPU dedup keeps (skipped without a GPU).
  The GPU dedup turned out slow in the first benchmark run (about 70 s per seed for JEFJUZ); superseded by the
  entry above (default back to the CPU).

## 2026-10-03 (one-pass kinematics: 3x3 products elementwise)
- **`ik/fk_compose.py`: `SMALL_MATMUL = "elementwise"`** (default; "bmm" = torch matmul as before). The 3x3 products
  of the composed maps are a broadcast multiply + 3-term sum (helpers `_vecmat` / `_matmat`). Why: with several seeds
  in one pass the GPU time is arithmetic, and torch matmul on millions of 3x3 matrices (cuBLAS batched gemm) and its
  backward were 16-66 % of the GPU kernel time (`gpuwork/13_row_cost.py`). Measured on the PC
  (`gpuwork/14_opts_bench.py`, solver seconds at 8 seeds per pass, bmm -> elementwise): PIDXOT 14.44 -> 8.52, CUWMEP
  10.68 -> 7.76, XECSON 4.96 -> 3.15, MELLUN 3.03 -> 1.99, AHIGOQ 3.19 -> 3.07. Mean best score over the seeds:
  PIDXOT identical to 4 decimals, CUWMEP within 0.003; XECSON, MELLUN, AHIGOQ within their GPU run-to-run spread.
  With "bmm" the results are bit-identical to before the edit (MELLUN, AHIGOQ, PIDXOT, rewritten loop on CPU);
  `tests/test_gpu_fast_path.py` passes with either. CUDA only (the CPU solver does not use this class). The
  bend plan's own products (`angle_bends.BendPlan.apply`) are not touched.

## 2026-10-03 (GPU fast path: recorded step + one-pass kinematics)
Speed only; the CPU path is untouched (CPU results bit-identical before and after on 4 cases x 3 seeds).
- **Why.** Profiled on the CUDA PC (RTX 2060 SUPER, Windows): 95-98 % of a solve is the 200 gradient steps on both
  devices; on CUDA a step costs (number of tensor operations) x about 35 us of launch overhead and almost no
  arithmetic (4 400-6 100 operations per step, median operation touches about 1 000 numbers; time does not depend
  on the number of rows). 70 % of the operations are the per-joint forward kinematics and its backward pass.
- **`ik/solver_replay.py` (new): `ReplaySolver`**, used by `engine._run_joint_ik` when the device is CUDA
  (`solver_class`; `JACOBIK_GPU_REPLAY=0` turns it off). Same set-up and final scoring as `JointIKSolver` (copied
  verbatim by `tools/jdev/build_replay_solver.py`); the step loop is rewritten so that a step is a fixed sequence of
  GPU operations on fixed memory (state updated in place, step counter and Adam bias-correction table on the device,
  periodic checks under a mask) and is recorded once with `torch.cuda.CUDAGraph` and replayed: step 0 eager, step 1
  recorded, 198 replays at about 4 us per kernel. The 4x4 `eigh` of the polyhedron fit runs between two recorded
  halves. If recording raises, the solve continues eagerly (traceback in `solver_replay.LAST`).
- **No row culling on this path** (owner decision): culled rows already keep competing with their best-so-far
  angles, so keep-all only gives rows more steps; on the GPU rows are nearly free. Measured on CPU, culling off vs on
  (4 cases x 3 seeds): #1 score better in 4, equal in 8, worse in 0. The CPU path keeps its culling, so CPU and CUDA
  now differ by design as well as by rounding. Culling by mask is not implemented.
- **`ik/fk_compose.py` (new): `ComplexFK`**, one kinematics pass for all ligands (`JACOBIK_GPU_FAST_FK=0` turns it
  off): base transforms, a leading block of each ligand's joints (incl. branch-bend joints) and all angle bends
  (one merged `BendPlan`, evaluated by `BendPlan.apply` itself) in a fixed number of operations; reference dihedrals
  and axes computed once per reference geometry. `ForwardKinematics` stays the reference and the only place joints
  are defined; joints that fail the build-time rule (ring joints with overlapping moved sets) run on its path.
  157 fixture complexes: 95 % of joints composed, coordinates within 3e-4 A (median 1e-5 A) of the reference loop.
- **`geometry.q2_dmd_angles`**: the i<j pairs are taken with a precomputed flat index instead of the boolean mask
  (same values and order; the mask ran a data-dependent `nonzero` every call).
- **Validated.** Rewritten loop run eagerly on CPU vs `JointIKSolver` with culling off: scores, coordinates and
  per-step traces bit-identical (MELLUN, PIDXOT, AHIGOQ). One-pass FK vs reference FK in the solver over seeds
  (CPU): AHIGOQ 12 seeds #1 better 8 / worse 4, paired difference -0.02 +- 0.07; MELLUN 8 seeds 3 / 5, +0.004 +- 0.13.
  On the PC (CUDA, seed 11, warm): XECSON 42.7 -> 5.6 s, PIDXOT 33.8 -> 6.4 s, CUWMEP 33.4 -> 3.9 s, MELLUN
  35.8 -> 4.6 s, AHIGOQ 20.8 -> 3.3 s including about 0.3-2 s of fixture reading in both numbers; with the timer
  around the solve only: 3.5, 3.8, 3.7, 2.3, 2.2 s. Energies (MACE) old vs new path: `gpuwork/10_delta_e.py`,
  not yet run. CUDA solves of one seed are not repeatable run to run (before and after).
- **Benchmark tooling.** Nothing to switch on: `run_panel.py` / `bench` / notebook 01 with a CUDA solver device use
  the fast path through the engine. `bench._spec`: CUDA result files are now named `__solver-cuda-replay`
  (`__solver-cuda` only with `JACOBIK_GPU_REPLAY=0`), so files written by the eager CUDA solver are not reused.
- **Found, not changed (accuracy work):** 17 torsion joints in 11 of 157 fixture complexes have an undefined
  dihedral (three collinear atoms, e.g. both phenyl torsions of XECSON's diphenylacetylene); there the reference FK
  moves atoms by up to 2.8 A for a 1e-6 A change of its input. XECSON's `trigonal` geometry makes every assignment
  fail the reachability rule (sites 120 deg apart, P-C-C-P limited to 115 deg).
- Tests: `tests/test_gpu_fast_path.py` (10 on CPU + 1 that needs CUDA). Suite: 238 passed, 3 xfailed, 1 skipped
  without a GPU.

## 2026-10-02 (CUDA path; one continuous benchmark process)
Built on the laptop's 10-01 changes (persistent loky case workers, batched energy-only float32 MACE).
- **Device selection.** `run_panel.py --device / --solver-device / --mace-device` (also `bench.run_*` and notebook 01).
  `benchmark.energy.resolve_device`: "auto" = CUDA when torch can use it; an explicit CUDA request on a CPU-only torch
  build fails at once with the torch / CUDA build in the message. `MACEPolarEvaluator(device="auto")` by default.
- **One process for the whole benchmark** (`run_panel.py --plan`, `bench.run_plan / run_all`): every result file of a
  benchmark (sets x DBs x configurations x seeds) is produced by one panel process; worker pool, parsed DBs and the
  MACE model are created once. Before, each (set, DB, config, seed) started a new process that rebuilt the pool and
  reloaded MACE in every worker. Run settings travel in the plan (not in JDEV_* variables read at import).
- **MACE on CUDA lives in the driver.** With a CUDA MACE (or inline cases) the solves return their structures and
  the driver's single evaluator scores them: the model is loaded once, never moved, and loky workers never touch the
  GPU. Batch 32 on CUDA (4 on CPU), automatic halving after a CUDA out-of-memory, one device->host transfer per batch.
- **CUDA solver = inline executor**: cases run one after another in the driver (one CUDA context shared with MACE,
  no worker processes, no solver threads); the solver's cached GPU blocks are released before MACE batches a case.
- **Solver, for CUDA** (static audit of engine / ik: no device mismatch found; CPU results bit-identical before and
  after on 4 cases x 2 DBs): seeded random starts are drawn on the CPU generator and moved (same starts on every
  device); `JointIKSolver` accepts a string device; Q3 / Q4 are no longer evaluated when S_orient replaces them (their
  values were discarded; the haptic Q3 costs a batched SVD per step); haptic face indices and the Q2 "has t
  components" flag are built once instead of per step; the beam's dedup and `fk.q5_alignment` read the device once
  instead of per row.
- **`python -m tools.jdev.cuda_check`**: on-GPU self-test (torch build, MACE GPU vs CPU energy and time, the same
  seeded solve on CPU and GPU) with a verdict on the faster layout. **Not run here: this sandbox has no GPU**, so the
  solver's CUDA path is audited, not executed.
- Checked on CPU: the three layouts (workers' MACE; driver MACE with loky; inline) give identical dE on 5 runs; the
  plan keeps workers warm across runs (setup 0.00 s, same PIDs). Tests: 228 passed, 3 xfailed (4 new in `tests/test_devices.py`).

## 2026-10-01 (refit package: the 2026-10 statistics; donor bends gated off)
Everything below is for the one big refit (`refit/run_refit.py` / `notebooks/03_full_refit.ipynb`). Old DBs keep
working with this code (legacy Q2 lookup, Q5 folding only for folded DBs, Hp -> H Q6 fallback, Q5 no_ortho level).
- **Benchmark orchestration:** the panel now uses bounded persistent loky processes instead of launching one Python
  interpreter per complex. Each worker retains imports, one parsed DB, one MACE calculator, and an incremental tmQM
  fixture index; every case still creates fresh solver state and seeds. Hard timeouts kill/rebuild the pool, and
  `--case-executor subprocess` keeps strict fresh-process isolation. Concurrent cases share a CPU budget rather than
  each claiming 8 solver threads. Matrix runs stream completed complexes by default, including progress count,
  metrics, and setup / MACE / total timing, without polling/heartbeat noise or whole-configuration buffering.
  MACE scoring now batches independent structures and requests energy only by default, avoiding unused force/stress
  derivatives and duplicate evaluation of the top conformer. `--mace-mode full` retains the historical full-property
  ASE path for force/Hessian work. MACE inference defaults to float32 (`--mace-dtype float64` remains available); both
  mode and dtype are printed, persisted, and included in the notebook result cache identity. Batched CPU inference
  temporarily uses the case's allotted core count (`--mace-threads` overrides it) instead of remaining single-threaded.
- **`angle_bends.DONOR_BENDS` (`JACOBIK_DONOR_BENDS`) default 0 (owner, 09-30).** N48 neutral (#1 median 114 -> 115,
  top-1 46 -> 36 %), RING10 mean 289 -> 228 (NOBBEN -538, YOSMOJ -66). Kept as a switch; retest on the new DB.
- **A1 evidence-weighted mixtures (`stats/mixture.py`).** Each complex has weight 1 per key (1/m per row); BIC on the
  effective count; every component needs >= 10 effective complexes; the `n // 30` component cap is gone (it forced
  44 % of the Q2 tables to K = 1, e.g. DEWZOW NO-NO bimodal 90/175 fitted as one peak at 120). Applies to Q1-Q4.
- **A2 partial pooling for Q1 and Q2 (`stats/pooling.py`).** Keys with >= 50 complexes fitted on their own data, every
  other key MAP-adapted (Reynolds 2000) from the next present key along its runtime candidate chain; entries carry
  `pooled` and the lookup takes the most specific one at any n. r (and the Q1 variant) chosen on held-out complexes in
  the refit (`refit_lib.pooled_holdout`). Prototype held-out (r = 4): keys with 0 training complexes 1.17 / -1.34 ->
  1.36 / -0.31 (mean / p5 log p per complex), 1-9 complexes 1.38 / -0.35 -> 1.73 / +0.52.
- **A3 Q2 Student-t mixtures ("tmix_cos", nu in {2, 4, 10}); scorer `_cos_mix_logp`.** A5: padded Q2 components inert.
- **A4 Q2 site-pair class in the key** `(geom, pair_class, dist_class, metal, sub_a, sub_b)`: the ideal angle of the two
  sites in the best-fit assignment (`coord_geom.best_fit_assignment`: exact for CN <= 6, Hungarian/Kabsch from 48 starts
  for CN 7-9); the solver uses each candidate's own assignment (per-candidate Q2 tables, like Q1 trans keys). The class
  is kept at every back-off level. Chelate pairs kept (owner). **Haptic faces are their own Q2 family** (the fam level
  used to merge eta-faces with kappa C donors: PABTAP / XIPLUD borrowed CO-CO angles).
- **A6 Q5 well model** (`fitter.fit_vmm_wells` = `fit_vmm_weighted` + `merge_vmm_to_wells` + minority tail dropped) and
  rotor-symmetry folding of the DATA at extraction (`key_builder.Q5_FOLD_DATA`); the scorer folds automatically when
  the DB sidecar says `q5_model: wells_folded` (`JACOBIK_Q5_FOLD=auto`). The legacy unweighted `fit_vmm` is removed.
- **B3 Q5 aryl ortho context**: rotors between C_ar and a non-ring partner get `free_o0/1/2` (heavy ortho substituents,
  capped at 2), back-off level `no_ortho` (= the old L0). Shared helper for extraction and runtime (`q5_context`).
- **B1 `C_eta7` / `C_eta8` labels** (hierarchy under C_haptic_any): eta7-C7H7 / eta8-COT no longer land in the eta2 table.
- **Q6 contact-onset wall** (`fitter.fit_contact_wall`): mu = 0.1 % quantile of the key's non-bonded distances, sigma from
  the 1 % - 0.1 % spread (floor 0.05 A); **polar-H keys** ("Hp" = H on N/O/F facing N/O/F/S/Cl/Br/I) in extraction and
  runtime (`key_builder.q6_pair_key`), lookup falls back Hp -> H. Old wall: mu = 5th percentile, crystals lost median
  7.7 nats (p10 26, PEWBOL H-bonds 46). The legacy `fit_halfgauss` is kept. Keys with < 1000 rows (= 1 / 0.001) are
  not fitted: their 0.1 % quantile is the sample minimum and the width collapses to the floor (found here: TACZUT
  Ti...F 2.60 A cost 85 nats against a wall from 134 rows); they fall back to the pooled / covalent walls.
  Rescored on the 48 N48 crystals with walls from the 3-shard sample (in v6db_eval): crystal Q6 median -7.7 -> 0.0,
  worst -73 -> -0.4; #1 of the old pools -7.5 -> 0.0 (C-H contacts -18 summed vs crystals -0.8). Q6 thus stops
  separating non-clashing conformers (its old within-pool rho ~0.44 came partly from a wall inside real contacts).
- **A7** `orientation.COV_FLOOR` documented as added regularisation (not a floor); value unchanged (owner).
- **A8 refit pipeline** (`refit/run_refit.py`, new `notebooks/03_full_refit.ipynb`; old one in notebooks/archive):
  stages audit / clean / extract / select / fit / check / install; benchmark complexes (N48 screen 144 + RING10,
  `refit/benchmark_holdout_codes.json`) dropped from every quantity at merge; S_orient incl. the per-substituent
  haptic rows (was a separate script); QG / QP priors fitted; sidecar records the model versions. Fixed:
  `qo_holdout_eval` crashed on haptic rows; `stats.load_db` accepts a dict (+ `meta=`).
- **Benchmark tooling:** case sets `n48` and `ring10` (fixtures under tests/regression/fixtures), per-configuration
  env switches (`"_env"`), `JDEV_ENSEMBLE_DE=1` measures every returned conformer -> `bench.targets` (top-1, top-3,
  within-ensemble rho, #1 |dE| median / > 200, solve time). New `notebooks/01_benchmark.ipynb` (old DB vs new DB).
- Validation: tests 224 passed (incl. 18 new in `tests/test_refit_2026_10.py`), 3 xfailed; mini end-to-end refit on 198
  complexes (all stages); a solve on the mini DB (pair classes per candidate, t-mixture Q2, folding, ortho keys) and on
  the v6 DB (legacy path) both run.

## 2026-09-30 late (statistics-priced lean ON; eta2 / eta3 audit; Q5 aryl scope; YOSMOJ benzyl; measurement + one default)
- **`angle_bends.HAPTIC_FREE_LEAN_MAX` default 3 -> 6 (owner OK).** Every haptic face's substituent lean is now priced by
  the per-substituent S_orient rows, not the energy prior.
  - N48 Cp / arene complexes: bends match the crystals, GFN2 neutral (see below).
  - MOSGIK (the 09-27 reason for the old limit): #1 dE 106 / 122 / 117 -> 99 / 119 / 107.
  - Tests: 206 passed, 3 xfailed.
- **eta2 / eta3 audit (Q1 observations vs the current extractor; `haud/` fixture of 31 outlier complexes):**
  - **COD was extracted as ONE eta4 site** (C_eta4: 1,301 rows at 1.4-1.6 A, 97 % COD; 1,665 tmQM complexes contain COD).
    The runtime (and the current v2 haptic detector) treat it as two eta2 sites (C_haptic), whose table holds only 208
    rows, none of them COD alkenes.
    - So every COD site is scored against Mo / Zr / W rows (medians 1.69-1.76 A). That is the Ru mode at 1.87 A in NOBBEN.
    - The current extractor gives FARDEJ, IHUGOI, NOBBEN and GUYFAH two eta2 sites each: **the refit fixes it.**
  - The < 1.6 A rows (Zn 0.28, Ni 0.0, Ag 0.49, Cd 0.85 ...) are old-extractor artefacts: on the 31 complexes the current
    extractor gives no haptic site, a carbene, an allyl, or correct eta2 distances (2.05-2.49).
  - **Still wrong in the current code:** `donor_classifier` maps haptic order 2 AND every order other than 3-6 to
    "C_haptic". eta7-C7H7 (Mo / W / Zr, 1.66-1.83 A) and eta8-COT (Ti / Hf, 1.53-1.58 A) rows land in the eta2 table.
    Fix: C_eta7 / C_eta8 labels (+ hierarchy). Not made yet.
- **Q5 aryl-rotor scope** (`diag/q5_aryl_scope.py`):
  - 1,224 keys with an aryl central atom (36 % of Q5 rows).
  - Ortho split (0 / 2 heavy ortho substituents), median twist from the aryl plane:

    | key | 0 ortho | 2 ortho |
    |---|---|---|
    | N_sp3-C_ar | 43 | 80 (77 % > 70) |
    | N_sp2-C_ar | 47 | 77 |
    | C_sp2-C_ar | 40 | 75 |
    | O_sp3-C_ar | 1 (planar) | 63 |

  - Small for P_sp3-C_ar (47 / 54; 87 % ortho-H) and C_ar-C_sp3 (35-64).
  - Proposal: the ortho count (0 / 1 / 2) in aryl-flank Q5 keys, backing off to the unsplit key.
- **YOSMOJ benzyl carbons planar (angle sum 360 vs crystal 327-330).**
  - The cap works (capped embed + MMFF: 329). The GFN2 refinement of the BARE free benzyl anion then flattens it (360),
    as in class C2.
  - S_orient cannot fix it: a monodentate donor has no bend DOF (class C3), so its substituent angles are frozen
    internals that S_orient can only score.

## 2026-09-30 (ring joints revision 2 ON by default; large-face lean prior checked)
- **`topology.decompose.RING_JOINTS` default 1 (owner OK, 20:31).** Revision 2: opening-adjacent joints plus a bend-free
  opening. Ring leans and kept folds stay off. Viewer runs: ring10-rc2-*, n48-tfr2-*.
- **Haptic bend of Cp / arenes sits at exactly -0.036 in the solved structures: an artefact of the energy prior, not the data.**
  - Faces of more than 3 atoms keep the Q7 energy prior on the lean column: k = 1300 (the IN-plane sp2 constant, on an
    out-of-plane lean) with a 2 deg free zone.
  - The lean stops at the free-zone edge: sin 2.06 deg = 0.036.
  - The S_orient per-substituent Cp table says -0.133 +- 0.06 (crystals -0.075 to -0.18).
  - **Bend prior off (bend_scale 0), seed 11:** Cp bends follow the data (IGUWAI -0.133 vs crystal -0.137, XEPKAF
    -0.127 vs -0.122, KUYNEX eta2 -0.277 vs -0.244). But every other bend is then free too (#1 dE 1290-2643).
  - **Large faces priced like small ones (`JACOBIK_HAPTIC_FREE_LEAN_MAX=6`; lean statistics-priced, per-substituent
    S_orient rows), the 15 N48 complexes with eta5/eta6 faces x 3 seeds (tag CPL vs TFR):**
    - Bends now match the crystals: e.g. JIHMAR -0.134 vs -0.116, VUYWIX -0.129 vs -0.124, YIYXEJ -0.098 vs -0.089.
    - #1 dE median 121 -> 120; runs better / worse 18 / 12; per-complex mean 0 [-12, +11]; relaxed median 1.1 -> 0.1.
    - Energy-neutral on GFN2 SP, geometry right. Not switched on yet (owner decision).
  - Related: substituents on a chelate path get ordinary (energy-priced) bends, not the haptic lean. KUYNEX's eta2 bend
    is -0.047 vs crystal -0.244.

## 2026-09-30 (NOBBEN outlier; ring-substituent leans tried; RING_JOINTS still default OFF)
- **NOBBEN s11 (1987 kJ/mol) is not caused by the ring joints.**
  - The eta3-allyl face tips edge-on (normal vs Ru 54-89 deg; crystal 20). Its central C sits at 1.8-1.9 A and its H
    points into Ru (0.93 A).
  - Joints off has the same: s11 #1 1.33 A, and 10-12 of 24 pool conformers have that H within 2 A of Ru.
  - Nothing scores M-H through a donor atom (Q6 excludes pairs within 2 bonds, M-C-H). The S_orient face-tilt
    difference is weak (1.7 nats).
  - The Ru eta2 C_haptic Q1 table has its main mode at 1.87 A (crystal COD 2.05-2.13), and Q2 scores the crystal at -50
    nats.
  - Belongs to the haptic extraction audit and the Q2 refit items.
- **Ring-substituent leans (`angle_bends.RING_LEAN`, env JACOBIK_RING_LEAN, default 0).** The face atoms' ring
  substituents get the free-branch lean pair (S_orient-priced; free within the eta2 wall). FK passes its ring openings
  to `bend_specs`. Seed 11 vs revision 2:
  - FARDEJ 159 -> 206, XEYPAS 140 -> 306, RAMLAT 159 -> 269 (worse); IHUGOI 104 -> 94, GUYFAH 111 -> 99 (better); GATDOV 57 -> 57.
  - Cause: crystal COD CH2s all lean -17 to -28 deg. S_orient scores only the face-mean lean, so single ring leans
    wander (XEYPAS -44 / -19 / -42 / +8).
  - Revision 2 without leans already had -15 to -24. What is off there is the C=C-C angle: 128-131 vs crystal 121-125,
    from the MMFF-relaxed pool conformers that replace the embed's internals (embed 125).
- **Pool torsions on the embed's own internals (diagnostic monkeypatch only):**
  - FARDEJ M-C +0.07, IHUGOI 89, RAMLAT 206.
  - XEYPAS 32,455 (ring left open) and GATDOV 272 (lone-pair-selected coordinates lost).
  - Not adopted.

## 2026-09-30 (ring joints, revision 2: opening-adjacent joints + bend-free opening; RING_JOINTS still default OFF)
- **`ik/fk.py`, two changes:**
  - **`JACOBIK_RING_OPEN_ADJ` (default 1):** in a small joint ring, the bond into each opening atom is a joint too (it was
    frozen at its embed torsion).
  - **Opening choice:** when the ligand has bends, open the ring on a single bond that every bend either leaves alone or
    moves rigidly together with all the seam atoms (except points on its own axis). This keeps the opening off haptic face
    atoms, whose H leans the closure would fight. COD now opens on a CH2-CH2 bond. Fallback: the old rule.
- **`ik/angle_bends.py`:** `JACOBIK_RING_KEEP_FOLDS` (default 0) keeps folds on joint rings with a haptic face.
  - Tested on seed 11: M-C right (+0.08 / -0.03 / -0.06), but the k = 0 folds bend ring angles 14-39 deg and #1 gets worse
    (FARDEJ 286, IHUGOI 532, RAMLAT 580, GUYFAH 364).
- **Held-out ring set, 10 x 3 (tag RC2) vs off (RC0) / first version (RC1), #1 dE:**
  - median 276 / 233 / 188; > 200: 24 / 20 / 13.
  - vs off: runs better / worse 26 / 3, complexes 8 / 1, per-complex mean -139.
  - vs RC1: 18 / 4 runs, 6 / 1 complexes. The mean is +12, all from NOBBEN s11 (1987: an H 0.93 A from Ru, to be
    investigated).
  - RAMLAT 444 / 369 / 412 -> 159 / 161 / 205; IHUGOI -> 104 / 125 / 102; FARDEJ -> 159 / 178 / 171; XEYPAS -> 140 / 146 / 136.
- **N48 rings:** GATDOV 57 / 56 / 58 -> 57 / 71 / 72; GUYFAH 102 / 103 / 119 -> 111 / 105 / 94; QEQJAA identical.
- Tests: 206 passed, 3 xfailed with RING_JOINTS on or off.

## 2026-09-30 (why joint-mode COD cannot leave its seed fold; measurement + one experimental switch, default off)
- **Closure-preserving torsion freedom** (null space of the seam Jacobian over the macro joints):
  - COD 0 (4 joints, rank 4); triazinane 0 (3 joints); the 12-ring cyclen arm 4.
  - A 6-8 ring at fixed bond lengths and angles has no continuous torsion freedom, so in joint mode the solver can only
    choose among pool folds.
- **The bond into each opening atom is never a joint** (`range(len(arm) - 2)`, inherited from the macrocycle code). Its
  torsion stays at the embed value. Experimental switch `JACOBIK_RING_OPEN_ADJ` (`ik/fk.py`, default 0) adds it for small
  rings: COD 5 joints, freedom still 0.
- **The bound COD tub is not an exact closure solution at the free ligand's internals.** Started from the crystal's ring
  torsions, the closure stops at a 0.48 A seam residual (mid-mid 3.40). Free C=C is 1.34 A vs 1.39 bound, and the sp2 angles
  differ by about 2 deg.
  - 3,000 random torsion starts give many folds, none with mid-mid below 3.0 A.
- **Joint mode removed the only angle DOF.** `angle_bends.bend_specs` drops the CH2-CH2 hinge folds on joint rings (my
  09-30 filter), leaving COD only its vinyl-H leans.

## 2026-09-30 (owner review of the ring10 runs; ring joints back to OFF; measurement only)
- **COD (FARDEJ, IHUGOI, RAMLAT, ...):**
  - With joints, every conformer has COD M-C 0.2-0.4 A long, and the ring is a chair / twist-boat (alkene mid-mid 3.19 vs 2.79-2.84 A in the crystal).
  - The macro pool is 16 MMFF-relaxed free-COD conformers, all with mid-mid 3.45 or 3.21. The ligand's own embed is also mid-mid 3.45: `chelate_embed.donor_pair_bounds` covers kappa donors only.
  - The off-mode #1 reaches mid-mid 2.66 only by bending angles (87-129 deg).
- **PABTAP** (eta6 cycloheptatriene Cr(CO)3):
  - The crystal has one CO eclipsing the sp3 CH (0 deg). The lowest-dE conformers are near it (6-32 deg); #1 is staggered (58-79 deg).
  - Q2 decides it: #1 +6.1 vs the crystal-like #6 -3.9 nats.
  - The sp3 C fold is 0.38-0.50 A vs 0.94 A in the crystal.
- `diag/cod_check.py`, `diag/pool_probe.py` (pool = reference embed only; inconclusive: #1 dE 1436 / 34782, not yet understood).

## 2026-09-30 (LAPKAS N-aryl torsion; measurement only, solver unchanged)
- `diag/q5_lapkas.py`: per-conformer torsions, Q5 log-density, terms and GFN2 dE.
- **Found:** the Q5 key ('N_sp2','C_ar','C_sp2','C_ar','free') pools 2,6-disubstituted aryls with ortho-H aryls.
  - The disubstituted aryls are 55 % of the 7,380 rows, with a median twist of 78 deg.
  - Ortho-H, N-bound aryls have a median of 48 deg; only 5 % are within 20 deg of planar.
  - The table peaks at +-90 deg, so LAPKAS (crystal 20 deg) has no near-planar conformer.
- Candidate refit item: the ortho-substituent count in aryl-flank Q5 keys (refit spec §7, under study).
- Viewer: runs n48-tfr-*, ring10-rc0-*, ring10-rc1-*; journal entries for the thread fix, the ring joints and LAPKAS.

## 2026-09-30 (worker-thread race; ring torsion joints for small donor rings)
- **FIX `ik_solver.JointIKSolver.solve`: each thread chunk now scores with its own shallow copy of the solver and scorer.**
  - Bug: `_solve_impl` ends by rescoring with the fit-time floors (`set_gmm_floor("fit")`, then back). With 2 thread
    workers the scorer was shared, so the chunk that finished first swapped the floors under the other chunk's steps.
  - Effect: 2-worker solves were not reproducible. Re-running 3 N48 complexes gave different pools each time (up to
    8.5 A per-atom differences, different #1 in some). With 1 worker the runs were already identical.
  - Consequence: every earlier N48 number is one draw of a noisy process. The earlier claim "the other 36 are
    bit-identical" (fix A) rested on one complex (LEBNOX) and does not hold.
  - Validation:
    - Bit-identical pools across two processes on 5 complexes (IPEPNI, TEDTIG, PEWBOL, GATDOV, XIPLUD).
    - Two new tests; `test_worker_chunks_switch_floors_on_their_own_scorer` fails on the old code.
- **Solve times in the BASE / EZ runs look inflated:** 7-12 s now vs 18-30 s then for the same complexes. The old runs
  probably shared the 2 cores with GFN2 measurement jobs. The clean re-baseline (tag TF) runs the solves alone.
- **ADD ring torsion joints for small donor rings (`topology.decompose.RING_JOINTS`, default on; env `JACOBIK_RING_JOINTS=0` turns it off).**
  - Which rings: a ring of >= 6 atoms holding >= 2 donor atoms (kappa or haptic), with no aromatic bond, not fused (no
    ring edge shared with another basis cycle) and >= 3 single bonds. It gets the macrocycle treatment:
    - torsion joints on its single bonds; double bonds stay rigid;
    - the ring is opened on a single bond (the anchor is chosen so the closure bond is single) and closed exactly as
      for macrocycles;
    - per-row ring conformers from the ETKDG pool (lone-pair convergence selection when it has >= 3 sp3 N ring donors).
  - `angle_bends` keeps its bends for such ligands but drops hinge (fold) specs that touch the joint ring. The ring now
    puckers through torsions with its bond angles kept, where a rigid fold could only bend them.
  - `fk.closure_project` and the fused closure step now act on the macro columns only (bend columns follow them).
  - First check, seed 11-13, before the thread fix:
    - GATDOV #1 dE 1034 / 748 / 971 -> 57 / 56 / 58 kJ/mol (GFN2-relaxed #1 82 -> -10);
    - GUYFAH 201 / 109 / 184 -> 102 / 103 / 119;
    - QEQJAA (a 9-ring macrocycle already) unchanged.
    - Clean paired numbers: see the next entry.
  - **Clean paired N48 (tags TF / TFR, 3 seeds):** 138 of 144 runs bit-identical; only GATDOV and GUYFAH change.
    - GATDOV #1 1034 / 748 / 971 -> 57 / 56 / 58 kJ/mol; GUYFAH 201 / 109 / 184 -> 102 / 103 / 119.
    - N48 overall: mean 172 -> 153, > 200: 44 -> 40, rho median 0.67 -> 0.69. Solve time is unchanged; the earlier
      "faster" was core contention.
  - **Held-out check:** the first 12 harness-valid tmQM complexes in crc32 order with a qualifying ring, none used
    before (`rcand/`, scan on the laptop in `_claude_diag/RINGcand`).
    - TEBREX fails to embed with the switch on or off (pre-existing); QUBHIG is unaffected.
    - Paired over the 10 affected x 3 seeds: #1 SP median -47, mean -151 kJ/mol; runs better / worse (> 10) 22 / 3;
      per complex 8 better / 1 worse (YOSMOJ +24); per-complex mean -151 [-351, -33].
    - Basin (relaxed #1) neutral: median 0.0, mean -4.4.
    - Largest: RICSUR 1285 / 1131 / 1329 -> 242 / 226 / 252.
    - Clean solve time +0-4 s per complex (PUHPAJ 11 -> 14 s). 295 s and 65 s single runs were contention, re-timed.
  - **Default ON** from here. -> **Reverted to OFF the same evening (owner review):** in every COD complex all conformers bind the alkenes too far out (M-C mean +0.27-0.31 A). The joint-ring seeds are free-COD conformers (alkene mid-mid 3.45 / 3.21 A; the bound tub is about 2.8), and neither the embed nor the pool is binding-aware for haptic sites. See the next entry.
  - Tests: 4 new in `tests/ik/test_macrocycle.py` (detection on/off for triazinane and COD, eta6 benzene
    stays rigid, joints skip C=C and the ring opens and recloses on a single bond). 204 passed, 3 xfailed with the
    switch on or off.

## 2026-09-30 (new benchmark set and GFN2 yardstick; measurement only, solver unchanged)
- **ADD `bench/gfn2.py` (GFN2-xTB single point / relaxation via the xtb binary) and `bench/n48_{solve,measure,report,push}.py`.**
  - ΔE = GFN2 single point minus the GFN2 single point of the tmQM geometry, which is an exact GFN2 minimum (relaxing it
    changes 0.0 kJ/mol).
  - Checked against MACE on the BASE pools (788 conformers): Spearman 0.89, within-pool median 0.95.
  - MACE is kept for final confirmation only.
- **New set N48:** 48 tmQM complexes, none used before, in crc32(code) order, ≤ 120 atoms, harness-valid (17 of the first
  90 candidates were not). The fixture is in `n48/cand` (laptop copy `_claude_diag/N48cand`).
- **N48 baseline** (hand-off defaults, 3 seeds, 2 threads): #1 ΔE median 136 kJ/mol, 62 of 144 runs > 200; #1 within
  1 kcal/mol of the run's best 47 %; ρ median 0.63; solve median 21 s (76 of 144 > 20 s).
  - GFN2 relaxation of #1: 88 % of the summed ΔE is strain; median basin error 9.7 kJ/mol.
  - 13 of 48 complexes are in a worse basin on all three seeds.
  - Details: project doc `claude/n48-baseline-2026-09-30.md`.
- **Viewer:** N48 runs carry per-atom GFN2 energies from tblite (atom-resolved; they sum exactly to the xtb total) and
  per-atom |force|. There is a new 'per-atom force' colour mode (`bench/n48_push.py`, `resources/viewer/make_page.py`).

## 2026-09-30 (chelate-ring double-bond configuration)
- **ADD `chelate_embed.chelate_ring_stereo` + `JACOBIK_CHELATE_EZ` (default on).** A non-ring double bond on the shortest
  path between two kappa donors of one ligand, where that path plus the metal forms a ring of <= 7 atoms, gets the
  configuration the ring requires (its ring-path neighbours cis). It is set as RDKit bond stereo before ETKDG, and stereo
  already in the SMILES is kept.
  - Why: tmQM SMILES carry no C=N / C=C stereo, the donor-pair bounds do not constrain it, the embed is the same in every
    seed, and the solver cannot rotate a double bond.
  - Embed check on N48: 22 / 22 such bonds match the crystal (was 12 / 22).
  - Solve check, the 12 N48 complexes it touches x 3 seeds (GFN2): #1 dE median 295 -> 93, mean 339 -> 144, > 200 kJ/mol
    27 -> 9; basin (GFN2-relaxed #1) median 68 -> 0.1; paired -195 [-291, -117] kJ/mol, 10 better / 0 worse; solve
    median 22.6 -> 15.2 s. The other 36 complexes are bit-identical (checked). [Correction, later on 09-30: only LEBNOX was
    checked. 2-worker solves were not reproducible (thread race, fixed above); fix A is re-measured on the clean runs.]
  - Whole N48: median 136 -> 120, mean 221 -> 172, > 200: 62 -> 44 of 144; rho median 0.63 -> 0.67; solve median 21 -> 18 s.
  - Tests: 2 new (`tests/test_v2_features.py`); 199 passed.
- Tried and REMOVED: a covalent-angle prior on ring-fold axis atoms. GATDOV and GUYFAH got worse (GUYFAH #1 201 -> 1460).
  A rigid fold can only reach the needed ring shape by changing those angles; the fix needs an angle-preserving pucker
  DOF (owner to choose).

## 2026-09-30 (N48 strain diagnosis; measurement only, solver unchanged)
- `diag/n48_attrib.py`, `diag/embed_audit.py`, `diag/embed_audit2.py`, `diag/embed_variants.py` (offline).
- **Found:**
  - (A) the E/Z of double bonds on chelate rings is left to ETKDG: 10 of 22 wrong in N48, 9 complexes, seed-stable. A
    topology rule (a small ring holds no trans double bond; the metal counts as a ring atom) predicts the crystal 22 of
    22.
  - (B) `angle_bends` ring folds have k = 0: they break covalent angles in GATDOV (N-C-N 111 -> 78 deg) and GUYFAH (COD).
  - (C) GFN2 refinement of bare anions / boryls / carbenes undoes the metal-surrogate caps in some donors. A capped-GFN2
    variant is mixed (11 angles better, 14 worse by > 5 deg).
  - (D) the Q1 back-off pools subclasses: Fe eta2 -> Fe haptic bucket at 1.78 A; Mo O_diketonate -> a 42 % oxo Mo-O table.
- Details: project doc `claude/n48-strain-diagnosis-2026-09-30.md`. No code change yet.

## 2026-09-29/30 (score-energy audit; experimental switches removed)
- **Solver source is identical to the 2026-09-29 hand-off** (`diff -r` against `diag/src_backup_2026-09-29`
  clean; tests 181 passed, 15 skipped, 3 xfailed). Nothing from this audit is in the solver.
- Tried and REMOVED (no code left behind):
  - `JACOBIK_SO_DECONV` (subtract the S_orient `reg_covar = 0.05^2`, clamp at 0.02^2): panel 12 x 3 paired #1
    -5.8 [-23.3, 8.7] kJ/mol, i.e. within noise. **Owner decision 09-30: the 0.05^2 stays** unless it is shown to be
    useless and harmful beyond noise on a new complex set.
  - physical (GFN2-Hessian) torsion widths (#1 mean -10 [-29, +6]; the ligand Hessian cost up to ~2 min per large
    ligand);
  - S_orient chelate-ring marginalisation (one solve, no gain).
  Findings are kept in the project docs (2026-09-29/30). The refit items the owner kept (Q1 partial pooling, Q2
  Student-t, Q2 site-pair key, inert Q2 padding, Q5 well model) are in claude/refit-spec-additions-2026-09-30.md.
- **FIX `tools/jdev/start.py` (diagnostic tool only):** `_crystal_ligand_coords` / `_junction_ligand_coords` keyed
  crystal coordinates by SMILES, so identical ligands (3x CO, 2x Cp) all received ONE crystal copy. Now per instance, in
  ligand order. Checked: DUFLAR s11 junction_oracle 2147 / bodies_oracle 2024 kJ/mol even after the fix, so these two
  modes stay unreliable (splicing bodies from two geometries distorts the junctions); full_oracle is the usable one.

## 2026-09-28 (torsion fitter, output deduplication, GFN2 embed, ranking score)
- **ADD `fitter.fit_vmm_weighted` + `merge_vmm_to_wells`, `topology.graph.rotor_symmetry`/`wl_classes`, scorer
  `JACOBIK_Q5_FOLD` / `JACOBIK_SCORE_AGG`** (all off in the solve unless set): Q5 fits with per-complex evidence weights
  (1/m for m copies of a complex), rotor-symmetry folding of the data (CH3/tBu 3-fold, planar sym. aryl 2-fold), one
  component per torsion well and the off-well tail treated as the outlier share. For the next refit; not yet in a DB.
  On the case keys (3-shard data): Q5-alone within-pool rho -0.18 -> +0.12, picks -17 kJ/mol vs the old fitter on
  equal data. Padded VMM/GMM components are now inert in these modes (they used to floor terms at ~-17.7 nats).
- **ADD output deduplication (`ik/dedup.py`, `JACOBIK_OUT_DEDUP`, default on):** the returned conformers are distinct
  structures (symmetry-aware heavy-atom RMSD <= 0.5 A, min over the bonded graph's automorphisms incl. coordination
  bonds; mirror images kept apart), best-scored member of each. Exact (identical counts to RDKit GetBestRMS on 15 runs)
  with a sorted-radial lower bound and a refined-automorphism upper bound; <= 2.4 s for 3200 automorphisms on 2 CPU
  threads, usually 0.1-0.5 s. Top-1 unchanged by construction (36/36). Distinct useful structures (<= 10 kcal/mol of
  the best found) in the returned 16: 116 -> 161 over 12 cases x 3 seeds.
- **ADD `embed=` ("gfn2" default, "mmff", "etkdg"; `fast_embed=True` = "etkdg"; `JACOBIK_EMBED`, `JACOBIK_XTB`):**
  each ligand embed (ETKDG -> MMFF) is refined by GFN2-xTB (`--opt crude`), with every donor-donor distance held at the
  embed's value, once per ligand per process (no disk cache). tmQM references are GFN2 geometries; MMFF draws Cp- as a
  localised diene (C-C 1.45/1.34 A) and is a silent no-op on boron. Internal-geometry error vs the references over the
  panel's 31 ligands: bonds 0.026 -> 0.022 A, 1-3 distances 0.045 -> 0.041, ring pairs 0.075 -> 0.066. Cost median
  0.1 s per ligand (max ~3 s, an 80-atom macrocycle). Falls back to MMFF when xtb is missing or fails. Panel: best
  returned structure -5 kJ/mol (21 W / 13 L), picks unchanged within noise.
- **ADD ranking score (`Scorer.ranking_score`, engine re-rank after the solve; `JACOBIK_RANK_AGG` default "sum",
  `JACOBIK_Q1_TAIL_SIGMA` default 0.10):** the final ranking uses the total log-likelihood over all features instead of
  per-quantity means, and drops Q1 mixture components broader than 0.10 A (or with a mean < 1.2 A) as the outlier
  share (the Q5 well rule). The solve is unchanged. Panel (36 runs, 24 distinct returned): #1 within 1 kcal/mol of the
  run's best 36 % -> 50 %, #1 in the energy top-3 64 % -> 78 %, median gap #1 -> run best 16.4 -> 5.1 kJ/mol; picks
  -6.5 [-19.7, 6.1] kJ/mol; rho over all returned 0.56 -> 0.52 (not improved), concordance (pairs > 25 kJ/mol apart)
  0.73 -> 0.75.
- **FIX math.md S16.1** (pooled Q6 walls: lookup now tries `(pg, x)` first) and **S16.2** (beam partial Q6 now gets
  the contact pairs). Both correct; neutral on the panel.
- **Panel with all of the above (bench/pools/BASE, 36 runs, 24 distinct returned):** #1 dE median/mean/max 116/132/380
  kJ/mol (4 runs > 200), #1 within 1 kcal/mol of the run's best 47 %, in the energy top-3 75 %, rho median 0.62,
  concordance (> 25 kJ/mol) 0.80, 30 % of returned conformers within 10 kcal/mol of the run's best, solve median 11 s.
- `tests/test_guards.py`: the Co-EDTA score guard runs against embed="mmff" (its historical band); with gfn2 the
  best score is ~-3.65 with all six arms bound (open item in HANDOFF). Tests: 196 passed, 3 xfailed.

## 2026-09-27 (B2.7 score balance -- score-energy baseline)
- **Baseline** (12 cases x 3 seeds, v6db_eval, MACE on the top 16 of each pool by each score): the pools usually hold
  a much better conformer than the one the score picks (best-in-pool median 116 kJ/mol vs picked 147), and within a
  pool the total score barely tracks energy (Spearman 0.1). Per term: Q6 +0.46, Q1 +0.42, S_orient +0.37, Q2 +0.18,
  Q5 -0.30. Q5 varies 2-9x more than any other term within a pool.
- **Findings on the widths.** The scorer's GMM floors (Q1 sd 0.2 A, Q4 2 deg, Q2/Q3 0.05 cos) are 5-30x wider than the
  fitted distributions (almost every Q1 component is narrower than 0.2 A), removing ~80 % of Q1's discrimination. tmQM
  torsion wells are ~5 deg wide (kappa 130-500 for sp3-sp3 staggered wells) because the structures are minima.
- **ADD `Scorer.set_gmm_floor` + `JACOBIK_GMM_FLOOR` (scorer | fit) and ranking with true widths (`ik_solver`
  `JACOBIK_RANK_FLOOR`, default fit):** the solve optimises with the scorer floors, the final rows are ranked with the
  fit-time floors (true fitted widths). A/B/C/D, picked dE median / mean / worst, best-in-pool median:
  A today 147/152/393, 116; **B rank with true widths 138/147/360, 116** (adopted); C true widths during the solve
  158/186/1029, 112; D = C + Q5 per-well tempering (kappa x 0.1, `JACOBIK_Q5_TEMPER`, experiment only, default off)
  182/193/901, 133. Softening Q5 during the solve makes the conformers worse -- sharp torsions help generation; Q5's
  within-pool anticorrelation is the trade-off at the optimum, not an overweighted term. Rescoring-only variants
  (kappa caps, tempering, dropping H-flanked torsions, per-term normalisation) raise pool Spearman to 0.26-0.33 but do
  not pick better conformers than B.
- Tests 196 passed.

## 2026-09-27 (B2.5 / B2.6)
- **FIX extractor dropped the B2.2 raw haptic columns** (QO rows were written with a fixed column list without
  raw_face / raw_closed / raw_subs; only the standalone haptic extraction had them). The refit would have lost them
  and the per-substituent haptic fit could not run. Now written; checked 160/160 haptic rows on a 400-complex run.
- **ADD `stats/hypothesis_tables.py` + extractor rows (B2.5)**: observations_QG (one row per complex: CN, label,
  runner-up, margin, OS), observations_QP (one row per bound pi arc: n, context whole ring / part of an r-ring /
  chain, split along the arc, bond string for audit only), observations_QB (candidate donor atoms: descriptors +
  bound flag; insurance). Fits `fit_geometry_prior` (soft counts inside the CN's 10th-percentile margin band,
  ladder metal+OS+CN -> metal+CN -> period-group+CN -> CN, Jeffreys 0.5) and `fit_partition_prior` (ladder arc+metal
  -> arc+period-group -> arc -> (n, context) -> n), stored as QG:/QP: categorical entries; `Stats.geometry_prior`,
  `Stats.partition_prior` look them up. Partition keys are topology only: tmQM draws many bound alkenes with a
  single C-C (AHIGOQ's COD came out "1"), so bond orders would differ between DB and input. Sample (12k tmQM):
  Pt(II) CN4 99 % square planar, Pd(II) 97 %, Ni(0) CN3 96 % trigonal; whole 6-rings never split (492/492); open
  4-chains split 2+2 in 27 %.
- **ADD `stats/reference_ll.py` (B2.6)**: ref_ll / ref_sd per Q1-Q5 and QO entry = mean / sd of log p of the
  entry's own samples, evaluated as the scorer does (GMM variance floors). Deterministic (stratified quantiles;
  angle-grid quadrature for von Mises; fixed seed for QO). 12 s for the whole DB; loaded into FittedDist. Finding:
  Q1's reference is 0.59 +- 0.13 (ceiling ~0.69) because of the scorer's 0.2 A Q1 floor -- every bound donor scores
  about the same on Q1, so Q1 carries little ranking resolution near the optimum.
- Tests 196 passed.

## 2026-09-27 (B2.3 / B2.4; eval DB v6db_eval = v5db_eval with post-hoc hygiene, a stand-in for the refit)
- **CHANGE `fitter.fit_gmm` / `fit_gmm_cosangle` (B2.3): variance floor per quantity (`VAR_FLOOR`: Q1 0.01^2 A^2,
  Q4 1 deg^2, Q2/Q3 0.01^2 cos^2; sklearn reg_covar) and no component under `N_COMP_MIN` = 10 effective samples (a K
  whose fit has one is not selectable).** Applies at the refit. Check on a 3-shard tmQM sample (12k complexes, 979
  raw keys, held-out 1 in 5 complexes): floor spikes Q1 10->0, Q2 22->0, Q3 73->0, Q4 26->0; held-out mean log p
  Q1 2.22->2.20, Q2 0.29->0.40, Q3 -5.95->-3.14, Q4 -1.40->-1.59; worst held-out point much better on all four
  (Q1 -1.30->-0.41, Q3 -95.8->-57.8, Q4 -31.5->-7.0).
- **ADD Q1 one-sided wall (`scorer`, `JACOBIK_Q1_WALL`, default on).** Per site, beyond max_j(mu_j + 3 sd_j) (fitted
  sd, >= 0.05 A), log p -= 0.5 ((d - d_hi)/s)^2 with s = max(sd_j, scorer Q1 floor 0.2 A). A slope from the fitted sd
  alone (0.05 A for phosphines) stalled XECSON convergence (conv 5-10/16 -> 1-4/16, dE 224/202/162).
- **CHANGE Q6 exclusions (B2.4, `graph.q6_topological_exclusions`, shared by extractor and scorer): metal pairs are
  excluded up to 2 bonds only (`JACOBIK_Q6_METAL_EXCL`, default 2); M...Y three bonds away is torsion-dependent and
  is scored.** Ligand 1-4 pairs keep the 3-bond exclusion. PIDXOT: 10 more Ru pairs scored (none clash).
- **Validation** (12 cases, seeds 11/12/13, v6db_eval, all on vs hb13): median 140 -> 147, max 382 -> 393 (DUFLAR
  s11, seed-bimodal as before), everything < 300 except DUFLAR s11. XECSON 137/89/166 -> 119/124/136; PIDXOT
  124/110/106 -> 129/156/114 (all donors bound in every run, as without B2.3); BICPEI s11 124 -> 247 and AHIGOQ
  s11/s12 211/172 -> 247/212 are the largest moves up. Neutral within seed noise on this set, as expected: the
  cases whose failure B2.3 targeted (PIDXOT's detached carbene) were already fixed by the B1 carbene typing.
  Tests 193 passed (`test_q6_exclusion_full_graph` updated to the new metal rule).

## 2026-09-27 (haptic bends; cloud sandbox, eval DB v5db_eval = pre-refit + new haptic entries)
- **ADD ring folds (`angle_bends.bend_specs`, hinge through two non-adjacent non-donor ring atoms of a non-aromatic
  ring >= 6 with donors on both sides; `_compatible` drops cyclic combinations).** Lets COD go from the staggered
  embed to the tub. No spring on the fold. The branches of the axis atoms (their H) are re-posed by the change of
  the axis atom's bisector frame (`BendPlan` frame-follow, no extra DOF); without it the CH2 H stayed put
  (AHIGOQ 1742-3034).
- **ADD per-substituent haptic bend (`orientation.per_sub_rows`, `scorer` `JACOBIK_HAPTIC_PER_SUB`, default on).**
  A face is scored as the mean over its substituents of log p(tilt, own bend, slip), with separate H / heavy entries
  (k + 100 / + 200) fitted from the stored raw face geometry (no re-extraction; eta2 H bend sd 0.25 vs heavy 0.57).
  Removes the face-mean loophole (one H swings, the mean stays typical). Falls back to the face mean without entries.
- **CHANGE haptic bend axes: lean referenced to the substituent's own plane (eta2: bond x substituent; larger faces:
  face plane) instead of the metal.** With a metal reference the lean/sideways split depended on how the embed
  oriented the face: the edge-on alkene of AHIGOQ got an in-plane "lean" (C=C-H 58-176 deg over +-60) with k = 0.
- **FIX near-linear haptic substituents (alkynes, nitriles in the embed): the local plane (bond x substituent) is
  undefined at 180 deg, so the lean/sideways axes came from numerical noise every step (XECSON twisting, alkyne
  C-C-C 123 deg on seed 12).** The lean direction now blends smoothly (below 20 deg from linear,
  `JACOBIK_LOCAL_PLANE_DEG`) to the face normal, sign-aligned, with a safe norm. XECSON 210/240/112 -> 137/89/166, alkyne angles
  151-166 deg (crystal 155); AHIGOQ unchanged (211/172/148); DUFLAR 234/295/283 -> 382/191/281 and MELLUN
  148/156/158 -> 149/183/206 (the sign alignment flips the lean direction of well-defined faces, so the optimiser
  lands in different basins; same kinematics).
- **ADD lean wall (`JACOBIK_HAPTIC_LEAN_WALL`, default on): the eta2/eta3 lean stays free within the data range
  (per-substituent H bend 2.5/97.5 %: 57 / 40 deg) and gets the ordinary bend stiffness beyond**, so a substituent
  cannot flip through its face atom.
- **Validation** (haptic set, seeds 11/12/13, v5db_eval): AHIGOQ 497/1108/648 -> 211/172/148 (alkene separation
  2.73 A vs crystal 2.81), DUFLAR 429/659/844 -> 234/295/283, MELLUN 299/266/347 -> 148/156/158, XECSON
  121/111/128 -> 210/240/112 (diffuse, max per-atom 40 kJ/mol; the alkyne substituent over-bends on seed 12: 123 vs
  155 deg), others within noise. Tests 190 passed.

## 2026-09-25 (v2; cloud sandbox, not yet on the laptop)
- **CHANGE `chelate_embed.cap_anions`: heteroatom-stabilised carbenes embedded in ylide/iminium form.** A kappa
  carbene [C] (2 radicals, neutral) next to a neutral, non-aromatic, singly-bonded N/O/S is embedded as X+=C with
  one H cap (was: =CH2 cap, all C-X single). C-N 1.41 -> 1.28-1.29 A (CAAC), C-O 1.30 A (Fischer); aromatic NHC
  (1.34 A) and alkylidene [CH] unchanged. `JACOBIK_CARBENE_YLIDE=0` restores the old embed. Affects 2 of 46 fixture
  complexes. PIDXOT (CAAC), seeds 11/12/13: 319/177/165 -> 364/115/303; converged rows 80-85 -> 103-105 of 112, and
  the rows with the CAAC bound are lower (best 115-121 vs 165-177). The seed 11/13 losses are rows with the CAAC
  carbon 2.9-3.1 A from Ru ranked first: CAAC is typed C_alkyl, whose wide Q1 does not reject it (typing item on the
  pre-refit list; the classifier sees CAAC/benzylidene carbons as CH2 in its explicit-H mol). AHIGOQ (saturated NHC):
  Ir-C 2.02-2.04 -> 2.07-2.08 (ref 1.99); its dE is dominated by the COD given as 4 kappa donors (pre-refit list).
  Tests added (fail with the switch off).
- **FIX `engine._order_sites_like_donor_groups`: coord sites in the solver's donor order.** The classifier lists haptic
  sites first, while targets, ideal directions, assignments and Q1 tables follow the ligand/donor-group order and
  the GeometryExtractor reads donor positions in coord-site order. With a haptic ligand not listed first, every
  per-donor quantity was paired with another donor. Found through MUDSEL (Cp*Fe(dppe)(C#CR), Cp* listed last): dppe
  chelates perfectly with the Cp* first, fails with it last. Seed 11: MUDSEL 998 -> 103 (legacy branch joints),
  FUPREQ 144 -> 58; complexes whose haptic ligand is first are unchanged. Test added.
- **OPTION `JACOBIK_BRANCH_PRIOR=1`**: with angle bends, replace the legacy donor branch-bend joints by prior-penalised
  branch bends. Off by default: after the site-order fix the legacy joints did better on the 7 affected complexes
  (MUDSEL 103 vs 158, XECSON 157 vs 202, QAXMEL 138 vs 177, MELLUN 951 vs 1091).
- **CHANGE `chelate_embed.cap_anions`: valence caps only on kappa donor atoms** (a charge or radical elsewhere is not a
  metal bond). Seed 11: GIZGUR 242 -> 167 (its free carboxylate O- is no longer turned into COOH), QOSGIP 499 -> 674 (its
  input donor index is wrong, see roadmap), others unchanged.
- **DIAG `ik/fk.py`: `JACOBIK_BRANCH_BENDS=0` switches off the legacy donor branch-bend joints** (default unchanged: on).
  Off: identical on 13 of 18 test complexes, worse on MUDSEL (998 -> 1891), XECSON (157 -> 225), MELLUN, QAXMEL; GIZGUR 167 -> 158.
- **FIX `chelate_embed.cap_anions`: no caps on haptic donor atoms or on aromatic anions whose capping breaks
  aromaticity** (Cp-/Cp*- written [cH-]/[c-]). The H cap made that ring carbon sp3 and tilted its H or methyl out of
  the ring plane (present since the 09-24 chelate embed). Aryl/indolide anions are still capped. Held-out haptic set,
  seed 11: BUHVAD 312 -> 47, MOSGIK 347 -> 88, QAXMEL 289 -> 141, FUPREQ 234 -> 144; others and kappa controls unchanged.
- **NEW `stats/orientation.py` (`haptic_site_specs`, `haptic_features`, `face_order`, `dim_of`), `ik/scorer.py`: haptic
  sites in S_orient** (k = 10 + face size; g = [tilt, bend], Newell normal). Why: S_orient skipped haptic sites while
  replacing Q3/Q4, so haptic faces were unscored. Fit on 8522 haptic rows (LnQM + tmQM X1–X3 s000–s002), 168 keys.
  Validated on 8 held-out haptic complexes (fit without them), |ΔE| seed 11, unscored / old Q3-Q4 / new:
  BICPEI 2960/766/322, BUHVAD 4139/281/312, DUFLAR 603/684/554, FUPREQ 235/234/234, MOSGIK 5561/2114/347,
  MUDSEL 4505/2184/950, QAXMEL 443/452/289, SAYZAV 351/340/354. Torch features = numpy features (test).
- **FIX `chelate_embed.py` (`cap_anions`): valence-completing caps.** Any donor-side atom written with missing valence
  (anion and/or radicals: [CH3-], carbene [C], alkylidene [CH], alkylidyne [C-3]) is capped for the embed with the
  metal bond's order (H / =CH2 / #CH); two bonded kappa donors (eta2 given as two kappa sites) share a CH2 cap
  (metallacyclopropene surrogate). PIDXOT 694/713/767 → 319/177/165, XECSON 540/338/324 → 157/240/206, GOZXEY
  432/432/445 → 314/338/337; controls unchanged.
- **FIX `ik/fk.py`: macrocycle closure pairs.** The opening was closed by its bond length and the two ring 1-3
  distances, leaving each end free to spin about its ring bond; that bent seam H into the ring (TINBIE C-C-H 17 deg).
  Now each opening atom keeps its distance to every other neighbour (H included) of the other one. TINBIE
  2158/785/2300 → 234/259/264 (v2 647); KUGWIV unchanged.
- **FIX `ik/site_enumeration.py` (`dedup_exact`, `proper_site_symmetry_group`, `topological_class_keys`), `engine.py`
  (`solve(embed_aware_dedup=True)`, `_identical_ligand_instances`, `_class_budget_rows`): the symmetry dedup kept
  assignments the embed cannot reach.** It merged assignments related by swapping topologically equivalent donors
  inside one ligand and by reflections. For a fixed 3D embed those are different structures: two identical arms on a
  tetrahedral centre have a fixed order that torsions cannot change. VUCVUN (two pyrazoles on each B) kept only the
  variant needing an inverted boron: never converged (0/16), donors hanging at 2.5–3.1 Å, bends "closed" it by
  flattening B, a stiff bend prior jammed a donor to 0.98 Å from Sc, and the result depended on the embed seed
  (255–1217). Now only proper rotations and whole-identical-ligand swaps merge (canonical key, O(n) per assignment for
  any number of identical ligands), and each graph-level class shares one candidate's row budget. Validated (VUCVUN,
  solve seeds 11–13 + embed seeds 1/3/5): no bends 283–302 kJ/mol (was 709–1217), bends + energy prior 175–194 (was
  3463); converged 10–16/16 (was 0/16); solve time 0.97–1.02× on VUCVUN, GUJCUJ, KAQHOA, YARHIM; aqua 8–9 H2O still 1
  candidate. `embed_aware_dedup=False` reproduces the old results exactly.
- **PERF `ik/angle_bends.py` (`BendPlan`), `ik/fk.py`: angle bends vectorised.** One batched kinematic-chain pass
  (bends ordered so each pivot is unmoved when its bend acts; per-chain transforms by D batched matmuls; one gather
  + index_copy) instead of 24 sequential full-tensor clones. Exactly rigid (bond lengths < 2e-6 Å), identity at β = 0,
  gradcheck OK; same DOFs, axes now taken from the pre-bend positions (agrees with the old sequential map to first
  order). Bend apply fwd+bwd 7.4× faster; solve time with bends 1.10–1.25× of no bends (was ~1.9×).
- **CLEANUP:** removed `BEND_LR_SCALE` (stayed 1.0), the sequential bend apply and `to_tensors`; `JointIKSolver.trace_hook`
  (None by default) documented as the per-step diagnostics callback. Tests: +5 (proper groups, exact dedup,
  VUCVUN-type class budget, BendPlan rigidity/gradcheck, single bend = rotation about pivot); suite 146 pass + 3 xfail.

## 2026-09-24 (v2; built and validated in the cloud sandbox, not yet on the laptop)
- **NEW `stats/orientation.py` + scorer: joint donor orientation S_orient (quantity `QO`)** replaces Q3 + Q4 when
  the DB has QO fits (`solve(orientation_model="auto")`, also `"sorient"` / `"q3q4"`). Extractor writes
  `observations_QO_<split>.parquet`; `load_db` reads `QO:` entries (older code ignores them); `StatsLookup.orientation_dist`;
  refit section 6b (`refit_lib.qo_*`). Why: Q3/Q4 as two 1-D statistics could not describe water (aqua median
  |ΔE| 153 with the anion-context DB) and let donors point away. Validated: features/keys/fits bit-identical to the
  prototype; panel aqua median 14.3 kJ/mol; tmQM panel median 275 → 258 alone.
- **NEW `chelate_embed.py`: chelate-aware free-ligand embed** (`solve(chelate_embed=True)`, default). Donor-pair
  distance bounds (≥ 2.4 Å; ≤ r_i + r_j; ≤ 100° bite for 4–6-membered chelate rings), best of 8 ETKDG candidates when the
  first violates them (early exit otherwise; identical result), MMFF with the bounds as restraints; temporary H caps on
  formally anionic lone-pair donors (not on [B-]/[Al-]...). Why: trans C=C between donors (DEFCPO, NAHNAN) and
  MMFF-straightened [C-]=O (YARHIM) made chelation impossible for every assignment. Validated: panel with S_orient
  tmQM median 99 kJ/mol (from 258), cases > 300 kJ/mol 5 → 1 (VUCVUN 507), no regressions; panel numbers identical to the
  prototype at the same seeds.
- **FIX `ik/scorer.py`, `ik/ik_solver.py`, `engine.py`: Q1 trans-partner key from the assignment.** The key was built
  once from the initial shell, whose ligand placement is arbitrary (DEFCPO: all 6 sites keyed "no trans partner").
  Now one Q1 table per candidate assignment, gathered per row (`score(row_groups=)`, passed through the call, never
  stored on the scorer, because solver worker threads share it). Validated: panel median unchanged (99.4), DEFCPO 67 → 50.
- **FIX `ik/fk.py` (`q5_alignment`), `engine.py`, `ik/ik_solver.py`: beam-search seeds and cull niches used another bond's
  Q5 statistics.** Joint k of a ligand read Q5 row k, but Q5 rows follow the pivot chains and FK joints a root-body BFS
  (49 of 52 joints misaligned on 6 panel ligands), and the two measure the dihedral with different flank atoms. Now each
  joint uses its own bond's row, shifted into the joint's dihedral convention. Validation: see the v2 panel (seeds 11–13).
- **NEW `ik/angle_bends.py`: optional bond-angle bends on chelate backbones** (`solve(angle_bends=True, bend_free_deg=2,
  bend_sigma_deg=5, bend_weight=1)`, off by default) with score term Q7 (flat-bottom quadratic on angle change). Why/validated:
  VUCVUN 507 → 192–255, but typical chelates get worse (panel median 99 → 111–137), so off by default.
- **tooling:** `run_panel.py` gained `--out`, `JDEV_SEED`, `JDEV_SOLVE`, `JDEV_TMQM_DIR/SPLIT`, `JDEV_SAVE_XYZ`, records
  src hash and solve() arguments; `tools/jdev/bench.py` (configurations × seeds × case sets, tidy tables, paired
  differences vs seed noise) and `tools/jdev/viz.py` (figures, 3-D overlays); `jdev case/audit/diagnose --solve JSON`
  replaces `--experiment`; experiments archived in `_archive_code/2026-09-24_jdev_experiments_integrated/`;
  `tests/test_v2_features.py` (15 tests); fixture `tests/regression/fixtures/tmqm_sample40`.
- **docs:** `math.md` (the mathematics of the whole algorithm, SI level, incl. open issues S16), `notebooks/`
  (01 benchmark, 02 visualization, 03 full refit incl. S_orient), GLOSSARY entries.
- **open (documented in math.md S16, not changed):** beam partial-Q6 never active (wrong attribute name); post-fit pooled
  Q6 keys unreachable (key order); Q1–Q5 quantity weights only add constants.

## 2026-09-23
- **tests/tooling (no src change):** added `tests/conftest.py` (always tests src),
  `tests/test_guards.py`, the ported `tests/ik/*_next.py`, the 24-case panel
  `tests/regression/run_panel.py` + `baseline.json`, `tools/jdev`, `DEV_RULES.md`, `GLOSSARY.md`.
  Why: tests/ik only ever ran against `src`, so a known regression went unnoticed.
- **REVERTED `ik/site_enumeration.py`** to the 2026-09-17 version (cheap exact sorted-site
  pre-reduction). The 16:20 hop-aware dedup (unvalidated, from a previous Claude session) made CN9
  aqua hang and changed nothing for VUCVUN (96 raw -> 1 unique assignment either way). Archived in
  `_archive_code/2026-09-23_hop_aware_dedup/`. Validated: guards green, panel no regressions.
- **kept `engine.py`** `embed_seed` parameter + `ComplexBuilder.solve_multi_embed()` (16:20, previous
  Claude session). Default behaviour unchanged (seed 42); panel identical to baseline.
  `solve_multi_embed` is NOT an accepted fix for anything (seed-gambling); it is available for diagnostics.
- `benchmark/visualization.py` + `benchmark/vendor/3Dmol-min.js`: 3Dmol.js vendored inline
  (CDN load failed in file-delivered HTML). Tooling only.
- `ik/ik_solver.py`: Q3 mode-commitment ignores zero-weight padding components in the shared-mode
  argmax (padding slots could win for a far-off query). Real bug fix; EDTA-style tying unaffected.

## 2026-09-23 (data, not code)
- Deployed DB `data/refit/final/constraints_refit.json` is the `neutral_sigma_pool` DB (the
  `anionic_context` DB was reverted for an aqua energy regression). The code default in `ladders.py`
  is `anionic_context`, but the DB sidecar wins.
