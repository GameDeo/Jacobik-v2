"""refit_q6_only.py -- re-fit ONLY the Q6 walls and the Q6 PMF tables of a finished refit DB from fresh observations.

    python refit/refit_q6_only.py [--keep final_pre_q6fix]

For a change that touches only the Q6 contact set (2026-10-15: hydride M--H bonds were Q6 "contacts",
mapping.raw_metal_bond_exclusion_pairs(q6=True)). After `run_refit.py extract --force`, this runs the same steps as
stage fit for Q6 only: aggregate + expand Q6 into final/, fitter.fit_all(quantities=["Q6"]) (incl. the pooled metal
keys), the Q6P tables from obs/q6hist_<dataset>.npz, and replaces every Q6: and Q6P: entry of
final/constraints_refit.json (Q1-Q5, QO, QG, QP unchanged: their observations do not depend on the Q6 contact set).
Previous DB files are copied to --keep first. Then: delete final/constraints_refit_q6p5.json and run
`run_refit.py select q6alt check`.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--refit-dir", default=str(HERE.parent / "data" / "refit"))
    ap.add_argument("--keep", default="final_pre_q6fix")
    ap.add_argument("--workers", type=int, default=11)
    a = ap.parse_args(argv)
    sys.path.insert(0, str(HERE.parent / "src"))
    sys.path.insert(0, str(HERE))
    import refit_lib as R
    from jacobik.stats import q6pmf
    from jacobik.stats.aggregator import aggregate
    from jacobik.stats.expander import expand_quantity
    from jacobik.stats.fitter import fit_all

    refit = Path(a.refit_dir)
    obs, final = refit / "observations", refit / "final"
    db = final / "constraints_refit.json"
    summ = json.loads((final / "fit_summary.json").read_text())
    ds = summ["datasets"]
    keep = refit / a.keep
    keep.mkdir(exist_ok=True)
    for f in final.glob("*.json"):
        shutil.copy(f, keep / f.name)
    print(f"previous DB files copied to {keep}")
    t = time.time()
    for d in ds:
        shutil.copy(obs / f"observations_Q6_{d}.parquet", final / f"observations_Q6_{d}.parquet")
    print("aggregate:", aggregate(final, ds, ["Q6"]))
    print("expand:", expand_quantity(final, final / "exp", quantities=["Q6"]))
    tmp = final / "q6_only.json"
    s6 = fit_all(final / "exp", tmp, quantities=["Q6"], n_workers=a.workers, pooled={}, progress=False)
    q6 = json.loads(tmp.read_text())
    tmp.unlink()
    pmf = q6pmf.fit_tables(q6pmf.load_hist([obs / f"q6hist_{d}.npz" for d in ds]))
    raw = {k: v for k, v in json.loads(db.read_text()).items() if not k.startswith(("Q6:", "Q6P:"))}
    raw.update(q6)
    raw.update(pmf)
    db.write_text(json.dumps(raw))
    (final / "q6pmf_summary.json").write_text(json.dumps(
        {k: {f: v[f] for f in ("n", "n_key", "r0", "core_b", "core_kappa")} for k, v in pmf.items()}, indent=1))
    summ["Q1-Q6"]["Q6"] = s6["Q6"]
    summ["q6_note"] = f"Q6 / Q6P re-fitted by refit_q6_only.py (previous: {keep.name})"
    (final / "fit_summary.json").write_text(json.dumps(summ, indent=1, default=float))
    print(f"Q6: {len(q6)} entries, Q6P: {len(pmf)} tables  ({time.time() - t:.0f}s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
