"""q6_m13_hist.py -- metal 1-3 contact histograms and their core-only Q6P tables (2026-10-16 d, plan U4).

    python refit/q6_m13_hist.py hist --workers 6     # per shard: data/refit/observations/m13/q6hist_m13_<shard>.npz
    python refit/q6_m13_hist.py fit                  # -> data/refit/final/constraints_refit_q6p5_m13.json

The training shards of the 2026-10 refit (data/refit/reports/contacts/shards.json: cleaned tmQM X1-X3 + LnQM), the
same benchmark exclusion and LnQM sibling weights as the refit's Q6 histograms. Only the metal 1-3 pairs
(q6pmf.metal_13_pairs) are recorded; the fit adds their core-only tables (q6pmf.M13) to a COPY of the production DB.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(HERE))
OBS = REPO / "data" / "refit" / "observations" / "m13"
SHARDS = REPO / "data" / "refit" / "reports" / "contacts" / "shards.json"
DB_IN = REPO / "data" / "refit" / "final" / "constraints_refit_q6p5.json"
DB_OUT = REPO / "data" / "refit" / "final" / "constraints_refit_q6p5_m13.json"


def _task(args):
    data_dir, shard, excl, wts = args
    import logging
    import warnings
    warnings.filterwarnings("ignore")
    logging.disable(logging.CRITICAL)
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    from jacobik.stats import q6pmf
    from jacobik.stats.parser import TMQMParser

    t = time.time()
    acc = q6pmf.HistAccumulator(records=q6pmf.m13_records)
    n = err = 0
    excl = set(excl)
    for mol in TMQMParser(data_dir).stream_split(shard):
        n += 1
        if mol.csd_code in excl:
            continue
        try:
            acc.add(mol, wts.get(mol.csd_code, 1.0))
        except Exception:
            err += 1
    acc.save(OBS / f"q6hist_m13_{shard}.npz")
    return dict(shard=shard, n=n, errors=err, s=round(time.time() - t))


def cmd_hist(a):
    import refit_lib as R
    OBS.mkdir(parents=True, exist_ok=True)
    shards = [s for s in json.loads(SHARDS.read_text()) if not (OBS / f"q6hist_m13_{s['shard']}.npz").exists()]
    excl = R.benchmark_codes()
    wts = {d: R.sibling_weights(d) for d in sorted({s["dir"] for s in shards})}
    tasks = [(s["dir"], s["shard"], excl, wts[s["dir"]]) for s in shards]
    for i, st in enumerate(R._loky_unordered(_task, tasks, a.workers), 1):
        print(f"m13 {i}/{len(tasks)} {st}", flush=True)


def cmd_fit(a):
    import numpy as np
    from jacobik.stats import q6pmf
    hist = q6pmf.load_hist(sorted(OBS.glob("q6hist_m13_*.npz")))
    tabs = q6pmf.fit_tables(hist)
    tabs = {k: v for k, v in tabs.items() if any(f"'{c}'" in k for c in q6pmf.M13_CLASSES)}
    walls = q6pmf.fit_m13_walls(hist)
    print(f"{len(walls)} m13 walls (5th-percentile form, as the q6p5 walls)")
    for k, e in sorted(walls.items(), key=lambda kv: -kv[1]["n"])[:12]:
        print(f"  {k:36s} n {e['n']:8d}  mu {e['mu']:.2f} A  sigma {e['sigma']:.3f}")
    tabs.update(walls)
    db = json.loads(DB_IN.read_text())
    db.update(tabs)
    DB_OUT.write_text(json.dumps(db))
    meta = DB_IN.with_name(DB_IN.stem + ".meta.json")
    m = json.loads(meta.read_text()) if meta.exists() else {}
    # this DB only ADDS entries (Q6P m13 tables, read only under q6_m13 / the PMF): tools reading pools of DB_IN accept it
    m.update(extends=str(DB_IN), extends_adds="Q6P metal 1-3 entries (refit/q6_m13_hist.py)")
    DB_OUT.with_name(DB_OUT.stem + ".meta.json").write_text(json.dumps(m, indent=1))
    n = {k: int(v.sum()) for k, v in hist.items()}
    print(f"{len(hist)} m13 keys in the histograms, {len(tabs)} with a table (>= {q6pmf.N_MIN} pairs)")
    for k, e in sorted(((k, e) for k, e in tabs.items() if 'r0' in e), key=lambda kv: -kv[1]["n"])[:25]:
        print(f"  {k:32s} n {e['n']:8d}  r0 {e['r0']:.2f} A  core b {e['core_b']:.2f} kappa {e['core_kappa']:.2f}")
    print(f"-> {DB_OUT}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("stage", choices=["hist", "fit"])
    p.add_argument("--workers", type=int, default=6)
    a = p.parse_args()
    {"hist": cmd_hist, "fit": cmd_fit}[a.stage](a)


if __name__ == "__main__":
    main()
