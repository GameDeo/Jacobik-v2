"""bvs_fit.py -- plan 3 S2 (2026-10-17 c): the bond-valence coupling term's tables, from the Q1 observations.

Brown's bond-valence sum V = sum over a complex's sigma metal-donor bonds of exp((R0 - R) / B), B = 0.37 A, is ~ the
metal's oxidation state. Q1 scores every bond independently, so the spread of V it implies (each bond's length drawn
from its own key) is wider than real complexes show where bonds are coupled (tools/jdev/budget/bvs_check.py, 10-17:
robust sd 0.138 real vs 0.212 independent; lanthanides 4-5x, early metals ~2x, late metals ~1x). The term adds only
what Q1 misses, as a reference ratio (Hamelryck 2010):

  log p_obs(x) - log p_indep(x),  both Gaussian in x  ->  -c / 2 (x - mu_obs)^2 + const,
  c = max(0, 1 / s_obs^2 - 1 / s_indep^2)

with x = V / OS on the oxidation-state levels, x = V / median V on the metal-only level (user input without an OS).
Where real complexes are not narrower than independent bonds (c = 0) the term vanishes by construction. One term per
complex (not per bond); it constrains only the sum, so bonds may differ freely within a complex (EDTA axial vs
equatorial). Scope v1: complexes whose coordination sites are all sigma (haptic sites: check 3, open).

Ladders (most specific with >= N_MIN complexes):
  R0  (metal, donor element) -> (period-group, donor element) -> (donor element); least squares on V / OS - 1;
  V   (metal, OS) -> (period-group, OS) -> (metal).
Spreads are robust (16-84 % half-width); the independent spread is the mean over N_SHUFFLE shuffles of every bond's
length within its Q1 key (metal, OS, donor subclass).

    python refit/bvs_fit.py [--db data/refit/final/constraints_refit_q6p5.json] [--out <db>_bvs.json]
Writes a DERIVED DB (the input DB's entries + "QVR:" R0 and "QV:" level entries) and data/refit/bvs/fit_report.txt.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO))
from tools.jdev.budget.bvs_check import B, OS_UNKNOWN, fit_r0, load, robust_sd, shuffled_lengths  # noqa: E402

N_MIN_BONDS = 30     # R0 entry
N_MIN = 200          # V level entry (complexes)
N_SHUFFLE = 3


def pg_of(metal: str) -> str:
    from jacobik.stats.ladders import metal_period_group

    return str(metal_period_group(metal))


def fit_r0_ladder(d):
    """{('el', metal, el) | ('pg', pg, el) | ('*', el): R0}: each level fitted on the complexes whose bonds all have an
    entry at that level or above (pairs with fewer than N_MIN_BONDS bonds pooled one level down)."""
    out = {}
    for lvl, col in (("el", "pair"), ("pg", "pgpair"), ("*", "el")):
        cnt = d[col].value_counts()
        ok = set(cnt[cnt >= N_MIN_BONDS].index)
        bad = set(d.loc[~d[col].isin(ok), "csd_code"])
        sub = d[~d.csd_code.isin(bad)].copy()
        sub["pair"] = sub[col]
        r0 = fit_r0(sub, sorted(sub[col].unique()))
        for k, v in r0.items():
            parts = k.split("|") if lvl != "*" else [k]
            out[(lvl, *parts)] = float(v)
    return out


def r0_of(r0, metal, pg, el):
    for k in (("el", metal, el), ("pg", pg, el), ("*", el)):
        if k in r0:
            return r0[k]
    return None


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=str(REPO / "data/refit/final/constraints_refit_q6p5.json"))
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    out_db = Path(a.out or a.db.replace(".json", "_bvs.json"))
    assert out_db.resolve() != Path(a.db).resolve(), "never overwrite the input DB"
    rng = np.random.default_rng(0)
    d, hapt = load()
    d = d[~hapt & (d.os != OS_UNKNOWN) & (d.os > 0)].copy()
    d["pg"] = d.metal.map(pg_of)
    d["pair"] = d.metal + "|" + d.el
    d["pgpair"] = d.pg + "|" + d.el
    r0 = fit_r0_ladder(d)
    R0 = np.array([r0_of(r0, m, p, e) for m, p, e in zip(d.metal, d.pg, d.el)], dtype=float)
    keep = ~d.csd_code.isin(set(d.loc[np.isnan(R0), "csd_code"]))
    d, R0 = d[keep].copy(), R0[keep.to_numpy()]
    d["s"] = np.exp((R0 - d.value.to_numpy()) / B)
    sh = [np.exp((R0 - shuffled_lengths(d, rng)) / B) for _ in range(N_SHUFFLE)]
    g = d.groupby("csd_code", sort=False)
    cx = pd.DataFrame(dict(metal=g.metal.first(), os=g.os.first(), pg=g.pg.first(), V=g.s.sum()))
    cx_sh = [pd.Series(s, index=d.index).groupby(d.csd_code.to_numpy(), sort=False).sum().reindex(cx.index) for s in sh]
    lines = [f"S2 fit: {len(cx)} sigma-only complexes with a known OS, {len(d)} bonds; R0 entries {len(r0)}"]
    entries = {}
    for lvl, cols in (("mo", ["metal", "os"]), ("po", ["pg", "os"]), ("m", ["metal"])):
        for key, grp in cx.groupby(cols):
            key = key if isinstance(key, tuple) else (key,)
            if len(grp) < N_MIN:
                continue
            ref = grp.os.astype(float) if lvl in ("mo", "po") else pd.Series(np.median(grp.V), index=grp.index)
            x = grp.V / ref
            s_o = robust_sd(x.to_numpy())
            s_i = float(np.mean([robust_sd((c[grp.index] / ref).to_numpy()) for c in cx_sh]))
            c = max(0.0, 1.0 / s_o ** 2 - 1.0 / s_i ** 2)
            e = dict(n=int(len(grp)), mu=round(float(np.median(x)), 4), s_obs=round(s_o, 4), s_indep=round(s_i, 4),
                     c=round(c, 3), v_ref=None if lvl != "m" else round(float(ref.iloc[0]), 4))
            entries[f"QV:{(lvl, *[k if isinstance(k, str) else int(k) for k in key])!r}"] = e
    for k, v in r0.items():
        entries[f"QVR:{k!r}"] = dict(n=1, R0=round(v, 4))
    db = json.loads(Path(a.db).read_text())
    db.update(entries)
    out_db.write_text(json.dumps(db))
    # it only adds entries (read under the profile field bvs): budget tools accept pools of the input DB with it
    src_meta = Path(a.db).with_name(Path(a.db).stem + ".meta.json")
    meta = json.loads(src_meta.read_text()) if src_meta.exists() else {}
    meta.update(extends=str(Path(a.db).resolve()), extends_adds="QV / QVR bond-valence entries (refit/bvs_fit.py)")
    out_db.with_name(out_db.stem + ".meta.json").write_text(json.dumps(meta, indent=1))
    qv = {k: v for k, v in entries.items() if k.startswith("QV:")}
    lines.append(f"V levels: {len(qv)} (mo {sum('mo' in k for k in qv)}, po {sum(chr(39) + 'po' in k for k in qv)}, "
                 f"m {sum(chr(39) + 'm' + chr(39) in k for k in qv)}); c = 0 (no coupling) for "
                 f"{sum(v['c'] == 0 for v in qv.values())}")
    lines.append("largest metal-OS levels: n, mu, s_obs, s_indep, ratio, c, penalty at x - mu = 0.1 (nats)")
    top = sorted(((k, v) for k, v in qv.items() if "'mo'" in k), key=lambda kv: -kv[1]["n"])[:25]
    lines += [f"  {k[3:]:22s} n {v['n']:6d}  mu {v['mu']:.3f}  s_obs {v['s_obs']:.3f}  s_indep {v['s_indep']:.3f}  "
              f"ratio {v['s_indep'] / v['s_obs']:4.2f}  c {v['c']:7.1f}  {0.5 * v['c'] * 0.01:5.2f}" for k, v in top]
    txt = "\n".join(lines)
    Path(REPO / "data/refit/bvs").mkdir(parents=True, exist_ok=True)
    (REPO / "data/refit/bvs/fit_report.txt").write_text(txt)
    print(txt + f"\nwrote {out_db}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
