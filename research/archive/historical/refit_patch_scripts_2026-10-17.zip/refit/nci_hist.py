"""nci_hist.py -- 2D histograms and tables of the noncovalent interaction term (plan 3 N2, 2026-10-17 c; stats/nci.py).

    python refit/nci_hist.py hist --workers 6   # per shard: data/refit/observations/nci/ncihist_<shard>.npz
    python refit/nci_hist.py fit [--db <db>]    # -> <db>_nci.json (derived DB: the input's entries + "NCI:")

The training shards of the 2026-10 refit (data/refit/reports/contacts/shards.json: cleaned tmQM X1-X3 + LnQM), the
same benchmark exclusion and LnQM sibling weights as the refit's Q6 histograms (pattern: q6_m13_hist.py).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(HERE))
OBS = REPO / "data" / "refit" / "observations" / "nci"
SHARDS = REPO / "data" / "refit" / "reports" / "contacts" / "shards.json"
DB_IN = REPO / "data" / "refit" / "final" / "constraints_refit_q6p5.json"


def _task(args):
    data_dir, shard, excl, wts = args
    import logging
    import warnings
    warnings.filterwarnings("ignore")
    logging.disable(logging.CRITICAL)
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    from jacobik.stats import nci
    from jacobik.stats.parser import TMQMParser

    t = time.time()
    acc = nci.HistAccumulator()
    n = err = 0
    excl = set(excl)
    for mol in TMQMParser(data_dir).stream_split(shard):
        n += 1
        if mol.csd_code in excl:
            continue
        try:
            acc.add(mol, wts.get(mol.csd_code, 1.0))
        except Exception:
            err += 1
    acc.save(OBS / f"ncihist_{shard}.npz")
    return dict(shard=shard, n=n, errors=err, s=round(time.time() - t))


def cmd_hist(a):
    import refit_lib as R
    OBS.mkdir(parents=True, exist_ok=True)
    shards = [s for s in json.loads(SHARDS.read_text()) if not (OBS / f"ncihist_{s['shard']}.npz").exists()]
    if a.limit:
        shards = shards[: a.limit]
    excl = R.benchmark_codes()
    wts = {d: R.sibling_weights(d) for d in sorted({s["dir"] for s in shards})}
    tasks = [(s["dir"], s["shard"], excl, wts[s["dir"]]) for s in shards]
    for i, st in enumerate(R._loky_unordered(_task, tasks, a.workers), 1):
        print(f"nci {i}/{len(tasks)} {st}", flush=True)


def cmd_fit(a):
    import numpy as np
    from jacobik.stats import nci
    hist = nci.load_hist(sorted(OBS.glob("ncihist_*.npz")))
    tabs = nci.fit_tables(hist)
    db_in = Path(a.db)
    db_out = db_in.with_name(db_in.stem + "_nci.json")
    db = json.loads(db_in.read_text())
    db.update(tabs)
    db_out.write_text(json.dumps(db))
    meta = db_in.with_name(db_in.stem + ".meta.json")
    m = json.loads(meta.read_text()) if meta.exists() else {}
    # only ADDS entries (read under the profile field nci): tools reading pools of the input DB accept it
    m.update(extends=str(m.get("extends") or db_in.resolve()),
             extends_adds=((m.get("extends_adds") + "; ") if m.get("extends_adds") else "")
             + "NCI tables (refit/nci_hist.py)")
    db_out.with_name(db_out.stem + ".meta.json").write_text(json.dumps(m, indent=1))
    lines = [f"{len(hist)} NCI labels in the histograms, {len(tabs)} tables (>= {nci.N_MIN} candidates in range)"]
    for k, e in sorted(tabs.items(), key=lambda kv: -kv[1]["n"]):
        s = np.array(e["s"])
        i, j = np.unravel_index(np.argmax(s), s.shape)
        lines.append(f"  {k:28s} n {e['n']:9d}  max ln g {s.max():+.2f} at r {e['r_lo'] + e['dr'] * (i + 0.5):.2f} A, "
                     f"angle {e['a_lo'] + e['da'] * (j + 0.5):.0f} deg; min {s.min():+.2f}")
    txt = "\n".join(lines)
    (REPO / "data" / "refit" / "nci_report.txt").write_text(txt)
    print(txt + f"\n-> {db_out}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("stage", choices=["hist", "fit"])
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--limit", type=int, default=0, help="hist: only the first N shards (smoke test)")
    p.add_argument("--db", default=str(DB_IN))
    a = p.parse_args()
    {"hist": cmd_hist, "fit": cmd_fit}[a.stage](a)


if __name__ == "__main__":
    main()
