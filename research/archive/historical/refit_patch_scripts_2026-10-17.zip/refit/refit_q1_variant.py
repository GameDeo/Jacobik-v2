"""refit_q1_variant.py -- re-fit ONLY the Q1 entries of a finished refit DB with another ladder variant.

    python refit/refit_q1_variant.py m_sub_early [--keep final_no_state]

Q1's pooled entries are the only part of constraints_refit.json that depends on the Q1 ladder variant (the variant
defines the pooling parents; stats.pooling). This runs the same code path as stage fit (PooledFitter on
final/exp/expanded_Q1.parquet, fit_independent, entries(r, variant); deterministic seeds), replaces the Q1: entries,
rewrites the sidecar's q1_variant and fit_summary.json, and copies the previous DB files to --keep first. Run
`run_refit.py select q6alt check` afterwards (delete final/constraints_refit_q6p5.json first) so selection.json and
the q6alt DB follow. Written 2026-10-15: the full refit's held-out pick was the state-free 'no_state' (0.013 ahead
of 'm_sub_early'); the owner keeps the oxidation / spin state in the keys.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("variant")
    ap.add_argument("--refit-dir", default=str(HERE.parent / "data" / "refit"))
    ap.add_argument("--keep", default="final_no_state", help="folder (under refit-dir) for the previous DB files")
    ap.add_argument("--workers", type=int, default=11)
    a = ap.parse_args(argv)
    sys.path.insert(0, str(HERE.parent / "src"))
    sys.path.insert(0, str(HERE))
    import refit_lib as R
    from jacobik.stats import ladders as L
    from jacobik.stats import pooling as PL

    if a.variant not in L.Q1_VARIANTS:
        raise SystemExit(f"unknown variant {a.variant}; one of {L.Q1_VARIANTS}")
    final = Path(a.refit_dir) / "final"
    db = final / "constraints_refit.json"
    summ = json.loads((final / "fit_summary.json").read_text())
    keep = Path(a.refit_dir) / a.keep
    keep.mkdir(exist_ok=True)
    for f in final.glob("*.json"):
        shutil.copy(f, keep / f.name)
    print(f"previous DB files copied to {keep}")
    r = summ["pooling"]["Q1"]
    t = time.time()
    pf = PL.PooledFitter("Q1", PL.load_expanded(final / "exp", "Q1"))
    n_ind = pf.fit_independent(n_workers=a.workers, progress=print)
    ent = pf.entries(r, a.variant)
    raw = {k: v for k, v in json.loads(db.read_text()).items() if not k.startswith("Q1:")}
    raw.update({f"Q1:{k}": e for k, e in ent.items()})
    db.write_text(json.dumps(raw))
    n_ad = sum(1 for e in ent.values() if e.get("src") == "adapted")
    print(f"Q1 ({a.variant}, r={r:g}): {len(ent)} entries ({n_ind} fitted on own data, {n_ad} adapted)  "
          f"{time.time() - t:.0f}s")
    meta = json.loads((final / "constraints_refit.meta.json").read_text())
    R.write_meta(final, a.variant, summ["pooling"],
                 extra={k: v for k, v in meta.items() if k not in ("q1_variant", "pooling", "benchmark_holdout")})
    summ["Q1-Q6"]["Q1"].update(fitted=len(ent), independent=n_ind, adapted=n_ad)
    summ["variant"] = a.variant
    summ["q1_variant_note"] = f"Q1 re-fitted with {a.variant} by refit_q1_variant.py (previous: {keep.name})"
    (final / "fit_summary.json").write_text(json.dumps(summ, indent=1, default=float))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
