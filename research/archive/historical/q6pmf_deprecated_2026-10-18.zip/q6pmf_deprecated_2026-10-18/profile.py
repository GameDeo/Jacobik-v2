"""One place for every setting that changes the solver's results (2026-10-16, ARCHITECTURE.md section 5).

Before this module ~40 environment switches, read at import in a dozen modules, decided the score, the degrees of
freedom, the embed and the output; it was not visible which combination a result came from. Now:

* a PROFILE is a named, frozen set of values for every result-changing field (FIELDS below);
* `JACOBIK_PROFILE` selects it (default: DEFAULT_PROFILE);
* `JACOBIK_PROFILE_OVERRIDES` (JSON object, field -> value) overrides single fields for an experiment;
* every module reads its fields from here at import (`get(name)`), and experiments in one process may still set the
  module attribute directly (tools/jdev/budget/gate.py does); `snapshot()` reads the LIVE module attributes, so what a
  result records is what actually ran.

Execution-only switches (devices, threads, GPU replay, MACE / xtb paths) are not fields: they do not change results
beyond the float path, and stay plain environment variables.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import os
from typing import Any, Dict, Tuple

#: field -> (module, attribute, legacy-2026-10 value, meaning). The attribute is the module global the code reads.
FIELDS: Dict[str, Tuple[str, str, Any, str]] = {
    "oxidation_model": ("jacobik.core.oxidation", "OXIDATION_MODEL", "legacy",
                        "query deduction: legacy radical/haptic inference or formal-charge training convention"),
    "angle_bends": ("jacobik.engine", "DEFAULT_ANGLE_BENDS", False,
                    "default for solve(angle_bends=None); explicit True/False takes precedence"),
    # --- score (ScoreModel) --------------------------------------------------------------------------------------
    "score_agg": ("jacobik.ik.scorer", "SCORE_AGG", "mean",
                  "solve objective: 'mean' = per-quantity means, 'sum' = summed log-likelihood / Z"),
    "rank_agg": ("jacobik.ik.scorer", "RANK_AGG", "sum", "ranking score aggregation ('sum' or 'mean')"),
    "solve_floor": ("jacobik.ik.scorer", "GMM_FLOOR_MODE", "scorer",
                    "variance floor in the solve: 'scorer' (Q1 sd 0.2 A, Q2/Q3 0.05 cos, Q4 2 deg), 'fit' (fit-time "
                    "precision floor) or 'thermal' (298 K widths, scorer.THERMAL_SD; also S_orient)"),
    "rank_floor_fit": ("jacobik.ik.ik_solver", "_RANK_FLOOR", True, "rank with the fit-time floors (true widths)"),
    "q1_tail_sigma": ("jacobik.ik.scorer", "Q1_TAIL_SIGMA", 0.10,
                      "ranking drops Q1 components broader than this (A); 0 = keep all"),
    "q1_wall": ("jacobik.ik.scorer", "Q1_WALL", True, "one-sided Q1 wall beyond the table's support"),
    "q5_fold": ("jacobik.ik.scorer", "Q5_FOLD_MODE", "auto", "rotor folding of Q5 densities: auto / 1 / 0"),
    "q6_model": ("jacobik.ik.scorer", "Q6_MODEL", "wall", "steric model: 'wall' or 'pmf'"),
    "q6_agg": ("jacobik.ik.scorer", "Q6_AGG", "softmin", "steric term in a mean-aggregated solve: 'softmin' or 'sum'"),
    "q6_pmf_wells": ("jacobik.stats.q6pmf", "PMF_WELLS", "hbond",
                     "PMF form: 'hbond', 'all', 'contact' or 'repulsive' (contact + physical repulsion on class-5 pairs)"),
    "q6_rep_class4": ("jacobik.stats.q6pmf", "REP_CLASS4", False,
                      "repulsive Q6: the physical repulsion also on 1-5 (class 4) pairs, not only the core"),
    "q6_m13": ("jacobik.ik.scorer", "Q6_M13", False, "metal 1-3 contacts (M...X, X bonded to a donor) in Q6"),
    "nci": ("jacobik.stats.nci", "NCI_ON", False,
            "noncovalent interaction term NCI (plan 3 N2; H-bond, pi-pi, CH-pi): needs a DB with NCI entries "
            "(refit/run_refit.py fit); replaces the contact Q6's polar-H wells"),
    "nci_types": ("jacobik.stats.nci", "ACTIVE_TYPES", ("hb", "pp", "chp"),
                  "enabled NCI components when nci is true; only hb replaces Q6 polar-H attractions"),
    "bvs": ("jacobik.ik.scorer", "BVS", False,
            "bond-valence coupling term QV (plan 3 S2): needs a DB with QV / QVR entries (refit/run_refit.py fit, jacobik.stats.bvs)"),
    "haptic_per_sub": ("jacobik.ik.scorer", "HAPTIC_PER_SUB", True, "haptic S_orient per substituent"),
    "bend_per_z": ("jacobik.ik.ik_solver", "_BEND_PER_Z", False,
                   "bend prior divided by the score's per-complex constant Z (summed objective in one unit)"),
    # --- embed (SolverConfig) --------------------------------------------------------------------------------------
    "embed": ("jacobik.engine", "DEFAULT_EMBED", "gfn2", "free-ligand embed refinement: gfn2 / mmff / etkdg"),
    "deterministic_embed": ("jacobik.engine", "DETERMINISTIC_EMBED", False,
                            "GFN2 embed on one OpenMP thread: bit-reproducible seeds under CPU load, slower"),
    "chelate_ez": ("jacobik.chelate_embed", "CHELATE_EZ", True, "chelate embed fixes E/Z between donors"),
    "carbene_ylide": ("jacobik.chelate_embed", "CARBENE_YLIDE", True, "carbene donors embedded as ylides"),
    "eta2_cap": ("jacobik.chelate_embed", "ETA2_CAP", False, "temporary cap on eta2 donors in the embed"),
    "bound_surrogate": ("jacobik.chelate_embed", "BOUND_SURROGATE", False,
                        "embed group-13 donors written as D=[X+] as their bound, H-capped form"),
    "ez_enumerate": ("jacobik.chelate_embed", "EZ_ENUMERATE", False,
                     "solve every E/Z combination of double bonds the SMILES and the chelate rule leave open"),
    # --- degrees of freedom (SolverConfig) ---------------------------------------------------------------------------
    "branch_bends": ("jacobik.ik.fk", "BRANCH_BENDS", True, "bend DOFs on branch junctions"),
    "branch_prior": ("jacobik.ik.fk", "BRANCH_PRIOR", False, "prior on branch bends"),
    "ring_open_adj": ("jacobik.ik.fk", "_SMALL_RING_OPEN_ADJ", True, "small donor rings opened next to the joint"),
    "ring_joints": ("jacobik.topology.decompose", "RING_JOINTS", True, "small donor rings as torsion joints"),
    "donor_bends": ("jacobik.ik.angle_bends", "DONOR_BENDS", False, "S_orient-priced bends of donor branches"),
    "haptic_bends": ("jacobik.ik.angle_bends", "HAPTIC_BENDS", True, "bends at haptic faces"),
    "haptic_free_lean_max": ("jacobik.ik.angle_bends", "HAPTIC_FREE_LEAN_MAX", 6,
                             "haptic faces whose lean is statistics-priced"),
    "haptic_lean_wall": ("jacobik.ik.angle_bends", "HAPTIC_LEAN_WALL", True, "wall on haptic lean"),
    "haptic_lean_all": ("jacobik.ik.angle_bends", "HAPTIC_LEAN_ALL", False,
                        "lean wall for every haptic face size (legacy: eta2 / eta3 only)"),
    "local_plane_deg": ("jacobik.ik.angle_bends", "LOCAL_PLANE_DEG", 20.0, "planarity tolerance for bend typing (deg)"),
    "beam_mode_score": ("jacobik.ik.beam", "BEAM_MODE_SCORE", "density",
                        "beam ranks torsion modes by 'density' at the mode mean or by 'mass' (mode weight)"),
    # --- output (SolverConfig) ---------------------------------------------------------------------------------------
    "out_dedup": ("jacobik.ik.dedup", "OUT_DEDUP", True, "symmetry-aware RMSD dedup of the output"),
    "dedup_rmsd": ("jacobik.ik.dedup", "DEDUP_RMSD", 0.5, "dedup threshold (A, heavy atoms + metal)"),
    "out_window": ("jacobik.engine", "OUT_WINDOW", 200.0, "output score window (summed nats); 0 = off"),
}

#: named profiles: field -> value (fields not listed take the legacy value)
PROFILES: Dict[str, Dict[str, Any]] = {
    # production as of 2026-10-16 (10-16 b: output window, cache-key fix); frozen to reproduce every 10-16 number
    "legacy-2026-10": {},
    # plan U2 (2026-10-16 d): one objective for the solve and the ranking. Summed log-likelihood (every feature once,
    # S_orient and the Q6 walls summed), table widths floored at the 298 K thermal width instead of the 0.2 A guard,
    # ranking with the same floors, no Q1 tail cut, bend prior in the score's units.
    # + 10-16 d: the lean wall for every haptic face size (the summed objective found the Cp-H fold; arm u1+lean) and
    # the E/Z enumeration of bonds neither the SMILES nor the chelate rule decide (arm u1+lean+ez).
    "u1": {"score_agg": "sum", "rank_agg": "sum", "solve_floor": "thermal", "rank_floor_fit": False,
           "q1_tail_sigma": 0.0, "bend_per_z": True, "haptic_lean_all": True, "ez_enumerate": True,
           "bound_surrogate": True,
           "angle_bends": True, "oxidation_model": "training",
           # Q6: physical exchange repulsion on class-5 pairs + the contact core elsewhere (plan 3 N1, adopted 10-17 c:
           # arm vs the contact form #1 -13.7 [-22.5, -7.0]; CHANGELOG)
           "q6_model": "pmf", "q6_pmf_wells": "repulsive"},
}
DEFAULT_PROFILE = "legacy-2026-10"


def _coerce(name: str, v: Any) -> Any:
    if name == "nci_types":
        allowed = ("hb", "pp", "chp")
        if not isinstance(v, (list, tuple)) or any(x not in allowed for x in v) or len(set(v)) != len(v):
            raise ValueError("nci_types must be an array of unique values from hb, pp, chp")
        return tuple(x for x in allowed if x in v)
    ref = FIELDS[name][2]
    if isinstance(ref, bool):
        return v if isinstance(v, bool) else str(v).lower() not in ("0", "", "false", "no", "off")
    if isinstance(ref, int) and not isinstance(ref, bool):
        return int(v)
    if isinstance(ref, float):
        return float(v)
    return str(v)


#: environment switches that used to set a field (or a variant removed 2026-10-16). Setting one now is an error, not
#: a silent no-op: benchmark arms pass environment variables to worker processes.
RETIRED_ENV = {
    "JACOBIK_SCORE_AGG": "score_agg", "JACOBIK_RANK_AGG": "rank_agg", "JACOBIK_GMM_FLOOR": "solve_floor",
    "JACOBIK_RANK_FLOOR": "rank_floor_fit", "JACOBIK_Q1_TAIL_SIGMA": "q1_tail_sigma", "JACOBIK_Q1_WALL": "q1_wall",
    "JACOBIK_Q5_FOLD": "q5_fold", "JACOBIK_Q6_MODEL": "q6_model", "JACOBIK_Q6_AGG": "q6_agg",
    "JACOBIK_Q6_PMF_WELLS": "q6_pmf_wells", "JACOBIK_HAPTIC_PER_SUB": "haptic_per_sub", "JACOBIK_EMBED": "embed",
    "JACOBIK_CHELATE_EZ": "chelate_ez", "JACOBIK_CARBENE_YLIDE": "carbene_ylide", "JACOBIK_ETA2_CAP": "eta2_cap",
    "JACOBIK_BRANCH_BENDS": "branch_bends", "JACOBIK_BRANCH_PRIOR": "branch_prior",
    "JACOBIK_RING_OPEN_ADJ": "ring_open_adj", "JACOBIK_RING_JOINTS": "ring_joints", "JACOBIK_DONOR_BENDS": "donor_bends",
    "JACOBIK_HAPTIC_BENDS": "haptic_bends", "JACOBIK_HAPTIC_FREE_LEAN_MAX": "haptic_free_lean_max",
    "JACOBIK_HAPTIC_LEAN_WALL": "haptic_lean_wall", "JACOBIK_LOCAL_PLANE_DEG": "local_plane_deg",
    "JACOBIK_OUT_DEDUP": "out_dedup", "JACOBIK_DEDUP_RMSD": "dedup_rmsd", "JACOBIK_OUT_WINDOW": "out_window",
    # removed variants / frozen labels
    "JACOBIK_Q6_WCA_N": None, "JACOBIK_Q6_WCA_T": None, "JACOBIK_SHAPE_CORE": None, "JACOBIK_SHAPE_TAIL": None,
    "JACOBIK_SHAPE_TAIL_FORM": None, "JACOBIK_SHAPE_TERMS": None, "JACOBIK_Q5_TEMPER": None, "JACOBIK_RING_LEAN": None,
    "JACOBIK_RING_KEEP_FOLDS": None, "JACOBIK_CARBON_STRUCTURAL": None, "JACOBIK_RESONANCE_LABELS": None,
    "JACOBIK_HAPTIC_V2": None, "JACOBIK_SHAPE_LABELS": None, "JACOBIK_Q6_METAL_EXCL": None,
    "JACOBIK_Q6_THROUGH_METAL": None,
}


def _load() -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
    stale = sorted(k for k in RETIRED_ENV if k in os.environ)
    if stale:
        hint = {k: RETIRED_ENV[k] for k in stale}
        raise RuntimeError(f"retired environment switches set: {stale}. Use JACOBIK_PROFILE / JACOBIK_PROFILE_OVERRIDES "
                           f"(JSON, field -> value; fields {hint}; None = removed, ARCHITECTURE.md)")
    name = os.environ.get("JACOBIK_PROFILE", DEFAULT_PROFILE)
    if name not in PROFILES:
        raise ValueError(f"JACOBIK_PROFILE={name!r} unknown; profiles: {sorted(PROFILES)}")
    raw = os.environ.get("JACOBIK_PROFILE_OVERRIDES", "").strip()
    over = json.loads(raw) if raw else {}
    bad = sorted(set(over) - set(FIELDS))
    if bad:
        raise ValueError(f"JACOBIK_PROFILE_OVERRIDES: unknown fields {bad}; fields: {sorted(FIELDS)}")
    vals = {k: v[2] for k, v in FIELDS.items()}
    vals.update(PROFILES[name])
    vals.update({k: _coerce(k, v) for k, v in over.items()})
    return name, vals, over


ACTIVE_NAME, _VALUES, OVERRIDES = _load()


def get(name: str) -> Any:
    """The value of a field under the active profile (+ overrides). Modules call this at import."""
    return _VALUES[name]


def snapshot() -> Dict[str, Any]:
    """Every field as the code will use it NOW (live module attributes), the profile name and a fingerprint."""
    live = {}
    for k, (mod, attr, _, _) in FIELDS.items():
        try:
            live[k] = getattr(importlib.import_module(mod), attr)
        except Exception:  # a module that cannot import here (optional dependency) reports the profile value
            live[k] = _VALUES[k]
    differs = {k: v for k, v in live.items() if v != {**{f: d[2] for f, d in FIELDS.items()},
                                                       **PROFILES[ACTIVE_NAME]}[k]}
    fp = hashlib.sha1(json.dumps(live, sort_keys=True, default=str).encode()).hexdigest()[:12]
    return dict(profile=ACTIVE_NAME, fingerprint=fp, differs_from_profile=differs, fields=live)
