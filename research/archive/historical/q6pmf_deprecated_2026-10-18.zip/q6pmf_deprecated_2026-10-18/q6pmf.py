"""
q6pmf.py -- Q6 as a potential of mean force with a physical core (2026-10-14; experimental; profile field q6_model='pmf',
default off, on in profile u1).

Why. The Q6 walls (5th-percentile or 0.1 %-onset half-Gaussians) keep only "not closer than mu" from the contact
distribution: they drop where favoured contacts sit (hydrogen bonds score well only if a structure happens to have one)
and they extrapolate into the clash region, where tmQM minima have no data at all, with a statistical width. GFN2 dimer
scans put the physical repulsion 3-10x steeper than either wall for heavy-atom contacts (C...H at 1.9 A: ~+15 kT vs
1.5-1.8 nats).

What. Per Q6 key (element pair, polar-H keys "Hp" included), bond-separation class and, for polar H facing an
acceptor, D-H...A angle class:
  * data region (r >= r0, the key's 0.1 % onset):  w(r) = -ln g(r),  g = p_key(r) / (prior * p_ref(r)),
    p_ref = the pooled distance distribution of ALL keys of the same class (removes molecule size/shape, which an
    ideal-gas r^2 reference turns into 1-2 kT fake wells at 4-5 A), prior = the random-orientation share of the angle
    class (0.25 for D-H...A >= 120 deg, 0.75 below; 1 without angle);
  * core (r < r0): w(r) = w(r0) + kappa (exp(b (r0 - r)) - 1), b and kappa from GFN2 head-on dimer scans
    (E = A exp(-b r); kappa = A exp(-b r0) / RT, at least 1) where scanned, else generic (b = 4.0 / A with H, 3.2
    otherwise; kappa = 1); continued linearly above 50 kT so deep overlaps keep a gradient;
  * tapered to 0 between 5 and 6 A.
w is in kT (RT at 298.15 K); the score uses log p = -w per pair, SUMMED over pairs.
Classes: "4" = exactly 4 ligand bonds apart (distance set by chain geometry), "m" = pairs with the metal,
"5" = everything else (>= 5 bonds, other ligands, pairs joined only through the metal).

Data. Extraction (stats/extractor.py) accumulates uncapped histograms (0.02 A bins to 8 A) per (key, class, angle
class) into q6hist_<split>.npz; the refit merges them per dataset and fits the tables in the fit stage (Q6P: entries).
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np

R_MAX_HIST = 8.0
DR_HIST = 0.02
EDGES = np.round(np.arange(0.0, R_MAX_HIST + 1e-9, DR_HIST), 4)
NB = len(EDGES) - 1
ANGLE_SPLIT_COS = -0.5            # D-H...A angle 120 deg
ANGLE_PRIOR = {"": 1.0, "lin": 0.25, "bent": 0.75}   # random-orientation share of each angle class
RT_KJ = 2.479                     # kJ/mol at 298.15 K
# table grid used by the scorer
R_LO, R_HI, DR_TAB = 0.6, 6.0, 0.02
R_TAPER = 5.0
W_LINEAR_ABOVE = 50.0
N_MIN = 3000                      # pairs of a key (all angle classes) for a table of its own
N_MIN_BIN = 25                    # counts in the 0.06 A window for a data-region value
ONSET_Q = 1e-3
W_DATA_CLIP = 8.0
#: which attractive parts of the PMF the runtime keeps (profile field q6_pmf_wells, 2026-10-14 check): "all" = the full w(r);
#: "hbond" = wells only for polar-H...acceptor pairs, every other pair max(w, 0) (core + barriers). Summed over ~10^3
#: pairs, the generic ~-1 kT contact wells reward compaction (BIDHEB, small check: Q6 -70 kT over 819 pairs, the solve
#: folded an acyl O onto Pd, MACE dE 2458 kJ/mol).
#: "contact" (2026-10-16 f): the physical core below each key's onset r0 for every pair (0 at and above r0), and for
#: polar-H...acceptor pairs the attractive part of the data curve (the H-bond well) out to H-bond range (HBOND_TAPER).
#: No other data region: beyond contact -ln(p_key / p_ref) is molecular shape, and clamped to max(w, 0) and summed over
#: ~10^3 pairs it pushed ligands off the metal (CHANGELOG 2026-10-16 f).
#: "repulsive" (2026-10-17 c, plan 3 branch N): the contact form, except that every class-5 pair that is not a
#: polar-H...acceptor pair (those belong to the H-bond / NCI term) gets the PHYSICAL exchange repulsion instead of the
#: core: U = A [e^(-b r) - e^(-b r_m) + b e^(-b r_m) (r - r_m)] / RT below the contact distance r_m (Alvarez vdW
#: sum), 0 beyond (zero value and force at r_m), linear above W_LINEAR_ABOVE. A, b per element from GFN2-xTB dimers
#: fitted jointly over all atom pairs (REP_PARAMS); Buckingham combination A_ij = sqrt(A_i A_j), b_ij = mean.
#: Class 4 (1-5) pairs keep the core (their sterics are in the Q5 torsion statistics) unless REP_CLASS4.
PMF_WELLS =__import__("jacobik.profile", fromlist=["get"]).get("q6_pmf_wells")  # profile field
REP_CLASS4 = __import__("jacobik.profile", fromlist=["get"]).get("q6_rep_class4")  # profile field
# GFN2-xTB head-on dimer scans (2026-10-14; E = A exp(-b r) on the repulsive branch, A in kJ/mol, b in 1/A).
# O...O is left out: the lone-pair/lone-pair scan is electrostatic out to 5 A (b = 1.6), not a contact core.
GFN2_CORES: Dict[str, Tuple[float, float]] = {
    "H_H": (8489.4, 4.191), "C_H": (31933.4, 3.603), "H_O": (88302.4, 5.078), "H_N": (192171.6, 5.585),
    "C_O": (136563.3, 3.528), "Hp_O": (824315.4, 7.699), "Hp_N": (3488633.6, 8.812), "C_C": (30022.0, 2.884),
}
GENERIC_B_H, GENERIC_B = 4.0, 3.2
#: repulsive Q6 (2026-10-17 c): per-element exchange repulsion {element: (A kJ/mol, b 1/A)} from
#: tools/jdev/budget/gfn2_dimer_scan.py (data/refit/q6rep/params.json), and Alvarez 2013 vdW radii (A). "Hp" uses H.
#: Fit 2026-10-17 c: 17 probes without polar H, 14 688 dimers, R^2 0.94, Spearman 0.93 on repulsive configurations;
#: b at its lower bound 2.5 / A for B, N, O, P, S, Si (soft, lone-pair electrostatics in the noise).
REP_PARAMS: Dict[str, Tuple[float, float]] = {
    "H": (8304.2, 3.867), "B": (6217.9, 2.5), "C": (52908.4, 3.1943), "N": (2558.4, 2.5), "O": (1794.0, 2.5),
    "F": (4288.8, 2.5493), "Si": (107369.6, 2.5), "P": (30445.7, 2.5), "S": (30862.1, 2.5), "Cl": (69172.6, 2.8674),
    "Se": (102333.9, 2.5882), "Br": (451089.0, 3.0641), "I": (2844105.5, 3.2715)}
ALVAREZ_RADII: Dict[str, float] = {"H": 1.20, "B": 1.91, "C": 1.77, "N": 1.66, "O": 1.50, "F": 1.46, "Si": 2.19,
                                   "P": 1.90, "S": 1.89, "Cl": 1.82, "Se": 1.82, "Br": 1.86, "I": 2.04}


def rep_pair_params(e1: str, e2: str) -> Optional[Tuple[float, float, float, float]]:
    """(A kJ/mol, b 1/A, r_m A, r_lin A) of the physical repulsion of an element pair, or None without parameters.
    r_lin: below it U is continued linearly (U(r_lin) = W_LINEAR_ABOVE kT)."""
    e1, e2 = ("H" if e1 == "Hp" else e1), ("H" if e2 == "Hp" else e2)
    if e1 not in REP_PARAMS or e2 not in REP_PARAMS or e1 not in ALVAREZ_RADII or e2 not in ALVAREZ_RADII:
        return None
    A = math.sqrt(REP_PARAMS[e1][0] * REP_PARAMS[e2][0])
    b = 0.5 * (REP_PARAMS[e1][1] + REP_PARAMS[e2][1])
    rm = ALVAREZ_RADII[e1] + ALVAREZ_RADII[e2]
    u = lambda r: A * (math.exp(-b * r) - math.exp(-b * rm) + b * math.exp(-b * rm) * (r - rm)) / RT_KJ
    lo, hi = 0.0, rm
    if u(lo) <= W_LINEAR_ABOVE:
        return A, b, rm, 0.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if u(mid) > W_LINEAR_ABOVE else (lo, mid)
    return A, b, rm, hi


def rep_energy(d, A, b, rm, rl):
    """Physical repulsion (kT) at distances d (torch, any shape; A, b, rm, rl broadcastable): shifted force below rm,
    0 at and beyond, linear below rl."""
    import torch

    A, b, rm, rl = (torch.as_tensor(v, dtype=d.dtype, device=d.device) for v in (A, b, rm, rl))
    em = torch.exp(-b * rm)
    u = lambda r: A * (torch.exp(-b * r) - em + b * em * (r - rm)) / RT_KJ
    slope = A * b * (torch.exp(-b * rl) - em) / RT_KJ  # -dU/dr at rl
    lin = u(rl) + slope * (rl - d)
    out = torch.where(d < rl, lin, u(torch.maximum(d, rl)))
    return torch.where(d < rm, out, torch.zeros_like(out))


def key_name(key: Tuple[str, str]) -> str:
    return f"{key[0]}_{key[1]}"


# ----------------------------------------------------------------------------------------------------------------
# topology: bond-separation class of each Q6 pair (shared by extraction and runtime)
# ----------------------------------------------------------------------------------------------------------------
def ligand_separation(mol, max_depth: int = 4) -> Dict[int, Dict[int, int]]:
    """{atom idx: {atom idx: bonds apart along LIGAND bonds (metal excluded)}} up to max_depth."""
    from jacobik.topology.graph import get_ligand_neighbors

    nb = get_ligand_neighbors(mol.atoms, mol.bonds, mol.metal_idx)
    out: Dict[int, Dict[int, int]] = {}
    for a in mol.atoms:
        if a.idx == mol.metal_idx:
            continue
        seen = {a.idx: 0}
        frontier = [a.idx]
        for d in range(1, max_depth + 1):
            nxt = []
            for u in frontier:
                for v in nb.get(u, ()):
                    if v not in seen:
                        seen[v] = d
                        nxt.append(v)
            frontier = nxt
        out[a.idx] = seen
    return out


def pair_class(i: int, j: int, metal_idx: int, sep: Dict[int, Dict[int, int]]) -> str:
    if i == metal_idx or j == metal_idx:
        return "m"
    return "4" if sep.get(i, {}).get(j) == 4 else "5"


#: Metal 1-3 class (2026-10-16 d, plan U4): the metal and an atom X bonded to a donor (W...H of a Cp ring, Pd...O of an
#: acyl). The Q6 exclusions drop these pairs (Q6_METAL_EXCL = 2), so nothing stopped X from being pushed into the metal
#: (COPYIP 866 kJ/mol, BIDHEB). In the data region the M...X distance is already priced by the M-D-X angle (S_orient,
#: haptic bend), so the class is CORE ONLY: w = 0 at and beyond the key's 0.1 % onset r0, the physical core below it.
M13 = "m13"
#: ... and for X bonded to an atom of a haptic face (a Cp ring H): its own class, because pooled with kappa donors (where
#: agostic C-H and bridging H reach 1.7-1.9 A) the onset hides that a Cp H never comes closer than ~2.7 A (YAVFEG's u1
#: #1: Cp H 2.41 A from Zr, 1200 kJ/mol; good structures >= 2.89 A).
M13_HAPTIC = "m13h"
M13_CLASSES = (M13, M13_HAPTIC)
#: pooled metal token for 1-3 keys without enough data of their own metal ("Mx_H": every metal)
M13_POOLED = "Mx"


def metal_13_pairs(mol) -> List[Tuple[int, int, str]]:
    """(metal idx, X idx, class), 1-based: X bonded through a ligand bond to a donor atom, X neither a donor nor bonded
    to the metal itself (raw bond-order evidence); class M13_HAPTIC if X is bonded to an atom of a haptic face."""
    from jacobik.stats.mapping import raw_metal_bond_exclusion_pairs
    from jacobik.topology.graph import donor_indices_of, get_ligand_neighbors

    m = mol.metal_idx
    don = set(donor_indices_of(mol))
    nb = get_ligand_neighbors(mol.atoms, mol.bonds, m)
    raw = raw_metal_bond_exclusion_pairs(mol.atoms, mol.bonds, m, q6=True)
    hapt = {d for si in getattr(mol, "coord_sites", None) or [] if si.kind == "haptic" for d in si.donor_indices}
    xs: Dict[int, str] = {}
    for d in don:
        for x in nb.get(d, ()):
            if x in don or x == m or tuple(sorted((m, x))) in raw:
                continue
            if d in hapt or x not in xs:
                xs[x] = M13_HAPTIC if d in hapt else M13
    return [(m, x, xs[x]) for x in sorted(xs)]


def m13_keys(sym_m: str, sym_x: str) -> Tuple[Tuple[str, str], Tuple[str, str]]:
    """(own key, pooled key) of a metal 1-3 pair, sorted element pairs."""
    own = tuple(sorted((sym_m, sym_x)))
    pooled = tuple(sorted((M13_POOLED, sym_x)))
    return own, pooled


def m13_records(mol):
    """Histogram records of the metal 1-3 pairs of a crystal: labels "a_b|m13|" for the own and the pooled key."""
    sym = {a.idx: a.symbol for a in mol.atoms}
    P = {a.idx: np.asarray(a.position, float) for a in mol.atoms}
    labels: List[str] = []
    dist: List[float] = []
    for m, x, cls in metal_13_pairs(mol):
        d = float(np.linalg.norm(P[m] - P[x]))
        for k in m13_keys(sym[m], sym[x]):
            labels.append(f"{key_name(k)}|{cls}|")
            dist.append(d)
    return labels, np.asarray(dist)


def fit_m13_walls(hist: Dict[str, np.ndarray], n_min: int = N_MIN) -> Dict[str, dict]:
    """Metal 1-3 walls for the wall model, fitted exactly as fitter.fit_halfgauss fits the q6p5 walls (mu = 5th
    percentile; sigma = sd of the left tail mirrored about mu, at least 0.1 A), here from the 0.02 A histograms.
    Entries "Q6P:(a, b, cls, 'wall')"."""
    rc = 0.5 * (EDGES[1:] + EDGES[:-1])
    out = {}
    for lab, h in hist.items():
        name, cls, ang = lab.split("|")
        if cls not in M13_CLASSES or ang != "" or h.sum() < n_min:
            continue
        cum = np.cumsum(h) / h.sum()
        mu = float(np.interp(0.05, cum, rc))
        left = rc <= mu
        sigma = float(np.sqrt((h[left] * (rc[left] - mu) ** 2).sum() / max(h[left].sum(), 1e-12)))
        sigma = max(sigma, 0.1)
        a_, b_ = name.split("_")
        out[f"Q6P:{(a_, b_, cls, 'wall')!r}"] = dict(type="halfgauss", n=int(h.sum()), k=1, mu=round(mu, 4),
                                                     sigma=round(sigma, 4))
    return out


def m13_wall_pairs(mol, tables: Dict[tuple, dict]):
    """[(metal pos, X pos, mu, sigma)] (0-based positions in mol.atoms) of the metal 1-3 pairs with a wall entry (own
    metal key, else the pooled one)."""
    pos = {a.idx: i for i, a in enumerate(mol.atoms)}
    sym = {a.idx: a.symbol for a in mol.atoms}
    out = []
    for m, x, cls in metal_13_pairs(mol):
        own, pooled = m13_keys(sym[m], sym[x])
        e = tables.get((own[0], own[1], cls, "wall")) or tables.get((pooled[0], pooled[1], cls, "wall"))
        if e is not None and m in pos and x in pos:
            out.append((pos[m], pos[x], float(e["mu"]), float(e["sigma"])))
    return out


def polar_donor(mol, polar: Iterable[int]) -> Dict[int, int]:
    """{polar H idx: its donor atom idx} (first ligand neighbour)."""
    from jacobik.topology.graph import get_ligand_neighbors

    nb = get_ligand_neighbors(mol.atoms, mol.bonds, mol.metal_idx)
    return {h: nb[h][0] for h in polar if nb.get(h)}


# ----------------------------------------------------------------------------------------------------------------
# extraction: uncapped histograms
# ----------------------------------------------------------------------------------------------------------------
def contact_records(mol, r_max: float = R_MAX_HIST):
    """Every Q6 pair of a crystal (the extractor's exclusions) within r_max: (labels "a_b|cls|ang", distances).
    Polar-H pairs give two records: the angle class ("lin"/"bent") and the total (""), so totals cover every pair."""
    from jacobik.stats import key_builder as kb
    from jacobik.stats.mapping import raw_metal_bond_exclusion_pairs
    from jacobik.topology.graph import donor_indices_of, q6_topological_exclusions

    atoms = list(mol.atoms)
    if len(atoms) < 2:
        return [], np.zeros(0)
    P = np.array([a.position for a in atoms], dtype=float)
    idx = [a.idx for a in atoms]
    pos = {a: i for i, a in enumerate(idx)}
    sym = [a.symbol for a in atoms]
    close = q6_topological_exclusions(mol.atoms, mol.bonds, mol.metal_idx, donor_indices_of(mol))
    close |= raw_metal_bond_exclusion_pairs(mol.atoms, mol.bonds, mol.metal_idx, q6=True)
    polar = kb.q6_polar_h(mol)
    donor = polar_donor(mol, polar)
    sep = ligand_separation(mol)
    D = np.linalg.norm(P[:, None] - P[None], axis=-1)
    ii, jj = np.nonzero(np.triu(D < r_max, k=1))
    labels: List[str] = []
    dist: List[float] = []
    for a, b in zip(ii.tolist(), jj.tolist()):
        lo, hi = (idx[a], idx[b]) if idx[a] < idx[b] else (idx[b], idx[a])
        if (lo, hi) in close:
            continue
        key = kb.q6_pair_key(sym[a], sym[b], idx[a] in polar, idx[b] in polar)
        cls = pair_class(idx[a], idx[b], mol.metal_idx, sep)
        base = key_name(key) + "|" + cls
        labels.append(base + "|")
        dist.append(D[a, b])
        if "Hp" in key:
            h, acc = (a, b) if (idx[a] in polar and sym[b] in kb.Q6_ACCEPTORS) else (b, a)
            dn = donor.get(idx[h])
            if dn is not None and dn in pos:
                u, v = P[pos[dn]] - P[h], P[acc] - P[h]
                c = float(u @ v / max(np.linalg.norm(u) * np.linalg.norm(v), 1e-12))
                labels.append(base + ("|lin" if c <= ANGLE_SPLIT_COS else "|bent"))
                dist.append(D[a, b])
    return labels, np.asarray(dist)


class HistAccumulator:
    """Per-label distance histograms (EDGES), summed over complexes."""

    def __init__(self, records=None):
        """records: mol -> (labels, distances); default contact_records (m13_records for the metal 1-3 pass)."""
        self.h: Dict[str, np.ndarray] = {}
        self.records = records or contact_records

    def add(self, mol, weight: float = 1.0) -> None:
        """weight: the complex's share of its independent structure (LnQM: 1 / siblings of its ligand set)."""
        labels, d = self.records(mol)
        if not labels:
            return
        lab = np.asarray(labels)
        uniq, inv = np.unique(lab, return_inverse=True)
        b = np.clip((d / DR_HIST).astype(np.int64), 0, NB - 1)
        cnt = np.bincount(inv * NB + b, minlength=len(uniq) * NB).reshape(len(uniq), NB) * float(weight)
        for k, row in zip(uniq.tolist(), cnt):
            if k in self.h:
                self.h[k] += row
            else:
                self.h[k] = row.astype(np.float64)

    def save(self, path) -> None:
        np.savez_compressed(path, edges=EDGES, **{"h:" + k: v for k, v in self.h.items()})


def load_hist(paths: Iterable) -> Dict[str, np.ndarray]:
    """Sum histogram files (q6hist_*.npz)."""
    out: Dict[str, np.ndarray] = {}
    for p in paths:
        z = np.load(p)
        for k in z.files:
            if k.startswith("h:"):
                out[k[2:]] = out.get(k[2:], 0) + z[k]
    return out


# ----------------------------------------------------------------------------------------------------------------
# fit
# ----------------------------------------------------------------------------------------------------------------
def core_params(name: str, r0: float) -> Tuple[float, float]:
    """(b, kappa) of the physical core for element-pair name 'A_B' at onset r0."""
    if name in GFN2_CORES:
        A, b = GFN2_CORES[name]
        return b, max(A * math.exp(-b * r0) / RT_KJ, 1.0)
    return (GENERIC_B_H if "H" in name.split("_") or "Hp" in name.split("_") else GENERIC_B), 1.0


def _smooth(h: np.ndarray) -> np.ndarray:
    k = np.ones(3)
    return np.convolve(h.astype(float), k, mode="same")


def _core(grid: np.ndarray, r0: float, w_r0: float, b: float, kappa: float) -> np.ndarray:
    """w(r0) + kappa (exp(b (r0 - r)) - 1) for r < r0, continued linearly above W_LINEAR_ABOVE (keeps a gradient for
    deep overlaps, no overflow)."""
    wc = w_r0 + kappa * (np.exp(b * (r0 - grid)) - 1.0)
    lim = W_LINEAR_ABOVE
    if (wc > lim).any() and lim > w_r0:
        r_l = r0 - math.log((lim - w_r0) / kappa + 1.0) / b
        slope = kappa * b * math.exp(b * (r0 - r_l))
        over = wc > lim
        wc[over] = lim + slope * (r_l - grid[over])
    return wc


def _taper(r: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return np.where(r <= lo, 1.0, np.where(r >= hi, 0.0, np.cos(0.5 * math.pi * (r - lo) / (hi - lo)) ** 2))


#: angle-class correction: pseudo-count pulling sparse bins to the random-orientation prior, clip, and range (the
#: D-H...A preference is a contact effect; beyond ~4 A the class share reflects molecular shape, not the H-bond)
ANGLE_PSEUDO, ANGLE_CLIP, ANGLE_TAPER = 20.0, 4.0, (3.5, 4.5)
#: H-bond range of the "contact" mode: the polar-H well is tapered to 0 between these distances (H...A <= ~2.8 A)
HBOND_TAPER = (2.6, 3.0)


def fit_tables(hist: Dict[str, np.ndarray], n_min: int = N_MIN) -> Dict[str, dict]:
    """Q6P DB entries {"Q6P:('a', 'b', cls, ang)": {...}} from merged histograms.

    Totals (ang ""): w = -ln(p_key / p_ref) in the data region (r >= r0, smoothed bins with >= N_MIN_BIN counts; gaps
    interpolated, 0 beyond the data), clipped, tapered 5-6 A; physical core below r0.
    Angle classes ("lin" / "bent", polar H facing an acceptor): the total plus an angular correction
    -ln(f(r) / prior), f = the class's share of the key's pairs at r (pseudo-count ANGLE_PSEUDO toward the prior),
    held at its contact value below the data, clipped to +-ANGLE_CLIP, tapered to 0 over ANGLE_TAPER. The core is the
    total's (repulsion does not depend on the D-H...A angle; a class-own onset would put the bent-class core where
    bent contacts merely become rare)."""
    rc = 0.5 * (EDGES[1:] + EDGES[:-1])
    grid = np.round(np.arange(R_LO, R_HI + 1e-9, DR_TAB), 4)
    ref: Dict[str, np.ndarray] = {}
    for lab, h in hist.items():
        name, cls, ang = lab.split("|")
        if ang == "":
            ref[cls] = ref.get(cls, 0) + h
    out: Dict[str, dict] = {}
    totals: Dict[str, np.ndarray] = {}
    for lab, h in hist.items():
        name, cls, ang = lab.split("|")
        if cls in M13_CLASSES and ang == "" and h.sum() >= n_min:  # core only (see M13)
            i0 = int(np.searchsorted(np.cumsum(h) / h.sum(), ONSET_Q))
            r0 = float(rc[min(i0, NB - 1)])
            b, kappa = core_params(name, r0)
            tab = np.zeros(len(grid))
            core = grid < r0
            tab[core] = _core(grid[core], r0, 0.0, b, kappa)
            a_, b_ = name.split("_")
            out[f"Q6P:{(a_, b_, cls, '')!r}"] = dict(
                type="pmf", n=int(h.sum()), n_key=int(h.sum()), r0=round(r0, 3), core_b=round(b, 3),
                core_kappa=round(kappa, 3), r_lo=R_LO, dr=DR_TAB, w=[round(float(x), 4) for x in tab])
            continue
        if ang != "" or h.sum() < n_min or cls not in ref or cls in M13_CLASSES:
            continue
        hs, rs = _smooth(h), _smooth(ref[cls])
        ok = (hs >= N_MIN_BIN) & (rs > 0)
        cum = np.cumsum(h) / h.sum()
        i0 = int(np.searchsorted(cum, ONSET_Q))
        while i0 < NB and not ok[i0]:
            i0 += 1
        good = ok & (rc >= rc[min(i0, NB - 1)])
        if good.sum() < 2:
            continue
        r0 = float(rc[i0])
        w = np.full(NB, np.nan)
        w[ok] = -np.log((hs[ok] / h.sum()) / (rs[ok] / ref[cls].sum()))
        wd = np.interp(rc, rc[good], w[good], right=0.0)
        wd = np.clip(wd, -W_DATA_CLIP, W_DATA_CLIP) * _taper(rc, R_TAPER, R_HI)
        b, kappa = core_params(name, r0)
        tab = np.interp(grid, rc, wd)
        tab[grid >= R_HI - 1e-9] = 0.0
        core = grid < r0
        tab[core] = _core(grid[core], r0, float(wd[i0]), b, kappa)
        totals[f"{name}|{cls}"] = tab
        a_, b_ = name.split("_")
        out[f"Q6P:{(a_, b_, cls, '')!r}"] = dict(
            type="pmf", n=int(h.sum()), n_key=int(h.sum()), r0=round(r0, 3), core_b=round(b, 3),
            core_kappa=round(kappa, 3), r_lo=R_LO, dr=DR_TAB, w=[round(float(x), 4) for x in tab])
    for lab, h in hist.items():
        name, cls, ang = lab.split("|")
        base = totals.get(f"{name}|{cls}")
        if ang == "" or base is None:
            continue
        tot = hist[f"{name}|{cls}|"]
        pr = ANGLE_PRIOR[ang]
        f = (_smooth(h) + ANGLE_PSEUDO * pr) / (_smooth(tot) + ANGLE_PSEUDO)
        dlt = np.clip(-np.log(f / pr), -ANGLE_CLIP, ANGLE_CLIP)
        has = _smooth(tot) >= N_MIN_BIN
        if not has.any():
            continue
        first = int(np.argmax(has))
        dlt[:first] = dlt[first]
        dlt = dlt * _taper(rc, *ANGLE_TAPER)
        tab = base + np.interp(grid, rc, dlt)
        e0 = out[f"Q6P:{(name.split('_')[0], name.split('_')[1], cls, '')!r}"]
        a_, b_ = name.split("_")
        out[f"Q6P:{(a_, b_, cls, ang)!r}"] = dict(
            type="pmf", n=int(h.sum()), n_key=int(tot.sum()), r0=e0["r0"], core_b=e0["core_b"],
            core_kappa=e0["core_kappa"], r_lo=R_LO, dr=DR_TAB, w=[round(float(x), 4) for x in tab])
    return out


# ----------------------------------------------------------------------------------------------------------------
# runtime
# ----------------------------------------------------------------------------------------------------------------
def build_runtime(mol, ge, tables: Dict[tuple, dict], wall_mu, wall_sigma, device, metal13: bool = False):
    """Tensors for the scorer: one table row per Q6 pair (or the pair's wall when it has no table)."""
    import torch

    from jacobik.stats import key_builder as kb
    from jacobik.topology.graph import get_ligand_neighbors

    if not tables:
        return None
    atoms = list(mol.atoms)
    sep = ligand_separation(mol)
    all_nb = get_ligand_neighbors(mol.atoms, mol.bonds, mol.metal_idx)
    polar = kb.q6_polar_h(mol, all_nb)
    donor = polar_donor(mol, polar)
    pos = {a.idx: i for i, a in enumerate(atoms)}
    rows: List[List[float]] = []
    row_r0: List[float] = []  # each row's data onset (diagnostics: core vs data region)
    row_of: Dict[tuple, int] = {}

    def row(k):
        e = tables.get(k)
        if e is None:
            return -1
        if k not in row_of:
            row_of[k] = len(rows)
            rows.append(e["w"])
            row_r0.append(float(e.get("r0", R_LO)))
        return row_of[k]

    # pairs the extractor never records (raw M...X bond-order evidence) keep their wall, as before
    from jacobik.stats.mapping import raw_metal_bond_exclusion_pairs

    raw_m = raw_metal_bond_exclusion_pairs(mol.atoms, mol.bonds, mol.metal_idx, q6=True)
    a_idx = ge._q6_a.tolist()
    b_idx = ge._q6_b.tolist()
    t_tot, t_lin, t_bent, hb_h, hb_d, hb_a, is_hb = [], [], [], [], [], [], []
    rep = []  # (A, b, r_m, r_lin) of pairs with the physical repulsion (PMF_WELLS "repulsive"), else None
    rep_cls = ("5", "4") if REP_CLASS4 else ("5",)
    for p, (ia, ib) in enumerate(zip(a_idx, b_idx)):
        key = ge._q6_elem_keys[p]
        lo, hi = sorted((atoms[ia].idx, atoms[ib].idx))
        if (lo, hi) in raw_m:
            t_tot.append(-1); t_lin.append(0); t_bent.append(0)
            is_hb.append(False); hb_h.append(0); hb_d.append(0); hb_a.append(0); rep.append(None)
            continue
        cls = pair_class(atoms[ia].idx, atoms[ib].idx, mol.metal_idx, sep)
        polar_acc = "Hp" in key and (key[0] in kb.Q6_ACCEPTORS or key[1] in kb.Q6_ACCEPTORS)
        rep.append(rep_pair_params(key[0], key[1]) if PMF_WELLS == "repulsive" and cls in rep_cls and not polar_acc
                   else None)
        k_cls = (key[0], key[1], cls, "")
        k_any = (key[0], key[1], "5", "")
        tt = row(k_cls)
        if tt < 0:
            tt = row(k_any)
        lin = bent = -1
        h = d = acc = 0
        hb = False
        if "Hp" in key:
            h_at, acc_at = (ia, ib) if atoms[ia].idx in polar and atoms[ib].symbol in kb.Q6_ACCEPTORS else (ib, ia)
            dn = donor.get(atoms[h_at].idx)
            if dn is not None and dn in pos:
                lin = row((key[0], key[1], cls, "lin"))
                bent = row((key[0], key[1], cls, "bent"))
                if lin < 0 or bent < 0:
                    lin = row((key[0], key[1], "5", "lin"))
                    bent = row((key[0], key[1], "5", "bent"))
                if lin >= 0 and bent >= 0:
                    hb, h, d, acc = True, h_at, pos[dn], acc_at
        t_tot.append(tt); t_lin.append(max(lin, 0)); t_bent.append(max(bent, 0))
        is_hb.append(hb); hb_h.append(h); hb_d.append(d); hb_a.append(acc)
    # metal 1-3 pairs (not Q6 pairs of the extractor): their core-only table, own metal key else the pooled one
    m13_a, m13_b, m13_r = [], [], []
    for m_, x, c13 in (metal_13_pairs(mol) if metal13 else ()):
        if m_ not in pos or x not in pos:
            continue
        own, pooled = m13_keys(atoms[pos[m_]].symbol, atoms[pos[x]].symbol)
        r = row((own[0], own[1], c13, ""))
        if r < 0:
            r = row((pooled[0], pooled[1], c13, ""))
        if r >= 0:
            m13_a.append(pos[m_]); m13_b.append(pos[x]); m13_r.append(r)
    if not rows:
        return None
    T = torch.tensor(np.array(rows, dtype=np.float32), device=device)
    lt = lambda v: torch.tensor(v, dtype=torch.long, device=device)
    has = torch.tensor([x >= 0 for x in t_tot], dtype=torch.bool, device=device)
    hbm = torch.tensor(is_hb, dtype=torch.bool, device=device)
    hp = torch.tensor(["Hp" in k for k in ge._q6_elem_keys], dtype=torch.bool, device=device)
    rp = np.array([r if r is not None else (0.0, 1.0, 0.0, 0.0) for r in rep], dtype=np.float64)
    ft = lambda v: torch.tensor(v, dtype=torch.float32, device=device)
    return dict(T=T, hp=hp, tot=lt([max(x, 0) for x in t_tot]), lin=lt(t_lin), bent=lt(t_bent), has=has, hb=hbm,
                hb_any=bool(any(is_hb)), h=lt(hb_h), d=lt(hb_d), acc=lt(hb_a), r_lo=R_LO, dr=DR_TAB, G=T.shape[1],
                mu=wall_mu, sigma=wall_sigma, n_tables=len(rows), n_pairs_with_table=int(has.sum()),
                m13_a=lt(m13_a), m13_b=lt(m13_b), m13_rows=lt(m13_r), n_m13=len(m13_r),
                r0=torch.tensor(row_r0, dtype=torch.float32, device=device),
                rep=torch.tensor([r is not None for r in rep], dtype=torch.bool, device=device),
                rep_any=any(r is not None for r in rep), rep_A=ft(rp[:, 0]), rep_b=ft(rp[:, 1]), rep_rm=ft(rp[:, 2]),
                rep_rl=ft(rp[:, 3]))


def _interp(T, rows, d, r_lo, dr, G):
    """Piecewise-linear w at distances d (B, M) for table rows (M,): linear extrapolation below r_lo, 0 above."""
    import torch

    u = (d - r_lo) / dr
    i0 = torch.clamp(torch.floor(u.detach()), 0, G - 2).long()
    f = u - i0.to(u.dtype)
    w0 = T[rows[None, :], i0]
    w1 = T[rows[None, :], i0 + 1]
    w = w0 + f * (w1 - w0)
    return torch.where(u >= G - 1, torch.zeros_like(w), w)


def _taper_t(r, lo: float, hi: float):
    """cos^2 taper 1 -> 0 between lo and hi (torch)."""
    import torch

    x = ((r - lo) / (hi - lo)).clamp(0.0, 1.0)
    return torch.cos(0.5 * math.pi * x) ** 2


def evaluate(rt, X, a_idx, b_idx):
    """(B,) sum over Q6 pairs of w (kT): table pairs by interpolation (polar-H pairs mix their 'lin' / 'bent' tables by
    the D-H...A angle), pairs without a table by their wall (mu - d)^2 / 2 sigma^2."""
    import torch

    d = (X[:, a_idx] - X[:, b_idx]).norm(dim=-1)  # (B, M)
    contact = PMF_WELLS in ("contact", "repulsive")
    if contact:  # each pair's onset, and w there (angle-mixed below like w)
        r0 = rt["r0"][rt["tot"]][None].expand_as(d)
        w0 = _interp(rt["T"], rt["tot"], r0, rt["r_lo"], rt["dr"], rt["G"])
    w = _interp(rt["T"], rt["tot"], d, rt["r_lo"], rt["dr"], rt["G"])
    if rt["hb_any"]:
        H, Dn, A = X[:, rt["h"]], X[:, rt["d"]], X[:, rt["acc"]]
        u, v = Dn - H, A - H
        c = (u * v).sum(-1) / (u.norm(dim=-1) * v.norm(dim=-1)).clamp(min=1e-8)
        s = torch.sigmoid((ANGLE_SPLIT_COS - c) / 0.08)   # ~1 for D-H...A > 125 deg, ~0 below 115
        wl = _interp(rt["T"], rt["lin"], d, rt["r_lo"], rt["dr"], rt["G"])
        wb = _interp(rt["T"], rt["bent"], d, rt["r_lo"], rt["dr"], rt["G"])
        w = torch.where(rt["hb"][None], s * wl + (1 - s) * wb, w)
        if contact:
            w0l = _interp(rt["T"], rt["lin"], r0, rt["r_lo"], rt["dr"], rt["G"])
            w0b = _interp(rt["T"], rt["bent"], r0, rt["r_lo"], rt["dr"], rt["G"])
            w0 = torch.where(rt["hb"][None], s * w0l + (1 - s) * w0b, w0)
    if contact:
        # core below the onset for every pair (0 at and above it); polar-H...acceptor pairs also keep the attractive
        # part of the data curve, held at its onset value below r0 and tapered to 0 over HBOND_TAPER
        core = d < r0
        w_core = torch.where(core, (w - w0).clamp(min=0.0), torch.zeros_like(w))
        well = torch.where(core, w0, w).clamp(max=0.0) * _taper_t(d, *HBOND_TAPER)
        from jacobik.stats import nci as _nci

        if _nci.hbond_replacement_enabled():  # only an active hb component replaces these wells
            well = torch.zeros_like(well)
        w = w_core + torch.where(rt["hp"][None], well, torch.zeros_like(w))
    elif PMF_WELLS == "hbond":
        w = torch.where(rt["hp"][None], w, w.clamp(min=0.0))
    t = (rt["mu"] - d).clamp(min=0.0)
    wall = t ** 2 / (2.0 * rt["sigma"].clamp(min=1e-7) ** 2)
    w = torch.where(rt["has"][None], w, wall)
    if rt.get("rep_any"):  # physical repulsion replaces the core (and any wall) on its pairs
        u = rep_energy(d, rt["rep_A"][None], rt["rep_b"][None], rt["rep_rm"][None], rt["rep_rl"][None])
        w = torch.where(rt["rep"][None], u, w)
    tot = w.sum(-1)
    if rt.get("n_m13", 0):
        d13 = (X[:, rt["m13_a"]] - X[:, rt["m13_b"]]).norm(dim=-1)
        tot = tot + _interp(rt["T"], rt["m13_rows"], d13, rt["r_lo"], rt["dr"], rt["G"]).sum(-1)
    return tot
