"""
nci.py -- noncovalent interaction term "NCI" (plan 3 N2, 2026-10-17 c; profile field nci, default off).

Why. Q6 is repulsion only (q6pmf "repulsive": physical exchange repulsion, GFN2 parameters). The attractions that
physics cannot price cheaply are context- and direction-dependent, which crystal statistics can: this term prices
them, one term per candidate interaction (~0-50 per complex, not ~1500 atom pairs: a summed reference bias cannot
build up, the failure of every data-region Q6 PMF, CHANGELOG 10-16 f).

Types (admitted by the census tools/jdev/budget/nci_census.py, 10-17):
  "hb"   polar H (bonded to N, O, F) ... acceptor (N, O, F, S, Cl, Br, I): x = (H...A distance, D-H...A angle 0-180)
  "pp"   two sp2 5- / 6-rings: x = (centroid distance, angle between the ring planes 0-90)
  "chp"  non-polar H ... sp2 ring: x = (H...centroid distance, angle of centroid->H to the ring normal 0-90)
Only pairs more than 4 ligand bonds apart or without a ligand path (other ligands, through the metal; for rings every
ring atom): intra-ligand geometry up to 1-5 belongs to the bonded terms and the Q5 torsions.
H-bonds whose donor D and acceptor A are both metal-bound are excluded: their coordination geometry belongs to Q2.

Form. s(x) = ln g(x) * taper(r), g = crystal density / random placement (volume element r^2 sin(angle)), normalised
so that g = 1 in a shell just beyond the interaction range (SPEC "shell"): where crystals look random the term is 0,
and only the short-range, directional enrichment remains (polar groups clustering at 3-4.5 A is normalised away). A
pseudo-count shrinks sparse bins to g = 1; ln g is clipped to +-S_CLIP; the cos^2 taper takes s to 0 over SPEC "win".
Keys down a ladder (most specific with >= N_MIN pairs in range): hb (donor el, acceptor el) -> (*, acceptor el) ->
(*, *); pp and chp pooled ("*").

Data: refit/run_refit.py fit (2D histograms over the refit's training shards) -> "NCI:" entries in the refit DB.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np

NCI_ON = __import__("jacobik.profile", fromlist=["get"]).get("nci")  # profile field
TYPES = ("hb", "pp", "chp")
ACTIVE_TYPES = __import__("jacobik.profile", fromlist=["get"]).get("nci_types")  # profile field


def hbond_replacement_enabled():
    """Pi-only experiments retain the adopted Q6 polar-H attractions."""
    return NCI_ON and "hb" in ACTIVE_TYPES
#: per type: r grid (lo, hi, step A), angle grid (lo, hi, step deg), taper range (A), normalisation shell (A)
SPEC = {
    "hb": dict(r=(1.4, 3.6, 0.05), a=(0.0, 180.0, 5.0), win=(2.6, 3.0), shell=(3.0, 3.6)),
    "pp": dict(r=(3.0, 6.0, 0.1), a=(0.0, 90.0, 5.0), win=(4.5, 5.0), shell=(5.0, 6.0)),
    "chp": dict(r=(2.0, 4.2, 0.05), a=(0.0, 90.0, 5.0), win=(3.1, 3.5), shell=(3.5, 4.2)),
}
ACCEPTORS = frozenset({"N", "O", "F", "S", "Cl", "Br", "I"})
RING_ELEMENTS = frozenset({"C", "N", "O", "S", "B", "P"})
PSEUDO = 5.0
S_CLIP = 4.0
N_MIN = 1000


def _grid(t):
    s = SPEC[t]
    r_lo, r_hi, dr = s["r"]
    a_lo, a_hi, da = s["a"]
    return r_lo, dr, int(round((r_hi - r_lo) / dr)), a_lo, da, int(round((a_hi - a_lo) / da))


def _taper(r, lo, hi):
    return np.where(r <= lo, 1.0, np.where(r >= hi, 0.0, np.cos(0.5 * math.pi * (r - lo) / (hi - lo)) ** 2))


# ----------------------------------------------------------------------------------------------------------------
# topology: candidates (shared by extraction and runtime)
# ----------------------------------------------------------------------------------------------------------------
def sp2_rings(mol, nb) -> List[List[int]]:
    """5- / 6-rings of the ligand graph (metal excluded) whose atoms are ring elements with <= 3 ligand neighbours
    (H counted): aromatic and other sp2 rings, topology only (no geometry, so extraction and runtime agree). Atom
    indices in ring order."""
    sym = {a.idx: a.symbol for a in mol.atoms}
    ok = {a.idx for a in mol.atoms if a.idx != mol.metal_idx and sym[a.idx] in RING_ELEMENTS
          and len(nb.get(a.idx, ())) <= 3}
    seen, out = set(), []

    def walk(start, cur, path):
        for v in nb.get(cur, ()):
            if v == start and len(path) in (5, 6):
                key = frozenset(path)
                if key not in seen:
                    seen.add(key)
                    out.append(list(path))
            elif v in ok and v > start and v not in path and len(path) < 6:
                walk(start, v, path + [v])

    for s in sorted(ok):
        walk(s, s, [s])
    return out


def hbond_candidates(mol, nb=None, sep=None) -> list:
    """Topology-only (D, H, A, ladder) candidates, shared with the geometric census.

    Exclude co-bound D/A, including haptic face atoms, but retain outer-sphere
    contacts with just one metal-bound partner. Use primary coordination sites,
    not incidental raw metal contacts. Optional graphs avoid rebuilding them.
    """
    from jacobik.stats import key_builder as kb
    from jacobik.stats.q6pmf import ligand_separation
    from jacobik.topology.graph import donor_indices_of, get_ligand_neighbors

    if nb is None:
        nb = get_ligand_neighbors(mol.atoms, mol.bonds, mol.metal_idx)
    if sep is None:
        sep = ligand_separation(mol, max_depth=4)
    bound = set(donor_indices_of(mol))
    sym = {a.idx: a.symbol for a in mol.atoms}
    acc = [a.idx for a in mol.atoms if a.idx != mol.metal_idx and a.symbol in ACCEPTORS]
    out = []
    for h in sorted(kb.q6_polar_h(mol, nb)):
        d = nb[h][0]
        for a in acc:
            if a != d and a not in sep.get(h, {}) and not (d in bound and a in bound):
                out.append((d, h, a, [("hb", sym[d], sym[a]), ("hb", "*", sym[a]), ("hb", "*", "*")]))
    return out


def candidates(mol) -> Dict[str, list]:
    """{"hb": [(D, H, A, keys)], "pp": [(ring_i, ring_j, keys)], "chp": [(H, ring, keys)]}: atom indices (mol.atoms
    .idx), keys = the ladder from most specific to pooled."""
    from jacobik.stats import key_builder as kb
    from jacobik.stats.q6pmf import ligand_separation
    from jacobik.topology.graph import get_ligand_neighbors

    nb = get_ligand_neighbors(mol.atoms, mol.bonds, mol.metal_idx)
    sep = ligand_separation(mol, max_depth=4)
    m = mol.metal_idx
    # more than 4 ligand bonds apart, or no ligand path (other ligands, through the metal). NOT q6pmf.pair_class == "5":
    # that is "not exactly 4 apart" for pairs the Q6 exclusions have already removed, so it lets 1-2 / 1-3 pairs in
    # (first fit, 10-17: N-H...N peaks at 40 deg = the H...N of an N-N bond)
    far = lambda i, j: j not in sep.get(i, {})
    sym = {a.idx: a.symbol for a in mol.atoms}
    lig = [a.idx for a in mol.atoms if a.idx != m]
    polar = kb.q6_polar_h(mol, nb)
    out: Dict[str, list] = {t: [] for t in TYPES}
    out["hb"] = hbond_candidates(mol, nb, sep)
    rings = sp2_rings(mol, nb)
    for i in range(len(rings)):
        for j in range(i + 1, len(rings)):
            ri, rj = rings[i], rings[j]
            if not set(ri) & set(rj) and all(far(u, v) for u in ri for v in rj):
                out["pp"].append((ri, rj, [("pp", "*")]))
    for ring in rings:
        near = set(ring) | {x for u in ring for x in nb.get(u, ())}
        for h in lig:
            if sym[h] == "H" and h not in polar and h not in near and all(far(h, u) for u in ring):
                out["chp"].append((h, ring, [("chp", "*")]))
    return out


# ----------------------------------------------------------------------------------------------------------------
# features (torch; extraction uses them at B = 1)
# ----------------------------------------------------------------------------------------------------------------
def _ring_frame(X, rings):
    """Centroids (B, R, 3) and unit normals (B, R, 3) of rings given as an index tensor (R, 6) padded with -1 (5-rings);
    normal = normalised sum of consecutive cross products about the centroid (smooth, orientation-free)."""
    import torch

    valid = rings >= 0
    idx = rings.clamp(min=0)
    P = X[:, idx]                                                  # (B, R, 6, 3)
    w = valid.to(X.dtype)[None, :, :, None]
    c = (P * w).sum(2) / w.sum(2)
    Q = (P - c[:, :, None]) * w
    n_at = valid.sum(1)                                            # ring sizes
    nxt = torch.stack([torch.roll(torch.arange(6, device=X.device), -1)] * len(rings))
    nxt = torch.where(nxt >= n_at[:, None], torch.zeros_like(nxt), nxt)   # 5-ring: atom 4 -> 0
    Qn = torch.gather(Q, 2, nxt[None, :, :, None].expand_as(Q))
    n = torch.cross(Q, Qn, dim=-1).sum(2)
    return c, n / n.norm(dim=-1, keepdim=True).clamp(min=1e-9)


def _deg_acos(c):
    import torch

    return torch.rad2deg(torch.acos(c.clamp(-1.0 + 1e-6, 1.0 - 1e-6)))


def features(rt_type: str, X, idx: dict):
    """(r, angle) (B, M) of one type's candidates; idx: index tensors (positions in X) built by index_tensors."""
    if rt_type == "hb":
        H, D, A = X[:, idx["h"]], X[:, idx["d"]], X[:, idx["a"]]
        u, v = D - H, A - H
        r = v.norm(dim=-1)
        return r, _deg_acos((u * v).sum(-1) / (u.norm(dim=-1) * r).clamp(min=1e-9))
    c, n = _ring_frame(X, idx["rings"])
    if rt_type == "pp":
        ci, cj, ni, nj = c[:, idx["ri"]], c[:, idx["rj"]], n[:, idx["ri"]], n[:, idx["rj"]]
        return (ci - cj).norm(dim=-1), _deg_acos((ni * nj).sum(-1).abs())
    Hh = X[:, idx["h"]]
    v = Hh - c[:, idx["ring"]]
    r = v.norm(dim=-1)
    return r, _deg_acos(((v * n[:, idx["ring"]]).sum(-1)).abs() / r.clamp(min=1e-9))


def index_tensors(cands: Dict[str, list], pos: Dict[int, int], device, keep: Optional[Dict[str, list]] = None):
    """Per type: index tensors into X (positions pos[atom idx]); keep[t] = candidate indices to include (default all)."""
    import torch

    lt = lambda v: torch.tensor(v, dtype=torch.long, device=device)
    out = {}
    for t in TYPES:
        cs = cands[t] if keep is None else [cands[t][k] for k in keep[t]]
        if not cs:
            continue
        if t == "hb":
            out[t] = dict(d=lt([pos[c[0]] for c in cs]), h=lt([pos[c[1]] for c in cs]), a=lt([pos[c[2]] for c in cs]))
            continue
        rings, rid = [], {}

        def ring_id(r):
            k = tuple(r)
            if k not in rid:
                rid[k] = len(rings)
                rings.append([pos[u] for u in r] + [-1] * (6 - len(r)))
            return rid[k]

        if t == "pp":
            ri = [ring_id(c[0]) for c in cs]
            rj = [ring_id(c[1]) for c in cs]
            out[t] = dict(rings=lt(rings), ri=lt(ri), rj=lt(rj))
        else:
            rg = [ring_id(c[1]) for c in cs]
            out[t] = dict(rings=lt(rings), ring=lt(rg), h=lt([pos[c[0]] for c in cs]))
    return out


# ----------------------------------------------------------------------------------------------------------------
# extraction: 2D histograms
# ----------------------------------------------------------------------------------------------------------------
def records(mol):
    """{label "t|key": (r array, angle array)} of every candidate of a crystal within the type's r range; each
    candidate recorded under every ladder key."""
    import torch

    atoms = list(mol.atoms)
    pos = {a.idx: i for i, a in enumerate(atoms)}
    X = torch.tensor(np.array([a.position for a in atoms], dtype=np.float64))[None]
    cands = candidates(mol)
    idx = index_tensors(cands, pos, "cpu")
    out: Dict[str, Tuple[list, list]] = {}
    for t, ix in idx.items():
        r, a = features(t, X, ix)
        r, a = r[0].numpy(), a[0].numpy()
        lo, hi = SPEC[t]["r"][:2]
        for k in np.flatnonzero((r >= lo) & (r < hi)):
            for key in cands[t][k][-1]:
                lab = "|".join(str(x) for x in key)
                rr, aa = out.setdefault(lab, ([], []))
                rr.append(float(r[k]))
                aa.append(float(a[k]))
    return out


class HistAccumulator:
    """Per-label 2D histograms (SPEC grids), summed over complexes (weights: LnQM sibling shares)."""

    def __init__(self):
        self.h: Dict[str, np.ndarray] = {}

    def add(self, mol, weight: float = 1.0) -> None:
        for lab, (r, a) in records(mol).items():
            r_lo, dr, nr, a_lo, da, na = _grid(lab.split("|")[0])
            i = np.clip(((np.asarray(r) - r_lo) / dr).astype(int), 0, nr - 1)
            j = np.clip(((np.asarray(a) - a_lo) / da).astype(int), 0, na - 1)
            cnt = np.bincount(i * na + j, minlength=nr * na).reshape(nr, na) * float(weight)
            self.h[lab] = self.h.get(lab, 0) + cnt

    def save(self, path) -> None:
        np.savez_compressed(path, **{"h:" + k: v for k, v in self.h.items()})


def load_hist(paths) -> Dict[str, np.ndarray]:
    out: Dict[str, np.ndarray] = {}
    for p in paths:
        z = np.load(p)
        for k in z.files:
            if k.startswith("h:"):
                out[k[2:]] = out.get(k[2:], 0) + z[k]
    return out


# ----------------------------------------------------------------------------------------------------------------
# fit
# ----------------------------------------------------------------------------------------------------------------
def bin_volumes(t: str) -> np.ndarray:
    """Random-placement volume of each (r, angle) bin: (r_hi^3 - r_lo^3) / 3 x (cos a_lo - cos a_hi)."""
    r_lo, dr, nr, a_lo, da, na = _grid(t)
    re = r_lo + dr * np.arange(nr + 1)
    ae = np.radians(a_lo + da * np.arange(na + 1))
    return np.outer((re[1:] ** 3 - re[:-1] ** 3) / 3.0, np.cos(ae[:-1]) - np.cos(ae[1:]))


def fit_table(t: str, h: np.ndarray) -> dict:
    """s = ln g on bin centres (nr, na), tapered; g normalised to 1 over the shell."""
    r_lo, dr, nr, a_lo, da, na = _grid(t)
    rc = r_lo + dr * (np.arange(nr) + 0.5)
    vol = bin_volumes(t)
    k = np.ones((3, 3)) / 9.0
    from scipy.signal import convolve2d

    # counts AND random-placement volumes smoothed with the same kernel: their ratio stays exact for random data (the
    # volumes change fast near angle 0, where smoothing the counts alone made a +0.5 artefact)
    sm = lambda x: convolve2d(x, k, mode="same", boundary="symm")
    hs, vs = sm(h), sm(vol)
    shell = (rc >= SPEC[t]["shell"][0]) & (rc < SPEC[t]["shell"][1])
    rho = hs[shell].sum() / max(vs[shell].sum(), 1e-12)
    E = rho * vs
    s = np.clip(np.log((hs + PSEUDO) / (E + PSEUDO)), -S_CLIP, S_CLIP)
    s = s * _taper(rc, *SPEC[t]["win"])[:, None]
    return dict(type="nci", n=int(round(h.sum())), r_lo=r_lo, dr=dr, a_lo=a_lo, da=da,
                s=[[round(float(x), 4) for x in row] for row in s])


def fit_tables(hist: Dict[str, np.ndarray], n_min: int = N_MIN) -> Dict[str, dict]:
    out = {}
    for lab, h in hist.items():
        if h.sum() < n_min:
            continue
        key = tuple(lab.split("|"))
        out[f"NCI:{key!r}"] = fit_table(key[0], h)
    return out


# ----------------------------------------------------------------------------------------------------------------
# runtime
# ----------------------------------------------------------------------------------------------------------------
def build_runtime(mol, tables: Dict[tuple, dict], device, types=None):
    """Per type: table tensor (K, nr, na), each candidate's table row and its index tensors; None without any."""
    import torch

    if not tables:
        return None
    atoms = list(mol.atoms)
    pos = {a.idx: i for i, a in enumerate(atoms)}
    cands = candidates(mol)
    rt = {}
    enabled = ACTIVE_TYPES if types is None else tuple(types)
    if any(t not in TYPES for t in enabled):
        raise ValueError(f"unknown NCI types: {enabled}")
    for t in TYPES:
        if t not in enabled:
            continue
        rows, row_of, keep, cand_row = [], {}, [], []
        for k, c in enumerate(cands[t]):
            e = next(((key, tables[key]) for key in c[-1] if key in tables), None)
            if e is None:
                continue
            if e[0] not in row_of:
                row_of[e[0]] = len(rows)
                rows.append(e[1]["s"])
            keep.append(k)
            cand_row.append(row_of[e[0]])
        if not keep:
            continue
        r_lo, dr, nr, a_lo, da, na = _grid(t)
        rt[t] = dict(T=torch.tensor(np.array(rows, dtype=np.float32), device=device),
                     row=torch.tensor(cand_row, dtype=torch.long, device=device),
                     idx=index_tensors(cands, pos, device, keep={**{x: [] for x in TYPES}, t: keep})[t],
                     grid=(r_lo, dr, nr, a_lo, da, na), n=len(keep))
    return rt or None


def _bilinear(T, row, r, a, grid):
    """T (K, nr, na) on bin centres; r, a (B, M); clamped to the grid in angle, 0 beyond the r range."""
    import torch

    r_lo, dr, nr, a_lo, da, na = grid
    u = ((r - r_lo) / dr - 0.5).clamp(0.0, nr - 1.0)
    v = ((a - a_lo) / da - 0.5).clamp(0.0, na - 1.0)
    i0 = torch.floor(u.detach()).long().clamp(0, nr - 2)
    j0 = torch.floor(v.detach()).long().clamp(0, na - 2)
    fu, fv = u - i0.to(u.dtype), v - j0.to(v.dtype)
    rw = row[None].expand_as(i0)
    g = lambda i, j: T[rw, i, j]
    s = (g(i0, j0) * (1 - fu) * (1 - fv) + g(i0 + 1, j0) * fu * (1 - fv) + g(i0, j0 + 1) * (1 - fu) * fv
         + g(i0 + 1, j0 + 1) * fu * fv)
    return torch.where(r >= r_lo + dr * nr, torch.zeros_like(s), s)


def evaluate(rt, X):
    """(B,) sum over candidate interactions of s (nats; positive = favoured)."""
    tot = X.new_zeros(X.shape[0])
    for t, e in rt.items():
        r, a = features(t, X, e["idx"])
        tot = tot + _bilinear(e["T"], e["row"], r, a, e["grid"]).sum(-1)
    return tot
