"""Solve missing CPU seeds (seeds 12 and 13) for the 6 non-repeatability pilot parents.

Parents: DAFFEZ, JIXWEW, QOCKUO, RIGZUC, WIVVED, YUKLIA.
Outputs:
  data/refit/nci_v2/pilot_v1/pools/{code}_s{seed}.npz
  data/refit/nci_v2/pilot_v1/pools/{code}_s{seed}.mace64.json
  data/refit/nci_v2/pilot_v1/pools/{code}_s{seed}_run_a.json
"""
from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
import sys
import time

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "refit"))

from refit.nci_v2_pilot import run_worker_process, DEFAULT_POOLS_DIR, DEFAULT_FRAME

PARENTS = ["DAFFEZ", "JIXWEW", "QOCKUO", "RIGZUC", "WIVVED", "YUKLIA"]
SEEDS = [12, 13]


def main():
    frame = json.loads(DEFAULT_FRAME.read_text(encoding="utf-8"))
    parents_info = {p["code"]: p for p in frame["pilot_cohort"]["parents"]}

    tasks = []
    for code in PARENTS:
        p = parents_info[code]
        for seed in SEEDS:
            pool_out = DEFAULT_POOLS_DIR / f"{code}_s{seed}.npz"
            res_out = DEFAULT_POOLS_DIR / f"{code}_s{seed}_run_a.json"
            if pool_out.exists() and res_out.exists():
                print(f"Skipping {code} seed {seed}: already exists")
                continue
            tasks.append((code, p["shard"], p["dataset"], seed, pool_out, res_out))

    print(f"Total CPU tasks to run: {len(tasks)}")
    if not tasks:
        print("All CPU seeds already exist.")
        return

    t0 = time.perf_counter()

    def _run_one(t):
        c, sh, ds, s, p_out, r_out = t
        print(f"Starting {c} seed {s}...", flush=True)
        t_sub = time.perf_counter()
        res = run_worker_process(c, sh, ds, s, "run_a", p_out, r_out)
        dt = time.perf_counter() - t_sub
        print(f"Completed {c} seed {s} in {dt:.1f}s (status={res.get('status')})", flush=True)
        return c, s, res

    # Run sequentially or with small pool (worker processes use MACE on cuda which can serialize or run in parallel)
    # Using 2 parallel workers to avoid GPU contention for MACE eval
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        results = list(ex.map(_run_one, tasks))

    print(f"\nAll {len(results)} tasks completed in {time.perf_counter() - t0:.1f}s")


if __name__ == "__main__":
    main()
