   Implementation Plan: NCI Energetic Fitting & Separate Embedding Diagnosis

  ## Goal Description

  Establish a generalizable, physically constrained, and energetically calibrated noncovalent interaction (NCI) addition to the unified u1 scorer (S = [Q1 + Q2 + S_orient + Q5 + Q6 + bend_prior (+
  NCI)] / Z), while keeping ligand embedding diagnostics on a strictly separate track.

  Prior calibration work (2026-10-18_energy_calibration_v2 and 2026-10-18_training_calibration_v2) demonstrated that amplitude-only scalar rescaling of the current 2D histogram tables does not
  satisfy all advancement conditions:

  • H-bond (hb) replacement showed a modest positive local full-complex energy-response signal (validation RMSE 2.506 → 2.401 kJ/mol, CI [+0.010, +0.210]), but failed curvature bounds (median ratio
  1.615 ∉ [0.7, 1.5]), suffered from chemical/charge descriptor collisions (e.g., water/water vs. water/sulfonate sharing score 0.10885 nat despite ∼ 27 kJ/mol physical energy difference), and lost
  coverage when removing all Q6 polar-H wells (including co-bound contacts excluded from NCI).
  • Stacking (pp) showed useful fragment-probe signal but inconclusive full-complex validation transfer (CI [-0.00167, +0.00312]) and increased wrong-sign curvatures (3 → 14) when combined.
  • CH-π (chp) had its scalar coefficient zeroed by calibration and worsened 13/16 validation cases at unit weight due to missing C - H directionality and uncalibrated sibling-hydrogen summation.

  Following the owner's steering in NCI_CONTINUATION_PROMPT.md, our first deliverable is a concrete model/fitting specification and a small, reproducible ablation pilot (Steps 1–4, plus scoped
  design for Steps 5–6 and the separate Step 8 embedding check) that isolates:

  1. Table shape, interpolation smoothness, and baseline ownership (Step 1)
  2. Prospective energy-blind cohort expansion & frozen scaffold-disjoint split (Step 2)
  3. Parent/scaffold-balanced vs. ordinary density estimation at controlled support (Step 3)
  4. Smooth surface fitting with physically justified sharpness bounds vs. descriptor/counting changes (Step 4–6)

  No full-corpus 125k regeneration, fixed-pool gate, dev80 arm, or runtime default change will be launched until a component passes its independent local response, curvature, and ownership gates.
  ──────
  ## User Review Required

  │ Important
  │ Staged Execution & Stopping Conditions
  │ We will start with Phase 1 (Table/Ownership Audit + Representative Sampling Balance + Smooth Surface/Sharpness Pilot) using existing cached shard/reference data and a newly frozen, scaffold-
  │ disjoint training cohort (v3). We will not tune on 2026-10-18_training_calibration_v2 (whose validation split is now spent) or on named dev80 cases (PEWBOL, FETSUU, XEPKAF, JEFJUZ).

  │ Warning
  │ Baseline Ownership of Polar-H Contacts & Ionic Depth Gaps
  │ Enabling hb in src/jacobik/stats/q6pmf.py currently zeroes all Q6 hp attractive wells (well = torch.zeros_like(well)), even for pairs that hbond_candidates excludes (such as co-bound D/A pairs
  │ or acceptors without an eligible NCI table). Meanwhile, physical probes show a ∼ 27 kJ/mol gap between neutral and anionic acceptors (e.g., sulfonate) that includes long-range electrostatics
  │ outside the 2.6--3.0 \AA NCI taper.
  │ In Phase 1, we will explicitly audit:
  │
  │ 1. Whether Q6 polar-H well removal should be scoped strictly to NCI-eligible candidate pairs vs. all polar-H pairs, or how co-bound/uncovered pairs are priced by Q2/S_orient vs. Q6.
  │ 2. Whether coarse formal-charge / donor-acceptor subclassing in hb resolves short-range well depth differences without masquerading as a long-range electrostatic force field.
  ──────
  ## Concrete Model & Fitting Specification (First Deliverable)

  ### 1. Mathematical Separation of Width, Depth, and Thermal Compliance

  In src/jacobik/stats/nci.py, each table currently stores binned log-enrichment:

                ⎛      (K * H)(r, θ) + α            ⎞
  s(r, θ) = clip⎜ln ───────────────────────,  -4,  4⎟ · τ(r)
                ⎜   ρ     (K * V)(r, θ) + α         ⎟
                ⎝    shell                          ⎠

  evaluated at runtime via piecewise bilinear interpolation _bilinear.

  This has three structural flaws that our specification addresses:

  1. Discontinuous derivatives (C⁰ only): Bilinear interpolation over 0.05 \AA × 5° bins has first-derivative jumps across cell boundaries and zero within-cell pure second derivatives (∂²s/∂r² = 0),
  making finite-difference curvature step-size sensitive (0.02 vs 0.04 A) and introducing artificial kinks in solver gradients.
  2. Width–Amplitude Coupling: For a local potential well U(δ) ≈ -D exp(-δ²/2w²), the local stiffness at the minimum is k_{eff} = D/w², and the 1D thermal compliance width is σ_T = √(k_BT/k_{eff})
  = w√(k_BT/D). Unlike Q1 (where each component is a normalized 1D log-Gaussian -1/2 δ²/σ² whose curvature is directly 1/σ²), an NCI table's local curvature is:

  κ         (r, θ) = -k T∇²s(r, θ)
   surrogate           B

  Therefore, physical sharpness must bound the local negative Hessian of s(r, θ) (i.e. -∇²s ⪯ Σ_T⁻¹), rather than overwriting the spatial range w of a broad multimodal distribution with σ_T.
  3. Angular Endpoint Singularity: At θ → 180° (hb) or θ → 0° (pp, chp), the random-placement volume Jacobian sin θ vanishes and the first-order feature Jacobian ∇_Xθ becomes singular. Smooth
  surface fitting must operate in the natural cosine/projected coordinate (or enforce zero normal derivative ∂s/∂θ = 0 at θ ∈ {0°, 180°} with second-order angular compliance).

  ### 2. Error Taxonomy & Falsification Matrix

   Error Source                        │ Observable Diagnostic                │ Constrained By                       │ Proposed Mechanism (Isolated Ablation) │ Falsifier / Stopping Condition
  ─────────────────────────────────────┼──────────────────────────────────────┼──────────────────────────────────────┼────────────────────────────────────────┼──────────────────────────────────────
   Grid / Bilinear Kinks               │ Step-size curvature instability      │ Independent motion scans &           │ C² bicubic / penalized B-spline        │ Two-step curvature agreement does
                                       │ (0.02 vs 0.04 \AA) & derivative      │ analytical Hessian of interpolant    │ surface over (r, θ) with ∂_θs = 0 at   │ not improve or introduces overshoot
                                       │ jumps in n2_balance_audit_2026-10-   │                                      │ endpoints                              │ oscillations near taper
                                       │ 18.csv                               │                                      │                                        │
   Over-sharp Local Peaks              │ Curvature ratio < 0.7 or wrong-      │ 300-complex GFN2 Hessian compliance  │ Curvature-bounded smoothing (cap       │ Worsens probe radial regret or fails
                                       │ sign/spurious stiffness along        │ (C_T = kT J H+ J^T) + probe          │ maximum positive curvature of -∇²s by  │ to keep stable curvature ratio
                                       │ contact modes                        │ curvature                            │ compliance ceiling without broadening  │ within [0.7, 1.5]
                                       │                                      │                                      │ already-wide modes)                    │
   Repeated Scaffold / Parent Mixture  │ Peak shifts between raw, parent-     │ Multi-shard cleaned tmQM/LnQM sample │ Equal-parent and equal-scaffold-family │ Peak/shape shifts vanish on a
   Bias                                │ balanced, and scaffold-balanced      │ with Ln sibling weights & ESS        │ weighting with raw-count eligibility   │ broader representative sample or do
                                       │ tables                               │ tracking                             │ (N_{raw} ≥ 1000, N_{eff,parent} guard) │ not improve independent calibration
                                       │                                      │                                      │                                        │ response
   Missing Chemical / Directional      │ Probe collisions (hb neutral vs      │ Rigid dimer scans                    │ Coarse hierarchical keys (hb: formal   │ Fails to reduce probe collision
   Descriptors                         │ anionic ∼ 27 kJ/mol gap; chp C - H   │ (energy_calibration_v2) + new v3     │ charge/donor-acceptor class with       │ residuals or fails v3
                                       │ angle invariance)                    │ training calibration split           │ shrinkage toward element key; chp:     │ calibration/validation improvement
                                       │                                      │                                      │ cos(∠C-H ⋯ centroid) gating + per-     │ CI
                                       │                                      │                                      │ carbon/ring aggregation)               │
   Q6 Polar-H Ownership Gap            │ PEWBOL and hb cases losing score on  │ Partition of removed Q6 well energy  │ Explicit ownership rule: compare       │ Fails on v3 full-complex hb
                                       │ uncovered/co-bound polar-H pairs     │ into NCI_covered vs co_bound vs      │ removing Q6 wells only on pairs        │ calibration/validation curves
                                       │ when hb turns on                     │ other_uncovered                      │ eligible for NCI vs. retaining/re-     │
                                       │                                      │                                      │ pricing uncovered pairs                │
  ──────
  ## Proposed Changes & Phased Execution Plan

┌─────────────────────────────────────────────┐   ┌────────────────────────────────────────────────────────────────┐   ┌───────────────────────────────────────────────────────────────────────────┐   ┌───────────────┐   ┌────────────────────────────┐   ┌──────────────────────────────────────────────────────────────┐   ┌─────────────┐   ┌────────────────────────┐   ┌─────────────────────────────────────────────────────┐   ┌─────────────────────────────────────────────────┐
│                                             │   │                                                                │   │                                                                           │   │               │   │                            │   │                                                              │   │             │   │                        │   │                                                     │   │                                                 │
│                                             │   │                        Ownership Audit                         │   │                                                                           │   │               │   │                            │   │                                                              │   │             │   │                        │   │                                                     │   │                                                 │
│      S1["Step 1: Table Shape, Gradient      ├─┬─┤                                                                │   │                                     S1                                    ├─┐ │       S2      ├─┐ │             S3             ├─┐ │                              S5                              ├─┐ │ Gate -- Yes ├─┐ │       Gate -- No       ├─┐ │ S8["Step 8 (Separate Track): Narrow Cp-Only Release │   │         Anionic N-N Donor-Angle Check"]         │
│                                             │ │ │      (tools/jdev/budget/nci_surface_ownership_audit.py)"]      │   │                                                                           │ │ │               │ │ │                            │ │ │                                                              │ │ │             │ │ │                        │ │ │                                                     │   │                                                 │
│                                             │ │ │                                                                │   │                                                                           │ │ │               │ │ │                            │ │ │                                                              │ │ │             │ │ │                        │ │ │                                                     │   │                                                 │
└──────────────────────┬──────────────────────┘ │ └────────────────────────────────┬───────────────────────────────┘   └─────────────────────────────────────┬─────────────────────────────────────┘ │ └───────────────┘ │ └────────────────────────────┘ │ └──────────────────────────────────────────────────────────────┘ │ └─────────────┘ │ └────────────────────────┘ │ └─────────────────────────────────────────────────────┘   └─────────────────────────────────────────────────┘
                       │                        │                                  │                                                                         │                                       │                   │                                │                                                                  │                 │                            │
                       ▼────────────────────────┴──────────────────────────────────▼                                                                         ▼                                       └─────────▼         └────────────────▼───────────────┴─────────────────────────────────▼────────────────────────────────┴────────▼────────┴──────────────▼─────────────┴────────────────────────────▼───────────────────────────────────────────────────────▼─────────────────────────────────────▼───────────────────────────────────▼
┌─────────────────────────────────────────────┐   ┌────────────────────────────────────────────────────────────────┐   ┌───────────────────────────────────────────────────────────────────────────┐   ┌───────────────┐   ┌────────────────────────────┐   ┌──────────────────────────────────────────────────────────────┐   ┌─────────────┐   ┌────────────────────────┐   ┌─────────────────────────────────────────────────────┐   ┌─────────────────────────────────────────────────┐   ┌────────────────┐   ┌───────────────────────────────────────────────┐
│                                             │   │                                                                │   │                                                                           │   │               │   │                            │   │                                                              │   │             │   │                        │   │                                                     │   │                                                 │   │                │   │                                               │
│ S2["Step 2: Prospective Cohort v3 Selection │   │                                                                │   │             S3["Step 3: Representative Corpus Sampling Balance            │   │               │   │                            │   │                 Sharpness-Bounded Prototype                  │   │             │   │                        │   │                                                     │   │                                                 │   │                │   │ Return Concrete Representation/Coverage Limit │
│                                             │   │ Individual-Scaffold Disjoint, Expanded HB/Ln/Bound Coverage)"] │   │                                                                           │   │ Ln Weights)"] │   │ S4["Step 4: Smooth Surface │   │                                                              │ ┌─┤      S4     │   │ Gate{"Passes All Local │   │               Validation v3 Checks?"}               │   │ PoolGate["Step 7: Fixed-Pool Gate (etkdg_u1_os) │   │ Power Review"] │   │                                               │
│                   (Parent                   │   │                                                                │   │               (Ordinary vs Parent vs Scaffold Balance + ESS               │   │               │   │                            │   │ (C2 Interpolation + Curvature Ceiling + Endpoint Boundary)"] │ │ │             │   │                        │   │                                                     │   │                                                 │   │                │   │         (Keep NCI Off, Do Not Run Arm)        │
│                                             │   │                                                                │   │                                                                           │   │               │   │                            │   │                                                              │ │ │             │   │                        │   │                                                     │   │                                                 │   │                │   │                                               │
└─────────────────────────────────────────────┘   └────────────────────────────────────────────────────────────────┘   └───────────────────────────────────────────────────────────────────────────┘   └───────────────┘   └────────────────────────────┘   └──────────────────────────────────────────────────────────────┘ │ └──────┬──────┘   └────────────────────────┘   └─────────────────────────────────────────────────────┘   └─────────────────────────────────────────────────┘   └────────────────┘   └───────────────────────────────────────────────┘
                                                                                                                                                                                                                                                                                                                             │        │
                       ▼───────────────────────────────────────────────────────────▼─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘        │
┌─────────────────────────────────────────────┐   ┌────────────────────────────────────────────────────────────────┐   ┌───────────────────────────────────────────────────────────────────────────┐                                                                                                                                  │
│                                             │   │                                                                │   │                                                                           │                                                                                                                                  │
│                                             │   │                                                                │   │                           Amplitude Calibration                           │                                                                                                                                  │
│                  S5["Step 5                 │   │                6: Coarse Descriptor / Counting                 │   │                                                                           │◄─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
│                                             │   │                                                                │   │ (Evaluated Strictly on Calibration v3, Validated Once on Validation v3)"] │
│                                             │   │                                                                │   │                                                                           │
└─────────────────────────────────────────────┘   └────────────────────────────────────────────────────────────────┘   └───────────────────────────────────────────────────────────────────────────┘

  ### Phase 1: Immediate Start — Audit, Sampling Balance, and Smooth Surface Pilot (Steps 1, 3, 4)

  #### [NEW] nci_surface_ownership_audit.py

  • Purpose (Step 1 & Step 4 prototype):
      1. Audit all 13 candidate NCI tables in data/refit/nci/2026-10-18_bound_fix/constraints_nci_2026-10-18.json and compare them against the replaced Q6 polar-H lin/bent wells (Q6P:('Hp', A, '5',
      'lin'|'bent')).
      2. Quantify peak locations, well depths (in nats and kJ/mol), radial and angular widths, bilinear derivative jumps across bin edges, and finite-difference curvature instability (h = 0.02 \AA
      vs 0.04 \AA).
      3. Prototype a C²-continuous surface representation (natural bicubic spline / penalized smooth log-density ratio preserving the exact geometric background V(r, θ) and ∂_θs = 0 at 0°, 180°)
      with an explicit upper bound on local stiffness derived from the thermal compliance audit (n2_thermal_audit_2026-10-18), without flattening broader empirical modes.
      4. Evaluate the width/smoothness-only prototype on the existing frozen 2026-10-18_energy_calibration_v2 rigid physical probes (no new quantum calculations required) to verify continuous
      forces, two-step curvature stability, and well depths.

  ──────
  ### Phase 2: Representative Corpus Balance & Expanded Disjoint Cohort v3 (Steps 2 & 3)

  #### [NEW] nci_corpus_balance_pilot.py

  • Purpose (Step 3):
      • Test whether the peak shifts seen in the 300-complex cohort (n2_density_balance_2026-10-18) survive on a broader, representative multi-shard sample (e.g., hash-sampled across all 34 cleaned
      tmQM and LnQM shards, preserving canonical benchmark exclusions and LnQM sibling weights).
      • Compare ordinary, equal-parent, and equal-scaffold-family histogram estimates at controlled support, reporting raw counts, effective sample size (N_{eff} = (∑ wᵢ)²/ ∑ wᵢ²), bootstrap
      uncertainty of peak position/depth, and co-bound ring-face sensitivity (pp with 0, 1, or 2 metal-bound faces) without inflating weighted counts to pass N_MIN = 1000.


  #### [NEW] nci_training_calibration_v3.py

  • Purpose (Step 2):
      • Because 2026-10-18_training_calibration_v2 validation was already used to reject the scalar fit, construct a new, prospectively frozen v3 cohort (data/refit/nci/2026-10-
      18_training_calibration_v3/) before any v3 model selection.
      • Expand energy-blind selection to ensure stratified coverage of:
          • hb chemical/charge contexts (neutral donor/neutral acceptor, neutral/anionic acceptor, cationic/neutral, one-bound-partner vs. outer-sphere) derived strictly from query-available ligand
          topology/formal charge.
          • pp and chp bound-face vs. unbound-face contexts and lanthanide (LNf) complexes where supported.
      • Enforce the strict connected-component graph split where every parent complex AND every individual participating ligand Murcko scaffold is restricted to a single split (calibration vs
      validation) across all interaction types.

  ──────
  ### Phase 3: Coarse Hierarchical Descriptors & Joint Calibration Ablations (Steps 5 & 6)

  #### [NEW] nci_ablation_pilot.py

  • Purpose (Steps 5 & 6):
      • Run controlled, separable ablations on the physical probes and v3 calibration split (holding v3 validation locked until the candidate specification is frozen):
          1. Ablation A (Smoothness + Curvature Floor only): C² interpolation + physical sharpness cap on existing keys.
          2. Ablation B (Sampling Balance only): Parent/scaffold-balanced tables vs. ordinary tables at matched support.
          3. Ablation C (Ownership & Coarse Descriptors):
              • hb: Query-topology formal-charge / acceptor-hybridization coarse hierarchy with empirical-Bayes shrinkage toward the parent element table ((hb, D_el, A_el, charge_class) -> (hb,
              D_el, A_el) -> (hb, *, A_el)), plus explicit test of Q6 polar-H well retention on pairs excluded from NCI (co_bound / uncovered).
              • chp: Include C - H ⋯ centroid orientation factor (φ = ∠(C - H, H → centroid)) in extraction & runtime, and compare carbon-centered group aggregation (e.g. smooth log-sum-exp / per-
              carbon-ring count normalization) against raw H-summation.
              • pp: Test radial/parallel-plane vs. lateral-slip separation and bound-face context pooling.
          4. Ablation D (Combined Calibrated Candidate): Calibrate amplitude/depth on v3 calibration contact-opening curves jointly with total Q6 + NCI slopes and curvature.


  ──────
  ### Phase 4: Separate Embedding Validation Track (Step 8)

  #### [NEW] nci_embedding_cp_validation.py

  • Purpose (Step 8):
      • Keep embedding experiments 100% separate from NCI comparisons.
      • Expand the narrow Cp-only intra-face restraint release check (which improved both bond and donor-angle RMS on 8/8 successful independent Cp/substituted-Cp ligands while general arene
      release worsened 6/8) to verify:
          1. Why the 9th selected Cp-family case failed strict xTB gradient convergence and how strict fallback/guarding behaves.
          2. Whether narrow Cp-only release preserves all existing eta2, group-13 bound_surrogate, and aromaticity protections across a broader independent training sample.
          3. For the 8 unique both-primary anionic N - N ligands (7 scaffolds) identified in the census, test whether any ligand-only bound-state restraint can preserve both heavy-bond lengths and
          donor angles (since blanket cap retention worsened donor angles 4.42°--5.33° vs 1.76°--2.03°).


  ──────
  ## Verification Plan

  ### Automated & Reproducible Verification

  All commands will be run from E:\Dev\Projects\jacobik_2026-10-02_full in PowerShell with JACOBIK_PROFILE=u1, MKL_THREADING_LAYER=SEQUENTIAL, and OMP_NUM_THREADS=1, respecting the single-GPU /
  max-2-CPU-job limits and keeping data/refit/final/constraints_2026-10-17.json and data/refit/nci/2026-10-18_bound_fix/constraints_nci_2026-10-18.json untouched:

  1. Step 1 & 4 Surface/Ownership Audit & Physical-Probe Check (CPU only, fast):
    $env:JACOBIK_PROFILE="u1"; $env:MKL_THREADING_LAYER="SEQUENTIAL"; $env:OMP_NUM_THREADS="1"
    pixi run python tools/jdev/budget/nci_surface_ownership_audit.py

  2. Step 3 Multi-Shard Representative Sampling Balance Pilot (CPU, <=2 workers):
    $env:JACOBIK_PROFILE="u1"; $env:MKL_THREADING_LAYER="SEQUENTIAL"; $env:OMP_NUM_THREADS="1"
    pixi run python tools/jdev/budget/nci_corpus_balance_pilot.py

  3. Focused Unit Tests for Surface Interpolation, Analytical Gradients/Curvature, and Ownership Invariants:
    $env:JACOBIK_PROFILE="u1"; $env:MKL_THREADING_LAYER="SEQUENTIAL"; $env:OMP_NUM_THREADS="1"
    pixi run pytest tests/ -k "nci" -q


  ### Advancement Gate Criteria (Before Any Full Refit or dev80 Arm)

  A component (hb, pp, or chp) will only advance to the fixed-pool gate (gate.py on etkdg_u1_os) if all of the following hold on independent data:

  • Continuous first derivatives and two-step stable curvature (0.02 vs 0.04 \AA agreement).
  • Median curvature ratio within [0.7, 1.5] and no increase in wrong-sign stable curvatures.
  • Strictly positive 95% bootstrap CI on v3 validation relative-energy RMSE improvement and non-worsening sampled-minimum regret.
  • If a component fails these independent checks, we stop that component and report the representation/coverage limit rather than tuning weights on dev80.