# Continuation prompt: NCI energetic fitting and separate embedding diagnosis

Continue work in `E:\Dev\Projects\jacobik_2026-10-02_full`. Read this entire prompt
before changing the model. It summarizes the owner's goals, completed research,
limits and next experiments. The objective is a generalizable, confidently
positive NCI addition to the unified scorer, with a defensible energetic scale.
It is not to improve a few named benchmark cases by tuning their weights.

## Owner's intent and scope

Architecture/handoff tasks 1 and 2 were completed. Task N2 introduced NCI but
often worsened selected structures' physical energies. Diagnose and address
the model, fitting, counting and score balance; retain the structural training
data as the empirical basis. Independent physics should constrain unrealistic
sharpness and establish energetic compatibility, as thermal floors did for Q1.
Do not replace the data with an ad hoc force field or arbitrary multipliers.

Widths AND amplitudes matter. The owner specifically proposes reducing the
influence of repeated environments and physically constraining fitting
strictness by interaction family. Treat these as testable hypotheses. A wide,
representative corpus may average incidental effects; full-corpus coordination
bias has not been established. Do not assume it or exclude bound rings merely
because a conditional correlation could exist.

The first approved conditional calibration investigation is complete. No
component passed every advancement condition. NCI remains off. Continue with
small, isolated, reviewable fitting experiments grounded in the evidence below.
Do not automatically launch another full-corpus refit, dev80 arm or held-out
test. Advance a supported component through the fixed-pool gate and power
review before a single benchmark arm. Keep embeddings unchanged in NCI
comparisons. Embedding work is a separate track.

## Read first

1. `HANDOFF.md`: newest section supersedes historical instructions below it.
2. `ARCHITECTURE.md`: sections 4.9 (thermal widths), profile fields, energetic
   balance/curvature methodology, and 11.2 (NCI).
3. `CHANGELOG.md`: newest implementation results and earlier predictions.
4. `data/refit/reports/n2_calibration_implementation_2026-10-18.md`: detailed
   current report, with adjacent JSON, SHA256 manifest and figures.
5. `data/refit/reports/n2_followup_2026-10-18.md`: earlier fresh solves,
   case-specific diagnosis, score balance and embedding experiments.

Runtime defaults and both DBs were preserved during the calibration work.
Default DB: `data/refit/final/constraints_2026-10-17.json`.
Isolated NCI candidate:
`data/refit/nci/2026-10-18_bound_fix/constraints_nci_2026-10-18.json`.
Its 445,851 non-NCI entries match the base; it contains 13 NCI tables.
Original DB hashes are in that directory's `fit_summary.json`.

## Current model and implemented fixes

`src/jacobik/stats/nci.py` fits 2D reference-contact histograms from 125,622
nonbenchmark cleaned tmQM/LnQM structures, with existing LnQM sibling weights.
It fits structural enrichment, NOT energy/force/Hessian labels:

`s = log((smoothed observed counts + 5)/(background expected counts + 5))`

The background includes the random-placement volume/Jacobian and is normalized
in a distant shell. Counts and background get the same 3x3 smoothing; score is
clipped to +/-4 nats and distance-tapered. The 1,000-observation threshold and
fallback ladder determine table eligibility. Correcting a density's amplitude
or width cannot recover information absent from its descriptors.

Current specificity:

- `hb`: H...A distance and D-H...A angle; donor/acceptor ELEMENT keys with pooled
  fallbacks. No resolved charge/chemical environment or acceptor orientation.
- `pp`: ring-centroid distance and plane angle; one pooled table. No explicit
  slip, ring chemistry/charge or bound-face context.
- `chp`: H...ring-centroid distance and approach relative to the ring normal;
  one pooled table. No C-H direction or carbon-centered sibling counting.

Earlier shared eligibility fix excludes H-bonds where D and A are BOTH primary
metal donors, including haptic face atoms. It preserves one-bound-partner and
outer-sphere contacts and the >4-ligand-bond rule. Extraction/runtime/census
share this rule. Full-corpus regeneration already completed; do not rerun it
without a changed, justified fitting hypothesis.

New component control: profile `nci_types` accepts unique `hb`, `pp`, `chp`, in
canonical order. `nci=True` with pi-only components preserves Q6 polar-H wells.
Only enabled hb replacement removes those wells. Defaults/all-types behavior
are preserved. Extraction candidates are independent of activation selection.
Do not reintroduce pi-only well removal or add hb on top of old wells as a
deployable candidate; that double-counts. Unsupported-class fallback/ownership
needs an explicit validated design, not incidental changes to eligibility.

u1 has one summed solve/ranking objective, thermal scoring floors and common
per-complex normalization Z. Use raw nats (undo Z) when measuring energetic
scale; `E_surrogate = -2.479 * S_raw` kJ/mol is the current 298 K comparison.
One nat is not automatically one physical kT simply because terms are summed.
Pooled median curvature does not certify well depths, multiplicity, forces or
between-conformer energy/score agreement.

## Completed evidence

### Independent physical probes

Use `data/refit/nci/2026-10-18_energy_calibration_v2/` ONLY. It contains frozen
manifests, monomer geometries, raw grids, MACE64/GFN2 energies,
`probe_analysis.json`, `probe_curves.csv`, and `chp_mechanism.json`.

All 1,008 rigid-pair geometries completed with MACE float64 and strict GFN2:
nine H-bond pairs, two stacking pairs, two CH-pi pairs, distance/orientation
scans. Interaction energy is E_AB-E_A-E_B at fixed geometries and defined
fragment charges. Rigid internal distances passed <1e-8 A checks.

At H...A 2 A / D-H...A 180 degrees:

- water/water: MACE -18.12, GFN2 -17.05 kJ/mol;
- water/acetone: -19.21 / -17.21;
- water/sulfonate: -45.39 / -44.47.

All three get exactly the same current hb score (0.10885 nat) and Q6-core
energy. Aniline/water versus aniline/sulfonate similarly share a score (0.39910)
but have physical energies around -15 versus -48 to -50 kJ/mol. This demonstrates
missing distinctions in the combined current model. It does NOT establish that
all ionic attraction should be assigned to a local H-bond: long-range
electrostatics is present in physical energies and absent from the short taper.
The old wells also lack this chemical specificity. Per-probe oracle scalars
vary and leave large residuals; none was adopted.

Neutral stacking has useful fragment-level signal. CH-pi ethane/benzene curve
RMSE worsens 5.44 -> 6.55 kJ/mol MACE and 5.94 -> 8.91 GFN2. A post-hoc
C-H-direction plus per-carbon/ring sibling-max ablation reduces these to 5.01
and 5.60. Methane and radial-regret results are mixed. This is mechanism
evidence, not a universally correct aggregation rule or refitted candidate.

### Scaffold-disjoint full-complex response

Use `data/refit/nci/2026-10-18_training_calibration_v2/` ONLY: 32 distinct
complexes/type, split 16 calibration + 16 validation; 96 contact cases, 80 unique
parents, 4,328 poses. Each individual participating Murcko scaffold AND parent
is restricted to one split across all types. Stable-hash/topology/geometry
selection, all canonical benchmark exclusions, no energy selection. Up to six
contact-changing rigid/torsional motions per case, +/-0.02 to +/-0.16 A tangent
norm. Reference statistical keys are fixed; solver assignment coverage and
bend/closure priors are not reconstructed. No Ln or bound-face stacking cases
were selected: these contexts remain unvalidated.

Equal-case, calibration-only nonnegative scalar fits:

| Component | Coefficient | Validation RMSE off -> fitted | Mean improvement CI95 |
|---|---:|---:|---:|
| hb replacement | 0.2325 | 2.506 -> 2.401 kJ/mol | +0.010 to +0.210 |
| pp only | 0.1113 | 0.6504 -> 0.6496 | -0.00167 to +0.00312 |
| chp only | 0 | 0.6992 unchanged | zero |

HB has modest positive local evidence, including at unit scale. Its fitted
median curvature ratio is 1.615, outside the frozen 0.7-1.5 band, and descriptor
collisions remain. Unit CH-pi worsens 13/16 cases and adds wrong-sign curvatures
(1 -> 4). Unit stacking is mixed. Full all-on scoring of stacking cases changes
wrong-sign curvatures 3 -> 14 despite a favorable median ratio. Analysis also
records response Spearman correlation, energy per nat and sampled-minimum
regret. Local motions are not a benchmark of generated conformers.

Important correction: the first `2026-10-18_training_calibration/` split only
separated contact-scaffold PAIRS and leaked five individual cores. It is marked
`VALIDATION_INVALID.json`; its analysis is exploratory. The corrected v2 selector
connects each scaffold separately. Sixteen identical raw measurements were
reused with explicit provenance; 80 cases newly measured. Old fits were
discarded. Do not tune to the now-visible v2 validation set; new model choices
need a fresh independent validation cohort or a prospectively fixed design.
The initial non-v2 physical-probe directory also failed before measurement.

### Thermal compliance and sampling balance

`data/refit/reports/n2_thermal_audit_2026-10-18/` reuses Q1's original independent
300-complex GFN2 Hessian cohort. Native NCI feature Jacobians give
`C_T = kT J H+ J^T`; radial/angular covariance and context are retained.

| Type | Contacts / independent parents | Median radial SD | Angular SD |
|---|---:|---:|---:|
| hb | 40 / 15 | 0.191 A | 14.57 deg |
| pp | 63 / 41 | 0.262 A | 10.21 deg |
| chp | 289 / 126 | 0.351 A | 8.94 deg |

Negative-mode exclusion sensitivity is small. Cached Hessians inherit historical
provenance without per-file original geometry hashes; dimensions/native input
order were checked. These are full-complex compliance widths, including
coordination/network effects. Do not transplant them as additional isolated
springs. Exactly linear/parallel angular features require second-order treatment
when their first-order Jacobians vanish. HB has too few parents for detailed
chemical subclasses. No NCI floors have been installed.

`data/refit/reports/n2_density_balance_2026-10-18/` compares ordinary,
equal-parent and equal-scaffold-family pooled fits on the same 300-complex
cohort, with identical geometric background treatment. Weighted mass was matched
ONLY to isolate shape from pseudocount shrinkage; effective independent parents
are reported separately. This does not make sparse fits eligible for adoption.
HB peak shifts from 1.975 A/142.5 deg to 1.775/167.5; pp from 4.55/67.5 to
3.55/17.5 under scaffold balance. Changes are modest (~0.12 nat maximum).
This establishes sensitivity in a small cohort, not full-corpus bias or energy
benefit. Sixteen fitting-range pp pairs have both faces bound; removing them
changes the table but does not prove their physical interaction is spurious.

## Named cases and separate embedding findings

The original user inspected `data/inspect/nci_force_viewer.html`: seven cases,
three seeds, offline reference/before/after geometry, forces, motion and energy
curves. It passed all 21 browser combinations. Global model-energy terms are
kept separate; forces do not imply a unique per-atom energy attribution.

- XEPKAF recovers a phenyl stack but can worsen total energy. Its Cp ring IS
  directly eligible for current NCI. Before/after covalent lengths are nearly
  unchanged (<2.25e-6 A); NCI cannot repair frozen ligand internals.
- PEWBOL struggles with trans/anti versus syn sulfonate conformers. Pinning the
  reference donor assignment does not enforce anti sulfonates. Old H-bond well
  removal matters, but coverage-only replacement ablations did not solve it.
- JEFJUZ compressed C-N/N-N and uneven Cp lengths reproduce in production
  embeddings. Evidence points to an embedding/constraint problem, not a simple
  corrupted-reference explanation. GFN2 restrains donor-pair distances to MMFF
  starts; caps are removed before bare-anion refinement.
- FETSUU has CH-pi reward/counting problems. Simple half-space or sibling-max
  ablations did not resolve its selected-pool loss.

Earlier 69 full-solve pools are complete, with exact ranking re-evaluation.
Fresh NCI-on minus off mean picked energies (kJ/mol): XEPKAF +10.59, PEWBOL
+87.54, JEFJUZ -23.85, FETSUU +26.78, BULGAT -0.15, CBTYCO -8.70, YIYXEJ
+39.29. Selected cohort, not dev80. PEWBOL s11 off-control differs from stored
by +89.13: do not mix stored/fresh controls or claim deterministic effect sizes.

`data/refit/reports/n2_embedding_validation_2026-10-18/` holds common-start
factorials and generality/census checks. JEF caps improve heavy-bond RMS but
worsen donor angles: bare keep-pairs 0.03319 A/2.03 deg; capped keep
0.01623/5.33; bare release bonded pairs 0.03066/1.76; capped release
0.00864/4.42. Earlier broad cap screen likewise failed (angles 4 better/12 worse
of 16). Historical archive reports cap regressions too. Do NOT retain all caps.

Cp-only intra-face restraint release improves bond/angle RMS for all eight
successful independently selected Cp/substituted-Cp ligands. Broad arene release
worsens bonds in six/eight. One selected xTB failure was recorded, not replaced.
Cp-only release is promising, not adopted. Preserve eta2, aromaticity, group-13
and other existing cap protections.

Broader CSV + mapped-topology census finds eight unique both-primary anionic
N-N ligands/seven scaffolds (11 occurrences), with 11 mapping/size failures.
LnQM has no supplied SMILES and cannot be ruled out. Earlier sample zero was
coverage, not absence. Do not add a JEFJUZ-specific N-N rule.

## How to approach a solution from data

Keep structural data central. It informs supported contact geometries,
multimodality, chemical variation and coverage/fallback. It does not guarantee
that log enrichment in optimized reference structures has a literal Boltzmann
well depth. Physical measurements constrain and calibrate the model; they need
not replace the structural density wholesale.

Widths and amplitudes are coupled. For an illustrative Gaussian-shaped
attraction `U=-D exp(-delta^2/(2w^2))`, local stiffness is `D/w^2` and the
one-dimensional thermal SD is `sqrt(kT*w^2/D)`. Thus setting a shape width to a
measured thermal SD is generally wrong when depth is free. Q1's local
log-Gaussian curvature has a simpler width relationship. Decide what NCI's
width parameter actually means before transferring Q1's floor prescription.

Separate the observables: data-supported modes/shape, physical upper bounds on
sharpness, contact formation/separation depth, force directions, multiplicity
and compatibility with other score terms. A global coefficient changes several
of these together; it was a falsification diagnostic, not the final fitting
strategy. Existing isolated-probe versus full-complex scalar results disagree,
so no trustworthy final amplitude is established yet.

Recommended next steps, with explicit ablations and stopping conditions:

1. Audit current table shapes/gradients and baseline ownership. Distinguish
   insufficient depth, wrong minimum, narrow features, spline/grid artifacts,
   missing descriptors and double-counted contributions. No assumption that all
   wells need broadening. Bilinear interpolation has derivative jumps; smoothing
   counts alone does not make runtime forces continuous.
2. Expand energy-blind independent HB chemical/charge coverage and bound-face/Ln
   coverage where supported. Freeze new parent AND individual-scaffold-disjoint
   calibration/validation before model selection; existing validation is spent.
   Choose class splits from query-available chemical topology, not CSD labels,
   reference outcomes or target coordinates. Use shared extraction/runtime code.
3. Compare ordinary and parent/scaffold-balanced estimates at controlled support,
   with uncertainty/effective sample sizes and existing Ln sibling weights.
   Do not inflate weighted counts to satisfy table eligibility. Establish whether
   observed shifts survive broader representative data before a full refit.
4. Prototype a data-fitted smooth density/surface with physically justified
   bounds on local sharpness and radial-angular coupling. Compare a width-only
   correction separately from balancing and descriptor changes. Preserve the
   geometric background/Jacobian correction. Broader supported modes need not
   be overwritten by a common thermal width. Handle angular endpoints properly.
5. Address demonstrably missing distinctions using coarse hierarchical/partially
   pooled classes: HB chemistry/charge/acceptor direction, CH-pi C-H direction
   and carbon-centered counting, pp separation/slip/ring context. Test choices;
   do not create a sparse Cartesian product of keys or assume sibling max is
   physically correct. Ionic depth gaps may require a baseline decision rather
   than forcing all electrostatics into HB.
6. Calibrate depth/amplitude on independent contact-opening/formation curves
   together with total Q6+NCI slopes/curvature; retain the correct old-well
   replacement in each comparison. In full complexes, energies are not uniquely
   attributable to one contact. Use matched relative energies/forces and the
   complete objective; don't fit absolute total molecular energies or subtract
   an invented unique atomic/contact energy.
7. Require sensible minima, depths, smooth forces, two-step stable curvature,
   pull-off/pressure, no systematic wrong-sign increase and independently
   positive whole-objective response. Then freeze a supported candidate, run
   the existing-pool gate preserving assignment terms/priors, assess power,
   and only then consider one dev80 arm. No held-out S5/default activation yet.
8. Separately validate narrow Cp-only embedding release and preserve donor
   angles as well as bonds for anionic N-N models. Never let embedding changes
   conceal an adverse NCI comparison.

First deliverable: a concrete model/fitting specification and small reproducible
ablation pilot that says which errors it can correct, which data constrain its
parameters, how uncertainty/fallback works, and what would falsify it. Keep
unsupported hypotheses clearly separate from established findings. If current
representation or coverage is inadequate, return that result rather than tune
on dev outcomes. No promise of overwhelming gains before independent evidence.

## Tools, validation and operational constraints

Research tools under `tools/jdev/budget/`:

- `nci_calibration.py`, `nci_calibration_analysis.py`, `nci_probe_mechanism.py`;
- `nci_training_calibration.py`, `nci_training_analysis.py`,
  `nci_calibration_report.py`;
- `nci_thermal_audit.py`, `nci_density_balance_audit.py`;
- `nci_embedding_validation.py`, `nci_cap_generality.py`,
  `nci_internal_experiment.py`, `nci_followup_report.py`;
- existing targeted rescore, fresh solve, contact/structure/pose/balance audit,
  energy diagnosis/viewer and `refit/nci_refit.py`.

Read their stage arguments; `prepare|measure` in reports means alternatives,
not a PowerShell pipeline. Reuse caches. Do not rerun 69 solves or the full
125k extraction just to get situated. Changed experiments need new versioned
output directories; do not bypass historical source/model/DB/input hash guards.

Use PowerShell, `pixi run python`, `JACOBIK_PROFILE=u1`,
`MKL_THREADING_LAYER=SEQUENTIAL`, `OMP_NUM_THREADS=1`. One GPU workload at a
time; actual GPU is 8 GB RTX2060. At most two heavy CPU jobs. xTB temporary
directory ACLs require ordinary filesystem permissions; strict research runners
check exit/output and must not silently count MMFF fallback as GFN2 success.
Pytest temp fixtures also needed ordinary permissions in this environment.

35 focused tests passed under u1; 20 component/eligibility tests also passed
legacy. Logs are named `n2_calibration_final_tests_u1_verified_2026-10-18.log`
and `n2_calibration_component_tests_legacy_2026-10-18.log`. The earlier broader
P7 baseline validation is recorded separately in HANDOFF. Scope new tests to
actual changes; do not automatically rerun the entire benchmark stack after
every edit. All research jobs are finished.

The worktree also contains completed earlier DB migration/P7/oxidation work;
do not revert it. `.claude/` and `benchmarks/` are user-owned and outside this
task. Data, energy caches and reports live under intentionally ignored `data/`;
code/docs commits do not automatically include them. Preserve the existing
data/archives and report provenance. Do not send external messages or publish.

Maintain concise progress updates. Resolve routine implementation choices
autonomously within scope; do not repeatedly ask for approval already granted.
Report what changed, what the measurements establish, remaining uncertainty and
the decision about advancement. Be explicit if a proposed physical replacement
would change the project's data-driven architecture and needs a separate decision.
